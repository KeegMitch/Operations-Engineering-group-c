-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: owncloud
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oc_account_terms`
--

DROP TABLE IF EXISTS `oc_account_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_account_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) unsigned NOT NULL,
  `term` varchar(191) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id_index` (`account_id`),
  KEY `term_index` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_account_terms`
--

LOCK TABLES `oc_account_terms` WRITE;
/*!40000 ALTER TABLE `oc_account_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_account_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_accounts`
--

DROP TABLE IF EXISTS `oc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `lower_user_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `display_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `quota` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `last_login` int(11) NOT NULL DEFAULT '0',
  `backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `home` varchar(1024) COLLATE utf8_bin NOT NULL,
  `state` smallint(6) NOT NULL DEFAULT '0' COMMENT '0: initial, 1: enabled, 2: disabled, 3: deleted',
  `creation_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_907AA303A76ED395` (`user_id`),
  UNIQUE KEY `lower_user_id_index` (`lower_user_id`),
  KEY `display_name_index` (`display_name`),
  KEY `email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts`
--

LOCK TABLES `oc_accounts` WRITE;
/*!40000 ALTER TABLE `oc_accounts` DISABLE KEYS */;
INSERT INTO `oc_accounts` VALUES (1,NULL,'admin','admin','admin',NULL,1718062395,'OC\\User\\Database','/var/www/owncloud/data/admin',1,1715036500),(2,NULL,'ocuser01','ocuser01','ocuser01',NULL,1717464205,'OC\\User\\Database','/var/www/owncloud/data/ocuser01',1,1717405364),(3,NULL,'ocuser02','ocuser02','ocuser02',NULL,1717536426,'OC\\User\\Database','/var/www/owncloud/data/ocuser02',1,1717405365),(4,NULL,'ocuser03','ocuser03','ocuser03',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser03',1,1717405365),(5,NULL,'ocuser04','ocuser04','ocuser04',NULL,1717446195,'OC\\User\\Database','/var/www/owncloud/data/ocuser04',1,1717405366),(6,NULL,'ocuser05','ocuser05','ocuser05',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser05',1,1717405366),(7,NULL,'ocuser06','ocuser06','ocuser06',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser06',1,1717405366),(8,NULL,'ocuser07','ocuser07','ocuser07',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser07',1,1717405367),(9,NULL,'ocuser08','ocuser08','ocuser08',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser08',1,1717405367),(10,NULL,'ocuser09','ocuser09','ocuser09',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser09',1,1717405368),(11,NULL,'ocuser10','ocuser10','ocuser10',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser10',1,1717405368),(12,NULL,'ocuser11','ocuser11','ocuser11',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser11',1,1717405368),(13,NULL,'ocuser12','ocuser12','ocuser12',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser12',1,1717405369),(14,NULL,'ocuser13','ocuser13','ocuser13',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser13',1,1717405369),(15,NULL,'ocuser14','ocuser14','ocuser14',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser14',1,1717405369),(16,NULL,'ocuser15','ocuser15','ocuser15',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser15',1,1717405370),(17,NULL,'ocuser16','ocuser16','ocuser16',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser16',1,1717405370),(18,NULL,'ocuser17','ocuser17','ocuser17',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser17',1,1717405371),(19,NULL,'ocuser18','ocuser18','ocuser18',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser18',1,1717405371),(20,NULL,'ocuser19','ocuser19','ocuser19',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser19',1,1717405371),(21,NULL,'ocuser20','ocuser20','ocuser20',NULL,1717449680,'OC\\User\\Database','/var/www/owncloud/data/ocuser20',1,1717405372),(26,NULL,'admin01','admin01','admin01',NULL,1717555226,'OC\\User\\Database','/var/www/owncloud/data/admin01',1,1717552899),(27,NULL,'admin02','admin02','admin02',NULL,1717555250,'OC\\User\\Database','/var/www/owncloud/data/admin02',1,1717552900),(28,NULL,'admin03','admin03','admin03',NULL,1717555147,'OC\\User\\Database','/var/www/owncloud/data/admin03',1,1717552900);
/*!40000 ALTER TABLE `oc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity`
--

DROP TABLE IF EXISTS `oc_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_activity` (
  `activity_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `user` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `affecteduser` varchar(64) COLLATE utf8_bin NOT NULL,
  `app` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `subjectparams` longtext COLLATE utf8_bin NOT NULL,
  `message` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `messageparams` longtext COLLATE utf8_bin,
  `file` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `link` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `object_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `object_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`activity_id`),
  KEY `activity_time` (`timestamp`),
  KEY `activity_user_time` (`affecteduser`,`timestamp`),
  KEY `activity_filter_by` (`affecteduser`,`user`,`timestamp`),
  KEY `activity_filter_app` (`affecteduser`,`app`,`timestamp`),
  KEY `activity_object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity`
--

LOCK TABLES `oc_activity` WRITE;
/*!40000 ALTER TABLE `oc_activity` DISABLE KEYS */;
INSERT INTO `oc_activity` VALUES (1,1715036538,30,'file_created','admin','admin','files','created_self','[{\"3\":\"\"}]','','[]','','http://13.75.139.57/index.php/apps/files/?dir=','files',3),(2,1715036538,30,'file_created','admin','admin','files','created_self','[{\"4\":\"\\/Documents\"}]','','[]','/Documents','http://13.75.139.57/index.php/apps/files/?dir=/','files',4),(3,1715036539,30,'file_created','admin','admin','files','created_self','[{\"5\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',5),(4,1715036539,30,'file_created','admin','admin','files','created_self','[{\"6\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','http://13.75.139.57/index.php/apps/files/?dir=/','files',6),(5,1715036539,30,'file_created','admin','admin','files','created_self','[{\"7\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',7),(6,1715036539,30,'file_created','admin','admin','files','created_self','[{\"8\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',8),(7,1715036539,30,'file_created','admin','admin','files','created_self','[{\"9\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',9),(8,1715036539,30,'file_created','admin','admin','files','created_self','[{\"10\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',10),(9,1715036539,30,'file_created','admin','admin','files','created_self','[{\"11\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',11),(10,1715036539,30,'file_created','admin','admin','files','created_self','[{\"12\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',12),(11,1715036539,30,'file_created','admin','admin','files','created_self','[{\"13\":\"\\/Photos\"}]','','[]','/Photos','http://13.75.139.57/index.php/apps/files/?dir=/','files',13),(12,1715036539,30,'file_created','admin','admin','files','created_self','[{\"14\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',14),(13,1715036539,30,'file_created','admin','admin','files','created_self','[{\"15\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',15),(14,1715036540,30,'file_created','admin','admin','files','created_self','[{\"16\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',16),(15,1717536424,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"517\":\"\"}]','','[]','','https://13.75.139.57/index.php/apps/files/?dir=','files',517),(16,1717536424,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"518\":\"\\/Documents\"}]','','[]','/Documents','https://13.75.139.57/index.php/apps/files/?dir=/','files',518),(17,1717536424,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"519\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','https://13.75.139.57/index.php/apps/files/?dir=/Documents','files',519),(18,1717536424,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"520\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','https://13.75.139.57/index.php/apps/files/?dir=/','files',520),(19,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"521\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',521),(20,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"522\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',522),(21,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"523\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',523),(22,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"524\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',524),(23,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"525\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',525),(24,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"526\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',526),(25,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"527\":\"\\/Photos\"}]','','[]','/Photos','https://13.75.139.57/index.php/apps/files/?dir=/','files',527),(26,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"528\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',528),(27,1717536425,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"529\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',529),(28,1717536426,30,'file_created','ocuser02','ocuser02','files','created_self','[{\"530\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',530),(29,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"558\":\"\"}]','','[]','','https://13.75.139.57/index.php/apps/files/?dir=','files',558),(30,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"559\":\"\\/Documents\"}]','','[]','/Documents','https://13.75.139.57/index.php/apps/files/?dir=/','files',559),(31,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"560\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','https://13.75.139.57/index.php/apps/files/?dir=/Documents','files',560),(32,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"561\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','https://13.75.139.57/index.php/apps/files/?dir=/','files',561),(33,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"562\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',562),(34,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"563\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',563),(35,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"564\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',564),(36,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"565\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',565),(37,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"566\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',566),(38,1717552919,30,'file_created','admin03','admin03','files','created_self','[{\"567\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','https://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',567),(39,1717552920,30,'file_created','admin03','admin03','files','created_self','[{\"568\":\"\\/Photos\"}]','','[]','/Photos','https://13.75.139.57/index.php/apps/files/?dir=/','files',568),(40,1717552920,30,'file_created','admin03','admin03','files','created_self','[{\"569\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',569),(41,1717552920,30,'file_created','admin03','admin03','files','created_self','[{\"570\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',570),(42,1717552920,30,'file_created','admin03','admin03','files','created_self','[{\"571\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','https://13.75.139.57/index.php/apps/files/?dir=/Photos','files',571),(43,1717553025,30,'file_created','admin01','admin01','files','created_self','[{\"574\":\"\"}]','','[]','','http://13.75.139.57/index.php/apps/files/?dir=','files',574),(44,1717553025,30,'file_created','admin01','admin01','files','created_self','[{\"575\":\"\\/Documents\"}]','','[]','/Documents','http://13.75.139.57/index.php/apps/files/?dir=/','files',575),(45,1717553025,30,'file_created','admin01','admin01','files','created_self','[{\"576\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',576),(46,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"577\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','http://13.75.139.57/index.php/apps/files/?dir=/','files',577),(47,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"578\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',578),(48,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"579\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',579),(49,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"580\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',580),(50,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"581\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',581),(51,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"582\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',582),(52,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"583\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',583),(53,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"584\":\"\\/Photos\"}]','','[]','/Photos','http://13.75.139.57/index.php/apps/files/?dir=/','files',584),(54,1717553026,30,'file_created','admin01','admin01','files','created_self','[{\"585\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',585),(55,1717553027,30,'file_created','admin01','admin01','files','created_self','[{\"586\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',586),(56,1717553027,30,'file_created','admin01','admin01','files','created_self','[{\"587\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',587),(57,1717553397,30,'file_created','admin03','admin03','files','created_self','[{\"853\":\"\\/ubuntu-24.04-live-server-amd64.iso\"}]','','[]','/ubuntu-24.04-live-server-amd64.iso','https://13.75.139.57/index.php/apps/files/?dir=/','files',853),(58,1717553932,30,'file_created','admin01','admin01','files','created_self','[{\"1119\":\"\\/Documents\\/ubuntu-24.04-live-server-amd64.iso\"}]','','[]','/Documents/ubuntu-24.04-live-server-amd64.iso','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',1119),(59,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1122\":\"\"}]','','[]','','http://13.75.139.57/index.php/apps/files/?dir=','files',1122),(60,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1123\":\"\\/Documents\"}]','','[]','/Documents','http://13.75.139.57/index.php/apps/files/?dir=/','files',1123),(61,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1124\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',1124),(62,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1125\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','http://13.75.139.57/index.php/apps/files/?dir=/','files',1125),(63,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1126\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1126),(64,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1127\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1127),(65,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1128\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1128),(66,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1129\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1129),(67,1717554045,30,'file_created','admin02','admin02','files','created_self','[{\"1130\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1130),(68,1717554046,30,'file_created','admin02','admin02','files','created_self','[{\"1131\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',1131),(69,1717554046,30,'file_created','admin02','admin02','files','created_self','[{\"1132\":\"\\/Photos\"}]','','[]','/Photos','http://13.75.139.57/index.php/apps/files/?dir=/','files',1132),(70,1717554046,30,'file_created','admin02','admin02','files','created_self','[{\"1133\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',1133),(71,1717554046,30,'file_created','admin02','admin02','files','created_self','[{\"1134\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',1134),(72,1717554046,30,'file_created','admin02','admin02','files','created_self','[{\"1135\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',1135),(73,1717554397,30,'file_created','admin02','admin02','files','created_self','[{\"1401\":\"\\/Documents\\/ubuntu-24.04-live-server-amd64.iso\"}]','','[]','/Documents/ubuntu-24.04-live-server-amd64.iso','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',1401);
/*!40000 ALTER TABLE `oc_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity_mq`
--

DROP TABLE IF EXISTS `oc_activity_mq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_activity_mq` (
  `mail_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amq_timestamp` int(11) NOT NULL DEFAULT '0',
  `amq_latest_send` int(11) NOT NULL DEFAULT '0',
  `amq_type` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_affecteduser` varchar(64) COLLATE utf8_bin NOT NULL,
  `amq_appid` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_subjectparams` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`mail_id`),
  KEY `amp_user` (`amq_affecteduser`),
  KEY `amp_latest_send_time` (`amq_latest_send`),
  KEY `amp_timestamp_time` (`amq_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity_mq`
--

LOCK TABLES `oc_activity_mq` WRITE;
/*!40000 ALTER TABLE `oc_activity_mq` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_activity_mq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbookchanges`
--

DROP TABLE IF EXISTS `oc_addressbookchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_addressbookchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `addressbookid` int(11) NOT NULL,
  `operation` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addressbookid_synctoken` (`addressbookid`,`synctoken`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbookchanges`
--

LOCK TABLES `oc_addressbookchanges` WRITE;
/*!40000 ALTER TABLE `oc_addressbookchanges` DISABLE KEYS */;
INSERT INTO `oc_addressbookchanges` VALUES (1,'Database:admin.vcf',1,2,1),(2,'Database:ocuser01.vcf',2,2,1),(3,'Database:ocuser02.vcf',3,2,1),(4,'Database:ocuser03.vcf',4,2,1),(5,'Database:ocuser04.vcf',5,2,1),(6,'Database:ocuser05.vcf',6,2,1),(7,'Database:ocuser06.vcf',7,2,1),(8,'Database:ocuser07.vcf',8,2,1),(9,'Database:ocuser08.vcf',9,2,1),(10,'Database:ocuser09.vcf',10,2,1),(11,'Database:ocuser10.vcf',11,2,1),(12,'Database:ocuser11.vcf',12,2,1),(13,'Database:ocuser12.vcf',13,2,1),(14,'Database:ocuser13.vcf',14,2,1),(15,'Database:ocuser14.vcf',15,2,1),(16,'Database:ocuser15.vcf',16,2,1),(17,'Database:ocuser16.vcf',17,2,1),(18,'Database:ocuser17.vcf',18,2,1),(19,'Database:ocuser18.vcf',19,2,1),(20,'Database:ocuser19.vcf',20,2,1),(21,'Database:ocuser20.vcf',21,2,1),(22,'Database:testuser.vcf',22,2,1),(23,'Database:testuser.vcf',23,2,3),(24,'Database:admin01.vcf',24,2,1),(25,'Database:admin01.vcf',25,2,2),(26,'Database:admin02.vcf',26,2,1),(27,'Database:admin02.vcf',27,2,2),(28,'Database:admin03.vcf',28,2,1),(29,'Database:admin01.vcf',29,2,3),(30,'Database:admin02.vcf',30,2,3),(31,'Database:admin03.vcf',31,2,3),(32,'Database:admin01.vcf',32,2,1),(33,'Database:admin02.vcf',33,2,1),(34,'Database:admin03.vcf',34,2,1);
/*!40000 ALTER TABLE `oc_addressbookchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbooks`
--

DROP TABLE IF EXISTS `oc_addressbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_addressbooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `addressbook_index` (`principaluri`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbooks`
--

LOCK TABLES `oc_addressbooks` WRITE;
/*!40000 ALTER TABLE `oc_addressbooks` DISABLE KEYS */;
INSERT INTO `oc_addressbooks` VALUES (1,'principals/users/admin','Contacts','contacts',NULL,1),(2,'principals/system/system','system','system','System addressbook which holds all users of this instance',35),(3,'principals/users/ocuser04','Contacts','contacts',NULL,1),(4,'principals/users/ocuser20','Contacts','contacts',NULL,1),(5,'principals/users/ocuser01','Contacts','contacts',NULL,1),(6,'principals/users/ocuser02','Contacts','contacts',NULL,1),(7,'principals/users/admin03','Contacts','contacts',NULL,1),(8,'principals/users/admin01','Contacts','contacts',NULL,1),(9,'principals/users/admin02','Contacts','contacts',NULL,1);
/*!40000 ALTER TABLE `oc_addressbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_appconfig`
--

DROP TABLE IF EXISTS `oc_appconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_appconfig` (
  `appid` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8_bin,
  PRIMARY KEY (`appid`,`configkey`),
  KEY `appconfig_config_key_index` (`configkey`),
  KEY `appconfig_appid_key` (`appid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_appconfig`
--

LOCK TABLES `oc_appconfig` WRITE;
/*!40000 ALTER TABLE `oc_appconfig` DISABLE KEYS */;
INSERT INTO `oc_appconfig` VALUES ('activity','enabled','yes'),('activity','installed_version','2.7.2'),('activity','types','filesystem'),('backgroundjob','lastjob','6'),('comments','enabled','yes'),('comments','installed_version','0.3.0'),('comments','types','logging,dav'),('configreport','enabled','yes'),('configreport','installed_version','0.2.2'),('configreport','types','filesystem'),('core','first_install_version','10.14.0.3'),('core','installedat','1715036500.9282'),('core','lastcron','1718097511'),('core','lastupdateResult','[]'),('core','lastupdatedat','1717732660'),('core','oc.integritycheck.checker','[]'),('core','public_files','files_sharing/public.php'),('core','public_webdav','dav/appinfo/v1/publicwebdav.php'),('dav','enabled','yes'),('dav','installed_version','0.7.0'),('dav','types','filesystem'),('diagnostics','enabled','yes'),('diagnostics','installed_version','0.2.0'),('diagnostics','types','authentication'),('federatedfilesharing','enabled','yes'),('federatedfilesharing','installed_version','0.5.0'),('federatedfilesharing','types','filesystem'),('federation','enabled','yes'),('federation','installed_version','0.1.0'),('federation','types','authentication'),('files','cronjob_scan_files','500'),('files','enabled','yes'),('files','installed_version','1.6.0'),('files','types','filesystem'),('files_external','enabled','yes'),('files_external','installed_version','0.9.0'),('files_external','types','filesystem'),('files_mediaviewer','enabled','yes'),('files_mediaviewer','installed_version','1.0.5'),('files_mediaviewer','types',''),('files_pdfviewer','enabled','yes'),('files_pdfviewer','installed_version','1.0.2'),('files_pdfviewer','types',''),('files_sharing','enabled','yes'),('files_sharing','installed_version','0.14.0'),('files_sharing','types','filesystem'),('files_texteditor','enabled','yes'),('files_texteditor','installed_version','2.6.1'),('files_texteditor','types',''),('files_trashbin','enabled','yes'),('files_trashbin','installed_version','0.9.1'),('files_trashbin','types','filesystem'),('files_versions','enabled','yes'),('files_versions','installed_version','1.3.0'),('files_versions','types','filesystem'),('firstrunwizard','enabled','yes'),('firstrunwizard','installed_version','1.3.0'),('firstrunwizard','types',''),('market','enabled','yes'),('market','installed_version','0.8.0'),('market','types',''),('notifications','enabled','yes'),('notifications','installed_version','0.6.0'),('notifications','types','logging'),('provisioning_api','enabled','yes'),('provisioning_api','installed_version','0.5.0'),('provisioning_api','types','prevent_group_restriction'),('systemtags','enabled','yes'),('systemtags','installed_version','0.3.0'),('systemtags','types','logging'),('updatenotification','enabled','yes'),('updatenotification','installed_version','0.2.1'),('updatenotification','types','');
/*!40000 ALTER TABLE `oc_appconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authtoken`
--

DROP TABLE IF EXISTS `oc_authtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_authtoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `login_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` longtext COLLATE utf8_bin,
  `name` longtext COLLATE utf8_bin NOT NULL,
  `token` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `last_check` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `authtoken_token_index` (`token`),
  KEY `authtoken_last_activity_index` (`last_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authtoken`
--

LOCK TABLES `oc_authtoken` WRITE;
/*!40000 ALTER TABLE `oc_authtoken` DISABLE KEYS */;
INSERT INTO `oc_authtoken` VALUES (42,'admin','admin','v2|665d1c278631563b27065b86e7233114b457f98f0b7329441538cdbf15566f70|b45d4450aa14960e3f1f2e46aa9f3b01|4b63936cbd3fdebaf5e1d1361e5f87d6432c8b26840bd88c8e911e5d25bdddf42bca165882d2aa93998501ebd1c6989233446f7cc7304aabcb70b4c1895d34d5','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','e7e9177fe7b0df53e4d12b6ba596689b39155bebc2a51f7ca8769f6744b3942b741a7d353a9e3c4e2cbca2c5e9e083a0cb9862d29ecc8b3346df6a119c9ce166',0,1717929083,1717929083),(43,'admin','admin','v2|c5c3b2e26f6cf1f1d556b7d626ede52bcae4f710d3d62ecb2b2caf40a358bc28|781003c80181dc76e2749212608fb45a|5097ba7bbd07f435d9c8daf7553ce3d5fc8ebcdef27b66e4b286f715f5ea9587b642b5019f48150a53a4dbf3a0d94ad981e1908853b9987110f1f03a88c167a3','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','e903a8cb637ca4eb430ec0e2b125804bb7c08a2cab4cc3186782c3494600e7de9cc82dfc09e2b3989cb817364f2a3f6aaafd76df078fc223e5143ea3ef7b5bd2',0,1718062395,1718062395);
/*!40000 ALTER TABLE `oc_authtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarchanges`
--

DROP TABLE IF EXISTS `oc_calendarchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `calendarid` int(11) NOT NULL,
  `operation` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendarid_synctoken` (`calendarid`,`synctoken`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarchanges`
--

LOCK TABLES `oc_calendarchanges` WRITE;
/*!40000 ALTER TABLE `oc_calendarchanges` DISABLE KEYS */;
INSERT INTO `oc_calendarchanges` VALUES (1,'system-Database:testuser.vcf.ics',1,2,3),(2,'system-Database:testuser.vcf-death.ics',2,2,3),(3,'system-Database:testuser.vcf-anniversary.ics',3,2,3),(4,'system-Database:admin01.vcf.ics',4,2,3),(5,'system-Database:admin01.vcf-death.ics',5,2,3),(6,'system-Database:admin01.vcf-anniversary.ics',6,2,3),(7,'system-Database:admin02.vcf.ics',7,2,3),(8,'system-Database:admin02.vcf-death.ics',8,2,3),(9,'system-Database:admin02.vcf-anniversary.ics',9,2,3),(10,'system-Database:admin03.vcf.ics',10,2,3),(11,'system-Database:admin03.vcf-death.ics',11,2,3),(12,'system-Database:admin03.vcf-anniversary.ics',12,2,3);
/*!40000 ALTER TABLE `oc_calendarchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects`
--

DROP TABLE IF EXISTS `oc_calendarobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendarid` int(10) unsigned NOT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `componenttype` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `firstoccurence` bigint(20) unsigned DEFAULT NULL,
  `lastoccurence` bigint(20) unsigned DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `classification` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `calobjects_index` (`calendarid`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects`
--

LOCK TABLES `oc_calendarobjects` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendars`
--

DROP TABLE IF EXISTS `oc_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `description` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `timezone` longtext COLLATE utf8_bin,
  `components` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `transparent` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `calendars_index` (`principaluri`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendars`
--

LOCK TABLES `oc_calendars` WRITE;
/*!40000 ALTER TABLE `oc_calendars` DISABLE KEYS */;
INSERT INTO `oc_calendars` VALUES (1,'principals/users/admin','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(2,'principals/system/system','Contact birthdays','contact_birthdays',13,NULL,0,'#FFFFCA',NULL,'VEVENT,VTODO',0),(3,'principals/users/ocuser04','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(4,'principals/users/ocuser20','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(5,'principals/users/ocuser01','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(6,'principals/users/ocuser02','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(7,'principals/users/admin03','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(8,'principals/users/admin01','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(9,'principals/users/admin02','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0);
/*!40000 ALTER TABLE `oc_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarsubscriptions`
--

DROP TABLE IF EXISTS `oc_calendarsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarsubscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `refreshrate` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `striptodos` smallint(6) DEFAULT NULL,
  `stripalarms` smallint(6) DEFAULT NULL,
  `stripattachments` smallint(6) DEFAULT NULL,
  `lastmodified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calsub_index` (`principaluri`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarsubscriptions`
--

LOCK TABLES `oc_calendarsubscriptions` WRITE;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards`
--

DROP TABLE IF EXISTS `oc_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` int(11) NOT NULL DEFAULT '0',
  `carddata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `lastmodified` bigint(20) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addressbookid_uri_index` (`addressbookid`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards`
--

LOCK TABLES `oc_cards` WRITE;
/*!40000 ALTER TABLE `oc_cards` DISABLE KEYS */;
INSERT INTO `oc_cards` VALUES (1,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:admin\r\nFN:admin\r\nN:admin;;;;\r\nCLOUD:admin@13.75.139.57\r\nEND:VCARD\r\n','Database:admin.vcf',1715037010,'f1d5727ee1334176a3958a4da10de53f',139),(2,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser01\r\nFN:ocuser01\r\nN:ocuser01;;;;\r\nCLOUD:ocuser01@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser01.vcf',1717405365,'58cda386f8461f01ea62874bb6bd10e3',151),(3,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser02\r\nFN:ocuser02\r\nN:ocuser02;;;;\r\nCLOUD:ocuser02@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser02.vcf',1717405365,'c9f8c2ff4755a5654f7e28f38fc1483d',151),(4,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser03\r\nFN:ocuser03\r\nN:ocuser03;;;;\r\nCLOUD:ocuser03@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser03.vcf',1717405365,'8e3b982844dc91339a01f30991d9868a',151),(5,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser04\r\nFN:ocuser04\r\nN:ocuser04;;;;\r\nCLOUD:ocuser04@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser04.vcf',1717405366,'891dad2baa4b70f70b0bf5a7c24db7d2',151),(6,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser05\r\nFN:ocuser05\r\nN:ocuser05;;;;\r\nCLOUD:ocuser05@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser05.vcf',1717405366,'17ea8e97322087e97dc28847e2d822f0',151),(7,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser06\r\nFN:ocuser06\r\nN:ocuser06;;;;\r\nCLOUD:ocuser06@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser06.vcf',1717405366,'f7aa5dad0bad3150bcf7d411d2d03b60',151),(8,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser07\r\nFN:ocuser07\r\nN:ocuser07;;;;\r\nCLOUD:ocuser07@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser07.vcf',1717405367,'91f31e128d71922000dda4521a2fd637',151),(9,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser08\r\nFN:ocuser08\r\nN:ocuser08;;;;\r\nCLOUD:ocuser08@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser08.vcf',1717405367,'ca1f7e06de4f960d311c0bdafc3931a6',151),(10,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser09\r\nFN:ocuser09\r\nN:ocuser09;;;;\r\nCLOUD:ocuser09@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser09.vcf',1717405368,'82700c28f0ebcc4ef78ee0b9f29729be',151),(11,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser10\r\nFN:ocuser10\r\nN:ocuser10;;;;\r\nCLOUD:ocuser10@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser10.vcf',1717405368,'749504b391ad37af21d813adc34d9854',151),(12,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser11\r\nFN:ocuser11\r\nN:ocuser11;;;;\r\nCLOUD:ocuser11@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser11.vcf',1717405368,'990207695d5c063dbc5b4bb595567c2c',151),(13,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser12\r\nFN:ocuser12\r\nN:ocuser12;;;;\r\nCLOUD:ocuser12@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser12.vcf',1717405369,'58f7e09827bd0094762e96274a570a7f',151),(14,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser13\r\nFN:ocuser13\r\nN:ocuser13;;;;\r\nCLOUD:ocuser13@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser13.vcf',1717405369,'be31e1d6aa38a4875081a166cef0c5d6',151),(15,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser14\r\nFN:ocuser14\r\nN:ocuser14;;;;\r\nCLOUD:ocuser14@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser14.vcf',1717405369,'fbc29a297947b2fc00fa031686473ab0',151),(16,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser15\r\nFN:ocuser15\r\nN:ocuser15;;;;\r\nCLOUD:ocuser15@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser15.vcf',1717405370,'5e51fe91c8beb6d98866aa9d6012ab96',151),(17,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser16\r\nFN:ocuser16\r\nN:ocuser16;;;;\r\nCLOUD:ocuser16@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser16.vcf',1717405370,'f863e31b8a891c8308587165bb2d25b9',151),(18,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser17\r\nFN:ocuser17\r\nN:ocuser17;;;;\r\nCLOUD:ocuser17@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser17.vcf',1717405371,'ca4d2ac478673e65413e76d2e09bb3c7',151),(19,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser18\r\nFN:ocuser18\r\nN:ocuser18;;;;\r\nCLOUD:ocuser18@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser18.vcf',1717405371,'588b0b6cd6eb7d8f70ba66b910682fa3',151),(20,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser19\r\nFN:ocuser19\r\nN:ocuser19;;;;\r\nCLOUD:ocuser19@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser19.vcf',1717405371,'18c7e19569a5f915c44bb90d10ca3e30',151),(21,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser20\r\nFN:ocuser20\r\nN:ocuser20;;;;\r\nCLOUD:ocuser20@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser20.vcf',1717405372,'86da30b7358de500247bacc9fdc8b33e',151),(26,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:admin01\r\nFN:admin01\r\nN:admin01;;;;\r\nCLOUD:admin01@13.75.139.57\r\nEND:VCARD\r\n','Database:admin01.vcf',1717552899,'7a080142a34d2ff60e895c62241cae9a',147),(27,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:admin02\r\nFN:admin02\r\nN:admin02;;;;\r\nCLOUD:admin02@13.75.139.57\r\nEND:VCARD\r\n','Database:admin02.vcf',1717552900,'bf1393db713a0ed4281972370113fd6c',147),(28,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:admin03\r\nFN:admin03\r\nN:admin03;;;;\r\nCLOUD:admin03@13.75.139.57\r\nEND:VCARD\r\n','Database:admin03.vcf',1717552900,'e887891a4c3a357fa22a881378ce6ac1',147);
/*!40000 ALTER TABLE `oc_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards_properties`
--

DROP TABLE IF EXISTS `oc_cards_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_cards_properties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint(20) NOT NULL DEFAULT '0',
  `cardid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `preferred` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `card_value_index` (`value`),
  KEY `card_name_index` (`name`),
  KEY `card_contactid_index` (`cardid`),
  KEY `card_bookid_name_index` (`addressbookid`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards_properties`
--

LOCK TABLES `oc_cards_properties` WRITE;
/*!40000 ALTER TABLE `oc_cards_properties` DISABLE KEYS */;
INSERT INTO `oc_cards_properties` VALUES (1,2,1,'UID','admin',0),(2,2,1,'FN','admin',0),(3,2,1,'N','admin;;;;',0),(4,2,1,'CLOUD','admin@13.75.139.57',0),(5,2,2,'UID','ocuser01',0),(6,2,2,'FN','ocuser01',0),(7,2,2,'N','ocuser01;;;;',0),(8,2,2,'CLOUD','ocuser01@13.75.139.57',0),(9,2,3,'UID','ocuser02',0),(10,2,3,'FN','ocuser02',0),(11,2,3,'N','ocuser02;;;;',0),(12,2,3,'CLOUD','ocuser02@13.75.139.57',0),(13,2,4,'UID','ocuser03',0),(14,2,4,'FN','ocuser03',0),(15,2,4,'N','ocuser03;;;;',0),(16,2,4,'CLOUD','ocuser03@13.75.139.57',0),(17,2,5,'UID','ocuser04',0),(18,2,5,'FN','ocuser04',0),(19,2,5,'N','ocuser04;;;;',0),(20,2,5,'CLOUD','ocuser04@13.75.139.57',0),(21,2,6,'UID','ocuser05',0),(22,2,6,'FN','ocuser05',0),(23,2,6,'N','ocuser05;;;;',0),(24,2,6,'CLOUD','ocuser05@13.75.139.57',0),(25,2,7,'UID','ocuser06',0),(26,2,7,'FN','ocuser06',0),(27,2,7,'N','ocuser06;;;;',0),(28,2,7,'CLOUD','ocuser06@13.75.139.57',0),(29,2,8,'UID','ocuser07',0),(30,2,8,'FN','ocuser07',0),(31,2,8,'N','ocuser07;;;;',0),(32,2,8,'CLOUD','ocuser07@13.75.139.57',0),(33,2,9,'UID','ocuser08',0),(34,2,9,'FN','ocuser08',0),(35,2,9,'N','ocuser08;;;;',0),(36,2,9,'CLOUD','ocuser08@13.75.139.57',0),(37,2,10,'UID','ocuser09',0),(38,2,10,'FN','ocuser09',0),(39,2,10,'N','ocuser09;;;;',0),(40,2,10,'CLOUD','ocuser09@13.75.139.57',0),(41,2,11,'UID','ocuser10',0),(42,2,11,'FN','ocuser10',0),(43,2,11,'N','ocuser10;;;;',0),(44,2,11,'CLOUD','ocuser10@13.75.139.57',0),(45,2,12,'UID','ocuser11',0),(46,2,12,'FN','ocuser11',0),(47,2,12,'N','ocuser11;;;;',0),(48,2,12,'CLOUD','ocuser11@13.75.139.57',0),(49,2,13,'UID','ocuser12',0),(50,2,13,'FN','ocuser12',0),(51,2,13,'N','ocuser12;;;;',0),(52,2,13,'CLOUD','ocuser12@13.75.139.57',0),(53,2,14,'UID','ocuser13',0),(54,2,14,'FN','ocuser13',0),(55,2,14,'N','ocuser13;;;;',0),(56,2,14,'CLOUD','ocuser13@13.75.139.57',0),(57,2,15,'UID','ocuser14',0),(58,2,15,'FN','ocuser14',0),(59,2,15,'N','ocuser14;;;;',0),(60,2,15,'CLOUD','ocuser14@13.75.139.57',0),(61,2,16,'UID','ocuser15',0),(62,2,16,'FN','ocuser15',0),(63,2,16,'N','ocuser15;;;;',0),(64,2,16,'CLOUD','ocuser15@13.75.139.57',0),(65,2,17,'UID','ocuser16',0),(66,2,17,'FN','ocuser16',0),(67,2,17,'N','ocuser16;;;;',0),(68,2,17,'CLOUD','ocuser16@13.75.139.57',0),(69,2,18,'UID','ocuser17',0),(70,2,18,'FN','ocuser17',0),(71,2,18,'N','ocuser17;;;;',0),(72,2,18,'CLOUD','ocuser17@13.75.139.57',0),(73,2,19,'UID','ocuser18',0),(74,2,19,'FN','ocuser18',0),(75,2,19,'N','ocuser18;;;;',0),(76,2,19,'CLOUD','ocuser18@13.75.139.57',0),(77,2,20,'UID','ocuser19',0),(78,2,20,'FN','ocuser19',0),(79,2,20,'N','ocuser19;;;;',0),(80,2,20,'CLOUD','ocuser19@13.75.139.57',0),(81,2,21,'UID','ocuser20',0),(82,2,21,'FN','ocuser20',0),(83,2,21,'N','ocuser20;;;;',0),(84,2,21,'CLOUD','ocuser20@13.75.139.57',0),(111,2,26,'UID','admin01',0),(112,2,26,'FN','admin01',0),(113,2,26,'N','admin01;;;;',0),(114,2,26,'CLOUD','admin01@13.75.139.57',0),(115,2,27,'UID','admin02',0),(116,2,27,'FN','admin02',0),(117,2,27,'N','admin02;;;;',0),(118,2,27,'CLOUD','admin02@13.75.139.57',0),(119,2,28,'UID','admin03',0),(120,2,28,'FN','admin03',0),(121,2,28,'N','admin03;;;;',0),(122,2,28,'CLOUD','admin03@13.75.139.57',0);
/*!40000 ALTER TABLE `oc_cards_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments`
--

DROP TABLE IF EXISTS `oc_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `topmost_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `children_count` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `actor_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message` longtext COLLATE utf8_bin,
  `verb` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `creation_timestamp` datetime DEFAULT NULL,
  `latest_child_timestamp` datetime DEFAULT NULL,
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `comments_parent_id_index` (`parent_id`),
  KEY `comments_topmost_parent_id_idx` (`topmost_parent_id`),
  KEY `comments_object_index` (`object_type`,`object_id`,`creation_timestamp`),
  KEY `comments_actor_index` (`actor_type`,`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments`
--

LOCK TABLES `oc_comments` WRITE;
/*!40000 ALTER TABLE `oc_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments_read_markers`
--

DROP TABLE IF EXISTS `oc_comments_read_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_comments_read_markers` (
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `marker_datetime` datetime DEFAULT NULL,
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `comments_marker_index` (`user_id`,`object_type`,`object_id`),
  KEY `comments_marker_object_index` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments_read_markers`
--

LOCK TABLES `oc_comments_read_markers` WRITE;
/*!40000 ALTER TABLE `oc_comments_read_markers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments_read_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_credentials`
--

DROP TABLE IF EXISTS `oc_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_credentials` (
  `user` varchar(64) COLLATE utf8_bin NOT NULL,
  `identifier` varchar(64) COLLATE utf8_bin NOT NULL,
  `credentials` longtext COLLATE utf8_bin,
  PRIMARY KEY (`user`,`identifier`),
  KEY `credentials_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_credentials`
--

LOCK TABLES `oc_credentials` WRITE;
/*!40000 ALTER TABLE `oc_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_job_status`
--

DROP TABLE IF EXISTS `oc_dav_job_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_job_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8_bin NOT NULL COMMENT '(DC2Type:guid)',
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `status_info` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_18BBA548D17F50A6` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_job_status`
--

LOCK TABLES `oc_dav_job_status` WRITE;
/*!40000 ALTER TABLE `oc_dav_job_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_job_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_properties`
--

DROP TABLE IF EXISTS `oc_dav_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_properties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `propertypath` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyvalue` varchar(255) COLLATE utf8_bin NOT NULL,
  `propertytype` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `propertypath_index` (`propertypath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_properties`
--

LOCK TABLES `oc_dav_properties` WRITE;
/*!40000 ALTER TABLE `oc_dav_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_shares`
--

DROP TABLE IF EXISTS `oc_dav_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_shares` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `access` smallint(6) DEFAULT NULL,
  `resourceid` int(10) unsigned NOT NULL,
  `publicuri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_shares_index` (`principaluri`,`resourceid`,`type`,`publicuri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_shares`
--

LOCK TABLES `oc_dav_shares` WRITE;
/*!40000 ALTER TABLE `oc_dav_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_applicable`
--

DROP TABLE IF EXISTS `oc_external_applicable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_applicable` (
  `applicable_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  `value` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`applicable_id`),
  UNIQUE KEY `applicable_type_value_mount` (`type`,`value`,`mount_id`),
  KEY `applicable_mount` (`mount_id`),
  KEY `applicable_type_value` (`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_applicable`
--

LOCK TABLES `oc_external_applicable` WRITE;
/*!40000 ALTER TABLE `oc_external_applicable` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_applicable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_config`
--

DROP TABLE IF EXISTS `oc_external_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_config` (
  `config_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `value` varchar(4096) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `config_mount_key` (`mount_id`,`key`),
  KEY `config_mount` (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_config`
--

LOCK TABLES `oc_external_config` WRITE;
/*!40000 ALTER TABLE `oc_external_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_mounts`
--

DROP TABLE IF EXISTS `oc_external_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_mounts` (
  `mount_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_point` varchar(128) COLLATE utf8_bin NOT NULL,
  `storage_backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `auth_backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `type` int(11) NOT NULL,
  PRIMARY KEY (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_mounts`
--

LOCK TABLES `oc_external_mounts` WRITE;
/*!40000 ALTER TABLE `oc_external_mounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_options`
--

DROP TABLE IF EXISTS `oc_external_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_options` (
  `option_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `value` varchar(256) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_mount_key` (`mount_id`,`key`),
  KEY `option_mount` (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_options`
--

LOCK TABLES `oc_external_options` WRITE;
/*!40000 ALTER TABLE `oc_external_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_federated_reshares`
--

DROP TABLE IF EXISTS `oc_federated_reshares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_federated_reshares` (
  `share_id` bigint(20) NOT NULL,
  `remote_id` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'share ID at the remote server',
  UNIQUE KEY `share_id_index` (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_federated_reshares`
--

LOCK TABLES `oc_federated_reshares` WRITE;
/*!40000 ALTER TABLE `oc_federated_reshares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_federated_reshares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_file_locks`
--

DROP TABLE IF EXISTS `oc_file_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_file_locks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lock` int(11) NOT NULL DEFAULT '0',
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `ttl` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lock_key_index` (`key`),
  KEY `lock_ttl_index` (`ttl`)
) ENGINE=InnoDB AUTO_INCREMENT=725 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_file_locks`
--

LOCK TABLES `oc_file_locks` WRITE;
/*!40000 ALTER TABLE `oc_file_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_file_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache`
--

DROP TABLE IF EXISTS `oc_filecache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_filecache` (
  `fileid` bigint(20) NOT NULL AUTO_INCREMENT,
  `storage` int(11) NOT NULL DEFAULT '0',
  `path` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `path_hash` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `parent` bigint(20) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `mimetype` int(11) NOT NULL DEFAULT '0',
  `mimepart` int(11) NOT NULL DEFAULT '0',
  `size` bigint(20) NOT NULL DEFAULT '0',
  `mtime` bigint(20) NOT NULL DEFAULT '0',
  `storage_mtime` bigint(20) NOT NULL DEFAULT '0',
  `encrypted` int(11) NOT NULL DEFAULT '0',
  `unencrypted_size` bigint(20) NOT NULL DEFAULT '0',
  `etag` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `permissions` int(11) DEFAULT '0',
  `checksum` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`fileid`),
  UNIQUE KEY `fs_storage_path_hash` (`storage`,`path_hash`),
  KEY `fs_parent_name_hash` (`parent`,`name`),
  KEY `fs_storage_mimetype` (`storage`,`mimetype`),
  KEY `fs_storage_mimepart` (`storage`,`mimepart`),
  KEY `fs_storage_size` (`storage`,`size`,`fileid`),
  KEY `fs_parent_storage_size` (`parent`,`storage`,`size`)
) ENGINE=InnoDB AUTO_INCREMENT=1404 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache`
--

LOCK TABLES `oc_filecache` WRITE;
/*!40000 ALTER TABLE `oc_filecache` DISABLE KEYS */;
INSERT INTO `oc_filecache` VALUES (1,2,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1715037031,1715037031,0,0,'6639617c09382',23,''),(2,2,'cache','0fea6a13c52b4d4725368f24b045ca84',1,'cache',2,1,0,1715036538,1715036538,0,0,'6639617a99996',31,''),(3,2,'files','45b963397aa40d4a0063e0d85e4fe7a1',1,'files',2,1,4688555,1715036540,1715036539,0,0,'6639617c09382',31,''),(4,2,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',3,'Documents',2,1,36227,1715036538,1715036538,0,0,'6639617af1061',31,''),(5,2,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',4,'Example.odt',4,3,36227,1715036539,1715036539,0,0,'0f879ed35c9022b35301d572c957143a',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(6,2,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',3,'Learn more about ownCloud',2,1,3640864,1715036539,1715036539,0,0,'6639617ba34bc',31,''),(7,2,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',6,'ownCloud Subscription Overview.pdf',5,3,1611431,1715036539,1715036539,0,0,'f0c40eacdb57d0186cdcac1c7c21bf4b',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(8,2,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',6,'Share files efficiently in your company.pdf',5,3,303237,1715036539,1715036539,0,0,'9755645aeda18f5e5040255b1c3e51b4',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(9,2,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',6,'Introducing ownCloud.pdf',5,3,238300,1715036539,1715036539,0,0,'744c73ec9bc558e50faeaf769f26b35e',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(10,2,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',6,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1715036539,1715036539,0,0,'c4d32c9acf5ca1cff5ef12a6bb11cc42',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(11,2,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',6,'Safely leverage Microsoft Office.pdf',5,3,314348,1715036539,1715036539,0,0,'2c931cbb5973e0ae97d66d3e2fd36efb',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(12,2,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',6,'Keep your files safe with ownCloud.pdf',5,3,755022,1715036539,1715036539,0,0,'c891849d6da02ef24c2bae307bb3402a',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(13,2,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',3,'Photos',2,1,1011464,1715036540,1715036540,0,0,'6639617c09382',31,''),(14,2,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',13,'Lake-Constance.jpg',7,6,538942,1715036539,1715036539,0,0,'34d400d02e041619f7eb976e5894e6e7',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(15,2,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',13,'Teotihuacan.jpg',7,6,228789,1715036539,1715036539,0,0,'9d25c1c3feea9cc658f4c36263741f3b',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(16,2,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',13,'Portugal.jpg',7,6,243733,1715036540,1715036540,0,0,'d042f6aa16c55dee5f499938e5d3c984',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(17,3,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,-2,1717536424,1717536424,0,0,'665fc06d2f18b',23,''),(18,3,'avatars','aec9f4efc5a055bbd053f220538c61e0',17,'avatars',2,1,0,1715036540,1715036540,0,0,'6639617c639da',31,''),(19,2,'thumbnails','3b8779ba05b8f0aed49650f3ff8beb4b',1,'thumbnails',2,1,-2,1715037032,1715037032,0,0,'66396367d3216',31,''),(20,2,'thumbnails/16','205061c872c90eb2ccc9f589b194004d',19,'16',2,1,0,1717654202,1717654202,0,0,'66396367d9aaa',31,''),(21,2,'thumbnails/15','fc5030e51a18e2657b54b65613863ec6',19,'15',2,1,0,1715056962,1715056962,0,0,'66396367dec4e',31,''),(22,2,'thumbnails/16/1024-768-max.png','e4c73c70e8f88896b55d1e4487b6ce4b',20,'1024-768-max.png',8,6,126124,1715037031,1715037031,0,0,'3bfdc34e11030a58086641819e32af8d',27,'SHA1:086cebd754e5c9904bbaa2dc059a6121a14de04c MD5:5c2870efdf5d7801fa3130dadb51fd19 ADLER32:3ba5ac68'),(23,2,'thumbnails/15/1024-768-max.png','1060fc64ed9b200cc422ea90ca5a51d0',21,'1024-768-max.png',8,6,89157,1715037031,1715037031,0,0,'c9024f41246d0b2965d365587fa9dff9',27,'SHA1:d6153622a1cd5f1a4461714093fd79fa1a4b9eff MD5:4ae275ee9657ef18a8d00f2d6531e635 ADLER32:f116b037'),(24,2,'thumbnails/16/32-32.png','7895dc310ca563126ced231d2d052080',20,'32-32.png',8,6,987,1715037031,1715037031,0,0,'76a34f5b9803a4483a7e63213c3a0d77',27,'SHA1:529ad3611d74b84ad207d5c1f014bd69928e2036 MD5:25fe0fca139f84378565e19617d1f068 ADLER32:7b277963'),(25,2,'thumbnails/15/32-32.png','81ec9aa63f517d7c3ac6ebd9e6b30941',21,'32-32.png',8,6,982,1715037031,1715037031,0,0,'845924faf6f3cead722bf87095e13ab6',27,'SHA1:0e9d22e3e841e7edabf4f840c82c0455454c8350 MD5:ac569379f1999910ebc831961daf8573 ADLER32:57a36e2a'),(26,2,'thumbnails/14','ea47b030176b781fc37e3b0ab4c9e953',19,'14',2,1,0,1717654202,1717654202,0,0,'663963680a341',31,''),(27,2,'thumbnails/14/2048-541-max.png','4afa26ad6cd79ced63b6bad7f0b61db4',26,'2048-541-max.png',8,6,211011,1715037032,1715037032,0,0,'97f63bf5ca6bc6257e94d3ea47078d91',27,'SHA1:bb9c2c65c2ce847e1a4074915d3df05526508da8 MD5:accd646949af5def623363377d018dcb ADLER32:01f8618d'),(28,2,'thumbnails/14/32-32.png','4b1f8e25d575269e8ab4ef5f8553eafa',26,'32-32.png',8,6,1005,1715037032,1715037032,0,0,'08711b393ab0a66326dab1b16043253b',27,'SHA1:18f94a96eb39d87194485545237a47990021268e MD5:eb59b9ea79166d417911e3c426e25c46 ADLER32:02918619'),(29,3,'files_external','c270928b685e7946199afdfb898d27ea',17,'files_external',2,1,-1,1715054757,1715054757,0,0,'665fc06d3ccb1',31,''),(30,2,'thumbnails/16/150-150.png','36cbfda9c7c194e418ae8bda4f85be09',20,'150-150.png',8,6,5837,1715056962,1715056962,0,0,'7a3a95ac6941a0418069781d12dcc073',27,'SHA1:cb248fe0e28099fc74fce2a40a27072d88566f8c MD5:13cf02f337acb5cb93a54aa7bf40b2b2 ADLER32:0597f1fc'),(31,2,'thumbnails/14/150-150.png','5cf835d37f7d6b52e1f72f1e033d0330',26,'150-150.png',8,6,6223,1715056962,1715056962,0,0,'3f54644e9985b6f038c84c185e9d6388',27,'SHA1:05d4416116fbf86389ea9c415a6978af9cc37e25 MD5:3439409969cec508ec15a240fc363bf7 ADLER32:e16e969d'),(32,2,'thumbnails/15/150-150.png','93c2c8eef748971acf823ba17ba04edc',21,'150-150.png',8,6,5186,1715056962,1715056962,0,0,'52bb1b1a08f91ece9218776a36c37722',27,'SHA1:7ef5da1f6828f01c69c38cb907478003e8cf1cf9 MD5:4aed90575f59fa908fb00857142b6661 ADLER32:369e74b5'),(33,5,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,17602722,1717449829,1717449828,0,0,'665e346596412',23,''),(34,5,'cache','0fea6a13c52b4d4725368f24b045ca84',33,'cache',2,1,0,1716934918,1716934918,0,0,'665d887239ad6',31,''),(35,5,'files_encryption','171a8829416be21834bef1b79079dde8',33,'files_encryption',2,1,4229,1717360015,1717360015,0,0,'665d88723be4c',31,''),(36,5,'thumbnails','3b8779ba05b8f0aed49650f3ff8beb4b',33,'thumbnails',2,1,3161635,1717449977,1717449977,0,0,'665d88723d7b4',31,''),(37,5,'files','45b963397aa40d4a0063e0d85e4fe7a1',33,'files',2,1,9748303,1717449829,1717360224,0,0,'665e34658c9e8',31,''),(38,5,'files_encryption/OC_DEFAULT_MODULE','75930a339fca24af03c665c2add1433c',35,'OC_DEFAULT_MODULE',2,1,4229,1717360015,1717360015,0,0,'665d887243e8c',31,''),(39,5,'files_encryption/OC_DEFAULT_MODULE/ocuser01.publicKey','8319412b611627e86e5e50e24da4fb03',38,'ocuser01.publicKey',9,3,800,1717360015,1717360015,0,0,'9f65dbf9462ce40b5750bc9bfe2f0f0d',27,''),(40,5,'files_encryption/OC_DEFAULT_MODULE/ocuser01.privateKey','338899ec26e8a8677e0f0771fd574c17',38,'ocuser01.privateKey',9,3,3429,1717360015,1717360015,0,0,'bbf1d467c7fb42784b640918fb5d4a5e',27,''),(41,5,'thumbnails/393','4b790f6db7ca2f4d523e84fe7acc367e',36,'393',2,1,30278,1717360239,1717360239,0,0,'665d887252a58',31,''),(42,5,'thumbnails/399','d6acad33d54102e76f19617ee0bdd752',36,'399',2,1,52754,1717360240,1717360240,0,0,'665d88725543b',31,''),(43,5,'thumbnails/397','11564220701a36ab66b4d5b93583e2f1',36,'397',2,1,499537,1717360240,1717360240,0,0,'665d887256ab6',31,''),(44,5,'thumbnails/389','d2419b9cca565e47ae2b2d833bd2372f',36,'389',2,1,420027,1717360240,1717360240,0,0,'665d8872580f6',31,''),(45,5,'thumbnails/392','2b42edf4f614087d63dfbd1304900a0e',36,'392',2,1,847994,1717360240,1717360240,0,0,'665d8872599bb',31,''),(46,5,'thumbnails/391','77444be6033d1627310031f61d313283',36,'391',2,1,214202,1717360239,1717360239,0,0,'665d88725ba00',31,''),(47,5,'thumbnails/394','053e2462a69f5f31d140944995bdcea9',36,'394',2,1,20430,1717360240,1717360240,0,0,'665d88725dcbc',31,''),(48,5,'thumbnails/395','62499efdc633b78ceb34b97e53f9d38b',36,'395',2,1,41055,1717360240,1717360240,0,0,'665d88725f062',31,''),(49,5,'thumbnails/390','8bf3116c5840b26f320625cace47027b',36,'390',2,1,265427,1717360239,1717360239,0,0,'665d887260453',31,''),(50,5,'thumbnails/396','d75e5fa3f581ff0b86abb8ce58f41253',36,'396',2,1,463129,1717360240,1717360240,0,0,'665d8872617c1',31,''),(51,5,'thumbnails/398','15849d0d7d7a8d7315810bef71e5fe69',36,'398',2,1,306802,1717360240,1717360240,0,0,'665d8872635a1',31,''),(52,5,'thumbnails/393/32-32.png','7565b584450ab1feec42a582a3b0d820',41,'32-32.png',8,6,1466,1717360239,1717360239,0,0,'f30ad71a17e612ff9957fda52cf1c978',27,''),(53,5,'thumbnails/393/450-532-max.png','3e15869f428475792d5d5d2528887159',41,'450-532-max.png',8,6,28812,1717360239,1717360239,0,0,'fe9b114a5fe02e0317046b508db6b3dc',27,''),(54,5,'thumbnails/399/32-32.png','13700302a7a9669b9c433199b8949f56',42,'32-32.png',8,6,1605,1717360240,1717360240,0,0,'7928f6ca6f813d6c1f7ab312dee0ef67',27,''),(55,5,'thumbnails/399/389-363-max.png','53f83cf758dbc84cb9994a63355903f4',42,'389-363-max.png',8,6,51149,1717360240,1717360240,0,0,'ac1538213939666a40441dce1ee7d039',27,''),(56,5,'thumbnails/397/32-32.png','32ca26b39941d1694f6fbb9fdcd3dc8a',43,'32-32.png',8,6,2814,1717360240,1717360240,0,0,'0b9d8eb82d5c51d6141e50ba63633d86',27,''),(57,5,'thumbnails/397/760-468-max.png','984be9ade60f50eb3a2ca4939afc95fe',43,'760-468-max.png',8,6,496723,1717360240,1717360240,0,0,'d8dd56793908ca9252adb73bbf815ab2',27,''),(58,5,'thumbnails/389/969-723-max.png','a10bd01e7875c2aada19bf5410a10be3',44,'969-723-max.png',8,6,418028,1717360240,1717360240,0,0,'38e0015fa4948595d41567b0809101ff',27,''),(59,5,'thumbnails/389/32-32.png','b5423e08af8120b587a6a0606bbf6ad5',44,'32-32.png',8,6,1999,1717360240,1717360240,0,0,'bf89c5895e2b0730a1fb694c2ac864b6',27,''),(60,5,'thumbnails/392/32-32.png','5dfdfe78e8e5739f6e70c7336a7e543a',45,'32-32.png',8,6,2164,1717360240,1717360240,0,0,'5527c1b223ed3282f14a40b7d8fe5c2f',27,''),(61,5,'thumbnails/392/791-528-max.png','30462385e3e962671319c2437f9feea7',45,'791-528-max.png',8,6,845830,1717360240,1717360240,0,0,'4984a09f6f7c8a44f5393b0229c6338d',27,''),(62,5,'thumbnails/391/32-32.png','1e6cbb3b753cfc9016f51f2464710c70',46,'32-32.png',8,6,2661,1717360239,1717360239,0,0,'3302bf1ec3020be6f5990001087f9c56',27,''),(63,5,'thumbnails/391/377-452-max.png','4ba5c6f0c11d5be2595a18fc87afd8b2',46,'377-452-max.png',8,6,211541,1717360239,1717360239,0,0,'ba55a1e1761cc1fa751ef760e0a91c93',27,''),(64,5,'thumbnails/394/32-32.png','3c577465074c2cc8b9ce6a64877f8629',47,'32-32.png',8,6,1686,1717360240,1717360240,0,0,'94347bf3d80d9d5cc96fcac4bf193db9',27,''),(65,5,'thumbnails/394/383-458-max.png','143820c63de6e1ffa4e03e84be88b373',47,'383-458-max.png',8,6,18744,1717360240,1717360240,0,0,'9fe20ce7eb2e3860c08fe54b3bf78fda',27,''),(66,5,'thumbnails/395/32-32.png','24b99a1485b177d5aed6acd9f5fcf212',48,'32-32.png',8,6,1823,1717360240,1717360240,0,0,'3d074595cedc4ab7f4acadb414e88b28',27,''),(67,5,'thumbnails/395/429-530-max.png','f834ccf2522bcb4e04cb29415f892d38',48,'429-530-max.png',8,6,39232,1717360240,1717360240,0,0,'f6b6d7377ef2ccef7d65d23dd928e48b',27,''),(68,5,'thumbnails/390/32-32.png','375ef1359923c62e466f0194537cdc7f',49,'32-32.png',8,6,2467,1717360239,1717360239,0,0,'fd8d79752cd9b83926c3716d7b992aaf',27,''),(69,5,'thumbnails/390/546-464-max.png','8319dc688a46553fca2c7f01fce3e41e',49,'546-464-max.png',8,6,262960,1717360239,1717360239,0,0,'d2153e59f300789ec479aac483680803',27,''),(70,5,'thumbnails/396/32-32.png','6a91ba621d7787eab71189ebf3119543',50,'32-32.png',8,6,2937,1717360240,1717360240,0,0,'dfda8f4d56f6be9046b9cc06e5929640',27,''),(71,5,'thumbnails/396/722-445-max.png','f4252a74cbcd37c24f4b4494a90f2b9a',50,'722-445-max.png',8,6,460192,1717360240,1717360240,0,0,'94f39c52fe03da5e7fa82f93d86397e3',27,''),(72,5,'thumbnails/398/524-625-max.png','c6be8c0f005503beaf67511533968ad9',51,'524-625-max.png',8,6,304201,1717360240,1717360240,0,0,'5bd0781490eb1fc4a332630f76a2f36e',27,''),(73,5,'thumbnails/398/32-32.png','98eb40c7a8a6f52dc8d4cc34c67eeca3',51,'32-32.png',8,6,2601,1717360240,1717360240,0,0,'e0a33d5fc36e8498c3fd3f7948628bc7',27,''),(74,5,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',37,'Documents',2,1,5095975,1717449828,1717360224,0,0,'665e346487a8a',31,''),(75,5,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',37,'Learn more about ownCloud',2,1,3640864,1717449829,1716934919,0,0,'665e34653c2c2',31,''),(76,5,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',37,'Photos',2,1,1011464,1717449829,1716934919,0,0,'665e34658c9e8',31,''),(77,5,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',74,'Example.odt',4,3,36227,1717449828,1717449828,0,0,'7f26d5ecc890cb2a519ab82cc2072cfc',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(78,5,'files/Documents/MYPRIVATEDOCs','dfe5049d8ecc649e7e319bc5a1172d79',74,'MYPRIVATEDOCs',2,1,5059748,1717405810,1717360057,0,0,'665d88730f112',31,''),(79,5,'files/Documents/MYPRIVATEDOCs/motherboard1.png','a31071cf1efc2fea8a545a5028d88bc5',78,'motherboard1.png',8,6,1892460,1714420726,1714420726,0,0,'4458fc2cf8d97146b63d1b7493f29a9e',27,''),(80,5,'files/Documents/MYPRIVATEDOCs/file3.png','a15f275f23e89629709a18f04111d4f0',78,'file3.png',8,6,31951,1717356251,1717356251,0,0,'ee02a88471429a51f39d4ebdd0c6f35c',27,'SHA1:24c3ebad5e26d2fd800c6b433d9827dda9e33fc2 MD5:e9f4a6ecb1245f081814b35eea591016 ADLER32:3c7ea885'),(81,5,'files/Documents/MYPRIVATEDOCs/file1.png','a2bf581f069694af0aa89f2737a00c73',78,'file1.png',8,6,309373,1717356207,1717356207,0,0,'5832fb8ce833521b35597dbc26162d6c',27,''),(82,5,'files/Documents/MYPRIVATEDOCs/chap1.PNG','ae41e90a93e7933fda2dc3097230a3ae',78,'chap1.PNG',8,6,325247,1714584371,1714584371,0,0,'6ddfdf16a03ab7514cea94991ece7664',27,''),(83,5,'files/Documents/MYPRIVATEDOCs/file4.png','d2f283ef382b842c309655e2e0f87110',78,'file4.png',8,6,19996,1717356268,1717356268,0,0,'a6aa673516bc6f2d1cd5398751fafd43',27,'SHA1:3adaaf16b04e1892d1d029a14f5e3aac1c987c2b MD5:e59d466f10130c83d08f8834d919cd1e ADLER32:cffbd7e9'),(84,5,'files/Documents/MYPRIVATEDOCs/bentley.PNG','077ccd940abb765471698386e2d36eda',78,'bentley.PNG',8,6,567157,1714581672,1714581672,0,0,'def3924636f6e3448e63093c73530943',27,''),(85,5,'files/Documents/MYPRIVATEDOCs/file2.png','fadb23e4ca551d126a787c3ec42d9fc4',78,'file2.png',8,6,1050024,1717356223,1717356223,0,0,'d5ca598adcc027f0a48132d284b4cefa',27,''),(86,5,'files/Documents/MYPRIVATEDOCs/tempsnip.png','7e41715f33c490c3596bdfa10deb7706',78,'tempsnip.png',8,6,49491,1706606622,1706606622,0,0,'5837abe5e24c266b96283c00528df5cb',27,'SHA1:0a2fb652ffd6896633f48f3b751830ed0dc755f4 MD5:269057380d35fe2d7856038c34bbe509 ADLER32:760389f6'),(87,5,'files/Documents/MYPRIVATEDOCs/OE2.png','cd1106c1b8a59d2b191d64ff9f0ea828',78,'OE2.png',8,6,298503,1695158267,1695158267,0,0,'d4c28077ab1ef131ad3c7c650a0c2a36',27,''),(88,5,'files/Documents/MYPRIVATEDOCs/motherboard.PNG','5087de0cfcfe9ab189e277c1e8a6b17c',78,'motherboard.PNG',8,6,473985,1714420782,1714420782,0,0,'64a1e621d91d27bce19558002d12b988',27,''),(89,5,'files/Documents/MYPRIVATEDOCs/file5.png','c7d5fa796cd5aa5d648a1b0ad07bb759',78,'file5.png',8,6,41561,1717356277,1717356277,0,0,'0a866589ffd7b3a9f255bdd168ccdd9f',27,'SHA1:dddf4b713d8bbe69e6a4b46dd3d191593ef89201 MD5:3b0dd8474c8d395ac4e1a336286050a8 ADLER32:8b4a2d5d'),(90,5,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',75,'ownCloud Subscription Overview.pdf',5,3,1611431,1717449828,1717449828,0,0,'c52ab200f4d2838228995bdf9974a702',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(91,5,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',75,'Share files efficiently in your company.pdf',5,3,303237,1717449828,1717449828,0,0,'699d816781cfaf8534aa8f6ce850f780',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(92,5,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',75,'Introducing ownCloud.pdf',5,3,238300,1717449829,1717449829,0,0,'592c8f7038a66a9e334c8bc560f9e24f',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(93,5,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',75,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717449829,1717449829,0,0,'71a167dfc97b59b36884832b37ce23ec',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(94,5,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',75,'Safely leverage Microsoft Office.pdf',5,3,314348,1717449829,1717449829,0,0,'956c25c564ff27b23ba4356a7efa14ce',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(95,5,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',75,'Keep your files safe with ownCloud.pdf',5,3,755022,1717449829,1717449829,0,0,'4edd74447b9194f99525d83990bddd12',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(96,5,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',76,'Lake-Constance.jpg',7,6,538942,1717449829,1717449829,0,0,'76f3b0989fdf59a990d6b440691cbfcd',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(97,5,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',76,'Teotihuacan.jpg',7,6,228789,1717449829,1717449829,0,0,'b886bd7d030e7b5ba83a752283210de3',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(98,5,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',76,'Portugal.jpg',7,6,243733,1717449829,1717449829,0,0,'c68ea21ce08073ec9e55b16ef2acc7ca',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(99,9,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405811,1716936189,0,0,'665d88736afbf',23,''),(100,9,'cache','0fea6a13c52b4d4725368f24b045ca84',99,'cache',2,1,0,1716936189,1716936189,0,0,'665d88733f611',31,''),(101,9,'files','45b963397aa40d4a0063e0d85e4fe7a1',99,'files',2,1,4688555,1717405811,1716936190,0,0,'665d88736afbf',31,''),(102,9,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',101,'Documents',2,1,36227,1717405811,1716936189,0,0,'665d88736afbf',31,''),(103,9,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',101,'Learn more about ownCloud',2,1,3640864,1717405811,1716936190,0,0,'665d88736afbf',31,''),(104,9,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',101,'Photos',2,1,1011464,1717405811,1716936190,0,0,'665d88736afbf',31,''),(105,9,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',102,'Example.odt',4,3,36227,1716936189,1716936189,0,0,'3444fd69720a5734d550be80b8f491a7',27,''),(106,9,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',103,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936189,1716936189,0,0,'a9c80f553b72bde94a6d471ef70b0898',27,''),(107,9,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',103,'Share files efficiently in your company.pdf',5,3,303237,1716936189,1716936189,0,0,'791cc4d682c9ad1093fb44133cfd0b33',27,''),(108,9,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',103,'Introducing ownCloud.pdf',5,3,238300,1716936190,1716936190,0,0,'e32e0e43d9e94b587b2488e8f338b9d5',27,''),(109,9,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',103,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936190,1716936190,0,0,'5fb8b81f3c525d468a954e64ebff1449',27,''),(110,9,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',103,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936190,1716936190,0,0,'df5bbce7f773d09bbeeff1d8d95a3e4f',27,''),(111,9,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',103,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936190,1716936190,0,0,'67c908bac79315c0da4b3b7211fbd732',27,''),(112,9,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',104,'Lake-Constance.jpg',7,6,538942,1716936190,1716936190,0,0,'4f0b1055cc4b4337f1157e88a053a26d',27,''),(113,9,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',104,'Teotihuacan.jpg',7,6,228789,1716936190,1716936190,0,0,'e5c7430bafffe8727e1f4d7dfa543a0f',27,''),(114,9,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',104,'Portugal.jpg',7,6,243733,1716936190,1716936190,0,0,'091048cb2e404530e15593442aa482f4',27,''),(115,11,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,9381352,1717445718,1717445717,0,0,'665e245629792',23,''),(116,11,'cache','0fea6a13c52b4d4725368f24b045ca84',115,'cache',2,1,0,1716936213,1716936213,0,0,'665d88737ef64',31,''),(117,11,'files_encryption','171a8829416be21834bef1b79079dde8',115,'files_encryption',2,1,4229,1717361408,1717361408,0,0,'665d8873803a2',31,''),(118,11,'thumbnails','3b8779ba05b8f0aed49650f3ff8beb4b',115,'thumbnails',2,1,0,1717445719,1717445719,0,0,'665d887382255',31,''),(119,11,'files','45b963397aa40d4a0063e0d85e4fe7a1',115,'files',2,1,4688568,1717445718,1717361419,0,0,'665e245620530',31,''),(120,11,'files_encryption/OC_DEFAULT_MODULE','75930a339fca24af03c665c2add1433c',117,'OC_DEFAULT_MODULE',2,1,4229,1717361408,1717361408,0,0,'665d88738939e',31,''),(121,11,'files_encryption/OC_DEFAULT_MODULE/ocuser04.publicKey','34fd80a1d59284d7ab361f0389dc1637',120,'ocuser04.publicKey',9,3,800,1717361408,1717361408,0,0,'2ad80a37e8e90adbfb4c2d29ee7cbc49',27,''),(122,11,'files_encryption/OC_DEFAULT_MODULE/ocuser04.privateKey','9f5bafdad40c40bc8ca477a955db157c',120,'ocuser04.privateKey',9,3,3429,1717361448,1717361448,0,0,'33bddb77c8dac7850e283f14771d0c02',27,''),(126,11,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',119,'Documents',2,1,36227,1717445717,1716936214,0,0,'665e24551fcf1',31,''),(127,11,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',119,'Learn more about ownCloud',2,1,3640864,1717445717,1716936215,0,0,'665e2455c9853',31,''),(128,11,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',119,'Photos',2,1,1011464,1717445718,1716936215,0,0,'665e245620530',31,''),(129,11,'files/mynewcred.txt','4c65eb144ef9ddb4963ca19d2bcc67d3',119,'mynewcred.txt',11,10,13,1717361429,1717361429,0,0,'035537bef4c4d078502d2d0b72498e9b',27,'SHA1:5ad905bc5977015d193c329d225261fa7556c4c5 MD5:947b01f10f6da5e38647b4293b3caa99 ADLER32:20090428'),(130,11,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',126,'Example.odt',4,3,36227,1717445717,1717445717,0,0,'a9d7a22673f5bd467534faf4b794a7a1',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(131,11,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',127,'ownCloud Subscription Overview.pdf',5,3,1611431,1717445717,1717445717,0,0,'279f9de7bcc57e3f861a00ff72876536',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(132,11,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',127,'Share files efficiently in your company.pdf',5,3,303237,1717445717,1717445717,0,0,'587f84169bf28f2c5408ce4509be30a2',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(133,11,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',127,'Introducing ownCloud.pdf',5,3,238300,1717445717,1717445717,0,0,'1a6cfd30295ae2d9f8cf28eb9cdb8278',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(134,11,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',127,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717445717,1717445717,0,0,'7957e290afa7315201f4837fbff04f06',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(135,11,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',127,'Safely leverage Microsoft Office.pdf',5,3,314348,1717445717,1717445717,0,0,'1ebdb885cc5a1a6373ee07ba06576b14',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(136,11,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',127,'Keep your files safe with ownCloud.pdf',5,3,755022,1717445717,1717445717,0,0,'3165133968c09c56db08852d6c20787d',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(137,11,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',128,'Lake-Constance.jpg',7,6,538942,1717445718,1717445718,0,0,'6128922eb07cd9f1b86e893ec7499e25',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(138,11,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',128,'Teotihuacan.jpg',7,6,228789,1717445718,1717445718,0,0,'75b889880cf509883a9aee0a7ad621e9',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(139,11,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',128,'Portugal.jpg',7,6,243733,1717445718,1717445718,0,0,'be4b310a1600badbcb8ef3dde7e3744c',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(140,13,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405812,1716936232,0,0,'665d88740dd4e',23,''),(141,13,'cache','0fea6a13c52b4d4725368f24b045ca84',140,'cache',2,1,0,1716936232,1716936232,0,0,'665d8873d3e30',31,''),(142,13,'files','45b963397aa40d4a0063e0d85e4fe7a1',140,'files',2,1,4688555,1717405812,1716936233,0,0,'665d88740dd4e',31,''),(143,13,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',142,'Documents',2,1,36227,1717405811,1716936232,0,0,'665d88740dd4e',31,''),(144,13,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',142,'Learn more about ownCloud',2,1,3640864,1717405811,1716936233,0,0,'665d88740dd4e',31,''),(145,13,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',142,'Photos',2,1,1011464,1717405812,1716936233,0,0,'665d88740dd4e',31,''),(146,13,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',143,'Example.odt',4,3,36227,1716936232,1716936232,0,0,'6f46a251eda009fcf800391750bc9c41',27,''),(147,13,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',144,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936232,1716936232,0,0,'93e83a1c76c6897f4f93f5cd71f731ae',27,''),(148,13,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',144,'Share files efficiently in your company.pdf',5,3,303237,1716936232,1716936232,0,0,'9e9901427ca8b509e5f61c3cf6743c56',27,''),(149,13,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',144,'Introducing ownCloud.pdf',5,3,238300,1716936232,1716936232,0,0,'2816a987e08c589bab7cf73b57417b79',27,''),(150,13,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',144,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936232,1716936232,0,0,'5834fc8d827489dc94d06ce05f7033b6',27,''),(151,13,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',144,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936233,1716936233,0,0,'5dd604248f6771aea724c60de73e9a52',27,''),(152,13,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',144,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936233,1716936233,0,0,'2696c5b6016d3ca4aefe26882c2d4efe',27,''),(153,13,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',145,'Lake-Constance.jpg',7,6,538942,1716936233,1716936233,0,0,'d671cae69e03ed4525a24e43cb151487',27,''),(154,13,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',145,'Teotihuacan.jpg',7,6,228789,1716936233,1716936233,0,0,'c4ec9b6a5176087da0c80c0e47dbaf31',27,''),(155,13,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',145,'Portugal.jpg',7,6,243733,1716936233,1716936233,0,0,'46ec929a1452e8c35ac8a83451334cbf',27,''),(156,15,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405812,1716936247,0,0,'665d887453f6d',23,''),(157,15,'cache','0fea6a13c52b4d4725368f24b045ca84',156,'cache',2,1,0,1716936247,1716936247,0,0,'665d887422977',31,''),(158,15,'files','45b963397aa40d4a0063e0d85e4fe7a1',156,'files',2,1,4688555,1717405812,1716936248,0,0,'665d887453f6d',31,''),(159,15,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',158,'Documents',2,1,36227,1717405812,1716936247,0,0,'665d887453f6d',31,''),(160,15,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',158,'Learn more about ownCloud',2,1,3640864,1717405812,1716936248,0,0,'665d887453f6d',31,''),(161,15,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',158,'Photos',2,1,1011464,1717405812,1716936248,0,0,'665d887453f6d',31,''),(162,15,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',159,'Example.odt',4,3,36227,1716936247,1716936247,0,0,'e85c1b9ba74cd14bbb3e41ea1b343773',27,''),(163,15,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',160,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936247,1716936247,0,0,'774a835f25de57fa70a06dedbac7c96e',27,''),(164,15,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',160,'Share files efficiently in your company.pdf',5,3,303237,1716936247,1716936247,0,0,'b9a9a664632ed1bc1e14735d4776dcd1',27,''),(165,15,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',160,'Introducing ownCloud.pdf',5,3,238300,1716936248,1716936248,0,0,'05ec06e9ae86ce1aa570c93a9f86c741',27,''),(166,15,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',160,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936248,1716936248,0,0,'fb84a9d31279e2a84fda5c39740d0371',27,''),(167,15,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',160,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936248,1716936248,0,0,'d002fa28d312e8f5094ace60dde8722b',27,''),(168,15,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',160,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936248,1716936248,0,0,'c5766587a3a4a78cba4aa88a89b662cc',27,''),(169,15,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',161,'Lake-Constance.jpg',7,6,538942,1716936248,1716936248,0,0,'71f268f729d6c9c5956d5d60b5e926b8',27,''),(170,15,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',161,'Teotihuacan.jpg',7,6,228789,1716936248,1716936248,0,0,'7a6c8ee172689af9042f405611da6cf6',27,''),(171,15,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',161,'Portugal.jpg',7,6,243733,1716936248,1716936248,0,0,'4c11580624f8e1769189838f7bf423bf',27,''),(172,17,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4692784,1717405812,1717360396,0,0,'665d8874af6a6',23,''),(173,17,'cache','0fea6a13c52b4d4725368f24b045ca84',172,'cache',2,1,0,1716936263,1716936263,0,0,'665d88746886f',31,''),(174,17,'files_encryption','171a8829416be21834bef1b79079dde8',172,'files_encryption',2,1,4229,1717360396,1717360396,0,0,'665d88746bf61',31,''),(175,17,'files','45b963397aa40d4a0063e0d85e4fe7a1',172,'files',2,1,4688555,1717405812,1716936264,0,0,'665d8874af6a6',31,''),(176,17,'files_encryption/OC_DEFAULT_MODULE','75930a339fca24af03c665c2add1433c',174,'OC_DEFAULT_MODULE',2,1,4229,1717360396,1717360396,0,0,'665d887475d90',31,''),(177,17,'files_encryption/OC_DEFAULT_MODULE/ocuser07.publicKey','8ccb5c008237abe77855bbec91e973f5',176,'ocuser07.publicKey',9,3,800,1717360396,1717360396,0,0,'e6e169f67402cab6e660141934f0dbb2',27,''),(178,17,'files_encryption/OC_DEFAULT_MODULE/ocuser07.privateKey','49d09a95e98463498d63cf20f758975a',176,'ocuser07.privateKey',9,3,3429,1717360412,1717360412,0,0,'f99b9ed6f45690969ebfc6cbf62868e8',27,''),(179,17,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',175,'Documents',2,1,36227,1717405812,1716936263,0,0,'665d8874af6a6',31,''),(180,17,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',175,'Learn more about ownCloud',2,1,3640864,1717405812,1716936264,0,0,'665d8874af6a6',31,''),(181,17,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',175,'Photos',2,1,1011464,1717405812,1716936264,0,0,'665d8874af6a6',31,''),(182,17,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',179,'Example.odt',4,3,36227,1716936263,1716936263,0,0,'6c889af46c5bcf44d36526b12af73183',27,''),(183,17,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',180,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936263,1716936263,0,0,'8e2dc17474ea5ca840824c7439d370c9',27,''),(184,17,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',180,'Share files efficiently in your company.pdf',5,3,303237,1716936263,1716936263,0,0,'7938a740674bd5a8af7d944c3850089c',27,''),(185,17,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',180,'Introducing ownCloud.pdf',5,3,238300,1716936263,1716936263,0,0,'c8dbdb010d25dfd45db0fd77583b9733',27,''),(186,17,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',180,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936263,1716936263,0,0,'9dff9506736b6923c97a2f06a1a3afbd',27,''),(187,17,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',180,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936264,1716936264,0,0,'5a05b0f8d521a16634b03cb543b0e86f',27,''),(188,17,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',180,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936264,1716936264,0,0,'2476b57bbb51b05998b0199058b7d8df',27,''),(189,17,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',181,'Lake-Constance.jpg',7,6,538942,1716936264,1716936264,0,0,'304741617b3d92f481584df5aabc5ff1',27,''),(190,17,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',181,'Teotihuacan.jpg',7,6,228789,1716936264,1716936264,0,0,'28ed9b71e2824cd540a893b806ccea1e',27,''),(191,17,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',181,'Portugal.jpg',7,6,243733,1716936264,1716936264,0,0,'3b41272d862836341dc8153f77467c85',27,''),(192,19,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405813,1716935963,0,0,'665d8875095b9',23,''),(193,19,'cache','0fea6a13c52b4d4725368f24b045ca84',192,'cache',2,1,0,1716935963,1716935963,0,0,'665d8874c9f50',31,''),(194,19,'files','45b963397aa40d4a0063e0d85e4fe7a1',192,'files',2,1,4688555,1717405813,1716935964,0,0,'665d8875095b9',31,''),(195,19,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',194,'Documents',2,1,36227,1717405812,1716935963,0,0,'665d8875095b9',31,''),(196,19,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',194,'Learn more about ownCloud',2,1,3640864,1717405812,1716935964,0,0,'665d8875095b9',31,''),(197,19,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',194,'Photos',2,1,1011464,1717405813,1716935965,0,0,'665d8875095b9',31,''),(198,19,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',195,'Example.odt',4,3,36227,1716935963,1716935963,0,0,'b036a30686d449ad0ef02e193b7a1ec6',27,''),(199,19,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',196,'ownCloud Subscription Overview.pdf',5,3,1611431,1716935964,1716935964,0,0,'0f46fc4cd4d10f84212d476d949e8c3d',27,''),(200,19,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',196,'Share files efficiently in your company.pdf',5,3,303237,1716935964,1716935964,0,0,'7c920325d70905bba2211834de9d8cd2',27,''),(201,19,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',196,'Introducing ownCloud.pdf',5,3,238300,1716935964,1716935964,0,0,'c5be148a121783167f931550b6b0925d',27,''),(202,19,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',196,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716935964,1716935964,0,0,'3a1099bc2c80f7d85d8d189b8092a353',27,''),(203,19,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',196,'Safely leverage Microsoft Office.pdf',5,3,314348,1716935964,1716935964,0,0,'290d00304e4915780f1a1b55a972eb95',27,''),(204,19,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',196,'Keep your files safe with ownCloud.pdf',5,3,755022,1716935964,1716935964,0,0,'90a9df11d378c6855308eed704dbdd45',27,''),(205,19,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',197,'Lake-Constance.jpg',7,6,538942,1716935964,1716935964,0,0,'223b177e8c9f3026b882e029686b795f',27,''),(206,19,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',197,'Teotihuacan.jpg',7,6,228789,1716935965,1716935965,0,0,'9877ac22709b230b22027245374c16ac',27,''),(207,19,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',197,'Portugal.jpg',7,6,243733,1716935965,1716935965,0,0,'a8125529dfb251913a89eb262edaafc4',27,''),(208,21,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405813,1716936280,0,0,'665d88754f837',23,''),(209,21,'cache','0fea6a13c52b4d4725368f24b045ca84',208,'cache',2,1,0,1716936280,1716936280,0,0,'665d887521122',31,''),(210,21,'files','45b963397aa40d4a0063e0d85e4fe7a1',208,'files',2,1,4688555,1717405813,1716936281,0,0,'665d88754f837',31,''),(211,21,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',210,'Documents',2,1,36227,1717405813,1716936280,0,0,'665d88754f837',31,''),(212,21,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',210,'Learn more about ownCloud',2,1,3640864,1717405813,1716936281,0,0,'665d88754f837',31,''),(213,21,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',210,'Photos',2,1,1011464,1717405813,1716936281,0,0,'665d88754f837',31,''),(214,21,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',211,'Example.odt',4,3,36227,1716936280,1716936280,0,0,'83643fb510e6673cb34008912c792791',27,''),(215,21,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',212,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936280,1716936280,0,0,'6e331dd21a6a9d715cb8743b357a1e20',27,''),(216,21,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',212,'Share files efficiently in your company.pdf',5,3,303237,1716936280,1716936280,0,0,'72f95ada97122ce02b33208761f8ed66',27,''),(217,21,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',212,'Introducing ownCloud.pdf',5,3,238300,1716936281,1716936281,0,0,'2a18a60a8694406380040bf138f840ce',27,''),(218,21,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',212,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936281,1716936281,0,0,'037fa5d0df34ffb20d557337de3f82c5',27,''),(219,21,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',212,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936281,1716936281,0,0,'7087da0cb57dcc6fb3f105064516f750',27,''),(220,21,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',212,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936281,1716936281,0,0,'06f900f1d2b1ba98a8bdeadcae4886da',27,''),(221,21,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',213,'Lake-Constance.jpg',7,6,538942,1716936281,1716936281,0,0,'68adeff47c7d2012c3072afd15274dd5',27,''),(222,21,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',213,'Teotihuacan.jpg',7,6,228789,1716936281,1716936281,0,0,'84b4fa1a93ebb92e7251e381896e1aae',27,''),(223,21,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',213,'Portugal.jpg',7,6,243733,1716936281,1716936281,0,0,'599041fb412e1e9aef39300b03c83b06',27,''),(224,23,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405813,1716936306,0,0,'665d8875924ab',23,''),(225,23,'cache','0fea6a13c52b4d4725368f24b045ca84',224,'cache',2,1,0,1716936306,1716936306,0,0,'665d887565da1',31,''),(226,23,'files','45b963397aa40d4a0063e0d85e4fe7a1',224,'files',2,1,4688555,1717405813,1716936307,0,0,'665d8875924ab',31,''),(227,23,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',226,'Documents',2,1,36227,1717405813,1716936306,0,0,'665d8875924ab',31,''),(228,23,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',226,'Learn more about ownCloud',2,1,3640864,1717405813,1716936306,0,0,'665d8875924ab',31,''),(229,23,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',226,'Photos',2,1,1011464,1717405813,1716936307,0,0,'665d8875924ab',31,''),(230,23,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',227,'Example.odt',4,3,36227,1716936306,1716936306,0,0,'5672936c531075904393d4f6d1bcbd4a',27,''),(231,23,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',228,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936306,1716936306,0,0,'cafd0cbc8e6dead8dcf80241c22e8f94',27,''),(232,23,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',228,'Share files efficiently in your company.pdf',5,3,303237,1716936306,1716936306,0,0,'ad7f56c0425150df95d16fc6d7073b68',27,''),(233,23,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',228,'Introducing ownCloud.pdf',5,3,238300,1716936306,1716936306,0,0,'49c4da94eab37f94f16fc3393687f982',27,''),(234,23,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',228,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936306,1716936306,0,0,'86fa3a603f4e3957caa354dd796b5d69',27,''),(235,23,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',228,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936306,1716936306,0,0,'5dfd37550bb70dfe6c28e75703101b8f',27,''),(236,23,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',228,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936307,1716936307,0,0,'8e92918f4973f64637027b6aeebe2ef5',27,''),(237,23,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',229,'Lake-Constance.jpg',7,6,538942,1716936307,1716936307,0,0,'c48161efa9bf44e8388c0d9de4a41983',27,''),(238,23,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',229,'Teotihuacan.jpg',7,6,228789,1716936307,1716936307,0,0,'409bc51d4a99aecf499c4d43d5f0348b',27,''),(239,23,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',229,'Portugal.jpg',7,6,243733,1716936307,1716936307,0,0,'84cf74e10e583be02505d08e8fd35457',27,''),(240,25,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405813,1716936321,0,0,'665d8875d1d8f',23,''),(241,25,'cache','0fea6a13c52b4d4725368f24b045ca84',240,'cache',2,1,0,1716936321,1716936321,0,0,'665d8875a62e3',31,''),(242,25,'files','45b963397aa40d4a0063e0d85e4fe7a1',240,'files',2,1,4688555,1717405813,1716936322,0,0,'665d8875d1d8f',31,''),(243,25,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',242,'Documents',2,1,36227,1717405813,1716936321,0,0,'665d8875d1d8f',31,''),(244,25,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',242,'Learn more about ownCloud',2,1,3640864,1717405813,1716936322,0,0,'665d8875d1d8f',31,''),(245,25,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',242,'Photos',2,1,1011464,1717405813,1716936322,0,0,'665d8875d1d8f',31,''),(246,25,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',243,'Example.odt',4,3,36227,1716936321,1716936321,0,0,'a6f308202386536d6d30350304036989',27,''),(247,25,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',244,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936321,1716936321,0,0,'54f3abea15f83c3894d2fceb62c5c444',27,''),(248,25,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',244,'Share files efficiently in your company.pdf',5,3,303237,1716936321,1716936321,0,0,'a60de4f71657b5ed2da14137e6369522',27,''),(249,25,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',244,'Introducing ownCloud.pdf',5,3,238300,1716936321,1716936321,0,0,'6c50dddf5e025c651f247afc5603f9be',27,''),(250,25,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',244,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936321,1716936321,0,0,'8156f87abb9590cbc2464b71b5242df5',27,''),(251,25,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',244,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936322,1716936322,0,0,'ff48264c41a5c3ed3c394c1b1b7b274b',27,''),(252,25,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',244,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936322,1716936322,0,0,'fff5ca0326f941ee614856f5bca7d888',27,''),(253,25,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',245,'Lake-Constance.jpg',7,6,538942,1716936322,1716936322,0,0,'84aded95c281b20782895f715c372cb9',27,''),(254,25,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',245,'Teotihuacan.jpg',7,6,228789,1716936322,1716936322,0,0,'e68be8b4649f1f3d90207b9f15658fab',27,''),(255,25,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',245,'Portugal.jpg',7,6,243733,1716936322,1716936322,0,0,'fdafc2152bd75c7ff448049f402d0da1',27,''),(256,27,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405814,1716936348,0,0,'665d88762268f',23,''),(257,27,'cache','0fea6a13c52b4d4725368f24b045ca84',256,'cache',2,1,0,1716936348,1716936348,0,0,'665d8875eb940',31,''),(258,27,'files','45b963397aa40d4a0063e0d85e4fe7a1',256,'files',2,1,4688555,1717405814,1716936349,0,0,'665d88762268f',31,''),(259,27,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',258,'Documents',2,1,36227,1717405814,1716936348,0,0,'665d88762268f',31,''),(260,27,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',258,'Learn more about ownCloud',2,1,3640864,1717405814,1716936349,0,0,'665d88762268f',31,''),(261,27,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',258,'Photos',2,1,1011464,1717405814,1716936349,0,0,'665d88762268f',31,''),(262,27,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',259,'Example.odt',4,3,36227,1716936348,1716936348,0,0,'19273e2a1b0d03ce077463f80f6e9a1d',27,''),(263,27,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',260,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936348,1716936348,0,0,'17ea20857d71655d6a65638e1f65646b',27,''),(264,27,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',260,'Share files efficiently in your company.pdf',5,3,303237,1716936348,1716936348,0,0,'a06f9449575882ee8f2b076bde776dd1',27,''),(265,27,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',260,'Introducing ownCloud.pdf',5,3,238300,1716936348,1716936348,0,0,'f3eea4c8b8764c3b3a545ffb5e9f462c',27,''),(266,27,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',260,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936348,1716936348,0,0,'9b83feeb54d69f94cf561ffd23ee3fe0',27,''),(267,27,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',260,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936349,1716936349,0,0,'bd820f00b7a286df0c27a621e009d276',27,''),(268,27,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',260,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936349,1716936349,0,0,'4046ac06744ad7c569afc13a1a5f813a',27,''),(269,27,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',261,'Lake-Constance.jpg',7,6,538942,1716936349,1716936349,0,0,'bd74ee46424259d65784f365171ef806',27,''),(270,27,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',261,'Teotihuacan.jpg',7,6,228789,1716936349,1716936349,0,0,'b598dbc50da30e0b5aa3e615cb7225d3',27,''),(271,27,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',261,'Portugal.jpg',7,6,243733,1716936349,1716936349,0,0,'488ff5238e4856ecdaaec619d7594acf',27,''),(272,29,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405814,1716936365,0,0,'665d88766e5fd',23,''),(273,29,'cache','0fea6a13c52b4d4725368f24b045ca84',272,'cache',2,1,0,1716936365,1716936365,0,0,'665d887636506',31,''),(274,29,'files','45b963397aa40d4a0063e0d85e4fe7a1',272,'files',2,1,4688555,1717405814,1716936366,0,0,'665d88766e5fd',31,''),(275,29,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',274,'Documents',2,1,36227,1717405814,1716936365,0,0,'665d88766e5fd',31,''),(276,29,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',274,'Learn more about ownCloud',2,1,3640864,1717405814,1716936366,0,0,'665d88766e5fd',31,''),(277,29,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',274,'Photos',2,1,1011464,1717405814,1716936366,0,0,'665d88766e5fd',31,''),(278,29,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',275,'Example.odt',4,3,36227,1716936365,1716936365,0,0,'ad602bc919b41833fd9831886cb52e94',27,''),(279,29,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',276,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936365,1716936365,0,0,'38b46a79b7cb5e5764c815df9d11f01c',27,''),(280,29,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',276,'Share files efficiently in your company.pdf',5,3,303237,1716936366,1716936366,0,0,'225880c42afe1a156d79c0311d23b444',27,''),(281,29,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',276,'Introducing ownCloud.pdf',5,3,238300,1716936366,1716936366,0,0,'d8a4d83e6ccd54cf4f4b432ae6108fdd',27,''),(282,29,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',276,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936366,1716936366,0,0,'c8f265225289c8b5aa8867acf0a00b13',27,''),(283,29,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',276,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936366,1716936366,0,0,'5fc79fe6850e977600c4ea5d24c7c923',27,''),(284,29,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',276,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936366,1716936366,0,0,'5e8e93e7f1eed819fef1194b9ca8abe7',27,''),(285,29,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',277,'Lake-Constance.jpg',7,6,538942,1716936366,1716936366,0,0,'a584c5fe979ac8298e028f9599cbccbc',27,''),(286,29,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',277,'Teotihuacan.jpg',7,6,228789,1716936366,1716936366,0,0,'9ce1a0dab9ff0b3d6a8f8b457c6105fb',27,''),(287,29,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',277,'Portugal.jpg',7,6,243733,1716936366,1716936366,0,0,'4c177b8954976249b34db8a3cb17e053',27,''),(288,31,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405814,1716936379,0,0,'665d8876b9b09',23,''),(289,31,'cache','0fea6a13c52b4d4725368f24b045ca84',288,'cache',2,1,0,1716936379,1716936379,0,0,'665d887682bd0',31,''),(290,31,'files','45b963397aa40d4a0063e0d85e4fe7a1',288,'files',2,1,4688555,1717405814,1716936380,0,0,'665d8876b9b09',31,''),(291,31,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',290,'Documents',2,1,36227,1717405814,1716936379,0,0,'665d8876b9b09',31,''),(292,31,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',290,'Learn more about ownCloud',2,1,3640864,1717405814,1716936380,0,0,'665d8876b9b09',31,''),(293,31,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',290,'Photos',2,1,1011464,1717405814,1716936381,0,0,'665d8876b9b09',31,''),(294,31,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',291,'Example.odt',4,3,36227,1716936379,1716936379,0,0,'8c3b03507daf7b2809eb5f415f86427b',27,''),(295,31,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',292,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936380,1716936380,0,0,'09754f3c175d6de3c71da4ec854cc490',27,''),(296,31,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',292,'Share files efficiently in your company.pdf',5,3,303237,1716936380,1716936380,0,0,'5206322bf3ee2d36e2ab50108bdd5569',27,''),(297,31,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',292,'Introducing ownCloud.pdf',5,3,238300,1716936380,1716936380,0,0,'6c5b858295b30378516bdace81015e1b',27,''),(298,31,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',292,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936380,1716936380,0,0,'20e4cffe3317ab32670661735a7c74f3',27,''),(299,31,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',292,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936380,1716936380,0,0,'8a346e54e91c17b63771d43062dbb498',27,''),(300,31,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',292,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936380,1716936380,0,0,'f3168e1e5ace3335468089a75347bc32',27,''),(301,31,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',293,'Lake-Constance.jpg',7,6,538942,1716936380,1716936380,0,0,'74929c44b52cefcf92df8ef5010f879a',27,''),(302,31,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',293,'Teotihuacan.jpg',7,6,228789,1716936380,1716936380,0,0,'882584797c5d70180fda320ee59e9933',27,''),(303,31,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',293,'Portugal.jpg',7,6,243733,1716936381,1716936381,0,0,'1010afa003a46b788e86092e62235ec7',27,''),(304,33,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405815,1716936393,0,0,'665d88770acc4',23,''),(305,33,'cache','0fea6a13c52b4d4725368f24b045ca84',304,'cache',2,1,0,1716936393,1716936393,0,0,'665d8876cd5ef',31,''),(306,33,'files','45b963397aa40d4a0063e0d85e4fe7a1',304,'files',2,1,4688555,1717405815,1716936394,0,0,'665d88770acc4',31,''),(307,33,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',306,'Documents',2,1,36227,1717405814,1716936394,0,0,'665d88770acc4',31,''),(308,33,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',306,'Learn more about ownCloud',2,1,3640864,1717405814,1716936394,0,0,'665d88770acc4',31,''),(309,33,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',306,'Photos',2,1,1011464,1717405815,1716936395,0,0,'665d88770acc4',31,''),(310,33,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',307,'Example.odt',4,3,36227,1716936394,1716936394,0,0,'ddf54c80ae43342850b375fa992a96e1',27,''),(311,33,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',308,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936394,1716936394,0,0,'96e977c86a9b09e9773f8bd24d1b08f2',27,''),(312,33,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',308,'Share files efficiently in your company.pdf',5,3,303237,1716936394,1716936394,0,0,'f5a643a88e9d364ad3d9a0d7aaf5681f',27,''),(313,33,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',308,'Introducing ownCloud.pdf',5,3,238300,1716936394,1716936394,0,0,'5150c1db1ebb32a2c13c062161f3be09',27,''),(314,33,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',308,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936394,1716936394,0,0,'62c94daec4020b785094e302b1c5bde9',27,''),(315,33,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',308,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936394,1716936394,0,0,'bcfccf9ad158de9056fa10af34d95114',27,''),(316,33,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',308,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936394,1716936394,0,0,'7fe729560ce77badd01e0a7a53326d86',27,''),(317,33,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',309,'Lake-Constance.jpg',7,6,538942,1716936394,1716936394,0,0,'67b02501c74173a5ac26f77dda1ad7e5',27,''),(318,33,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',309,'Teotihuacan.jpg',7,6,228789,1716936395,1716936395,0,0,'67ccebce2959ac04f8904ff9536911cd',27,''),(319,33,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',309,'Portugal.jpg',7,6,243733,1716936395,1716936395,0,0,'ae67682131eff982e221ab60d0da9fca',27,''),(320,35,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405815,1716936410,0,0,'665d88774abfb',23,''),(321,35,'cache','0fea6a13c52b4d4725368f24b045ca84',320,'cache',2,1,0,1716936410,1716936410,0,0,'665d88771c8a3',31,''),(322,35,'files','45b963397aa40d4a0063e0d85e4fe7a1',320,'files',2,1,4688555,1717405815,1716936411,0,0,'665d88774abfb',31,''),(323,35,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',322,'Documents',2,1,36227,1717405815,1716936410,0,0,'665d88774abfb',31,''),(324,35,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',322,'Learn more about ownCloud',2,1,3640864,1717405815,1716936411,0,0,'665d88774abfb',31,''),(325,35,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',322,'Photos',2,1,1011464,1717405815,1716936411,0,0,'665d88774abfb',31,''),(326,35,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',323,'Example.odt',4,3,36227,1716936410,1716936410,0,0,'a455315ec3dfa9682bd74227384bc663',27,''),(327,35,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',324,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936410,1716936410,0,0,'383f48b68f44d4aee4323d9c098f505c',27,''),(328,35,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',324,'Share files efficiently in your company.pdf',5,3,303237,1716936411,1716936411,0,0,'5976f62f6a8dbbcf6419ce375d6c1cf3',27,''),(329,35,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',324,'Introducing ownCloud.pdf',5,3,238300,1716936411,1716936411,0,0,'4e7746172d10e732609bebf6ac594bf0',27,''),(330,35,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',324,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936411,1716936411,0,0,'ba88aa74e7ace14c6ad86720cf2fb675',27,''),(331,35,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',324,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936411,1716936411,0,0,'260de1980f4fd81976a7ca2d5919891e',27,''),(332,35,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',324,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936411,1716936411,0,0,'26873f488356dddcd765eaff8ad7e7fd',27,''),(333,35,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',325,'Lake-Constance.jpg',7,6,538942,1716936411,1716936411,0,0,'39d091c2a1250f3cd30cda841352716f',27,''),(334,35,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',325,'Teotihuacan.jpg',7,6,228789,1716936411,1716936411,0,0,'40186b3ac20d5a92ebcd67a2ca70aaa7',27,''),(335,35,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',325,'Portugal.jpg',7,6,243733,1716936411,1716936411,0,0,'a5797b6d75d2d72f6f7557d47be20430',27,''),(336,37,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405815,1716936426,0,0,'665d887794e82',23,''),(337,37,'cache','0fea6a13c52b4d4725368f24b045ca84',336,'cache',2,1,0,1716936426,1716936426,0,0,'665d887761ded',31,''),(338,37,'files','45b963397aa40d4a0063e0d85e4fe7a1',336,'files',2,1,4688555,1717405815,1716936427,0,0,'665d887794e82',31,''),(339,37,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',338,'Documents',2,1,36227,1717405815,1716936426,0,0,'665d887794e82',31,''),(340,37,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',338,'Learn more about ownCloud',2,1,3640864,1717405815,1716936427,0,0,'665d887794e82',31,''),(341,37,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',338,'Photos',2,1,1011464,1717405815,1716936427,0,0,'665d887794e82',31,''),(342,37,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',339,'Example.odt',4,3,36227,1716936426,1716936426,0,0,'4d7a9dc42fc91d51f4628de355bf50be',27,''),(343,37,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',340,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936426,1716936426,0,0,'ee715a025750b29d4b6c51920f82bf15',27,''),(344,37,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',340,'Share files efficiently in your company.pdf',5,3,303237,1716936426,1716936426,0,0,'9e86348785fd8a0297f7bafaccde0a06',27,''),(345,37,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',340,'Introducing ownCloud.pdf',5,3,238300,1716936426,1716936426,0,0,'031ade1a6c3d2826ebbf3173a4b56da9',27,''),(346,37,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',340,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936426,1716936426,0,0,'4b695a1c4c6eafc7a8adaf82ab9c7ee3',27,''),(347,37,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',340,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936427,1716936427,0,0,'5777bb96e9ae01006d94398630d99ed2',27,''),(348,37,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',340,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936427,1716936427,0,0,'1b69da0d66599c8e6934d697ce8f8c39',27,''),(349,37,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',341,'Lake-Constance.jpg',7,6,538942,1716936427,1716936427,0,0,'64eced47aa698039e271587e3b7cd6f8',27,''),(350,37,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',341,'Teotihuacan.jpg',7,6,228789,1716936427,1716936427,0,0,'618e9b4d4743678f32450d8cfda6677f',27,''),(351,37,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',341,'Portugal.jpg',7,6,243733,1716936427,1716936427,0,0,'e1c32d9a28579dd4e8fc6ae68ce96117',27,''),(352,39,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405815,1716936440,0,0,'665d8877dfde2',23,''),(353,39,'cache','0fea6a13c52b4d4725368f24b045ca84',352,'cache',2,1,0,1716936440,1716936440,0,0,'665d8877a9c33',31,''),(354,39,'files','45b963397aa40d4a0063e0d85e4fe7a1',352,'files',2,1,4688555,1717405815,1716936441,0,0,'665d8877dfde2',31,''),(355,39,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',354,'Documents',2,1,36227,1717405815,1716936440,0,0,'665d8877dfde2',31,''),(356,39,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',354,'Learn more about ownCloud',2,1,3640864,1717405815,1716936441,0,0,'665d8877dfde2',31,''),(357,39,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',354,'Photos',2,1,1011464,1717405815,1716936441,0,0,'665d8877dfde2',31,''),(358,39,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',355,'Example.odt',4,3,36227,1716936440,1716936440,0,0,'9708762884ebef31d6955d7c5a6e11bf',27,''),(359,39,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',356,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936440,1716936440,0,0,'6cb2ce11680ba68c9c3c010f025f84e8',27,''),(360,39,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',356,'Share files efficiently in your company.pdf',5,3,303237,1716936440,1716936440,0,0,'ab2e964212c9321ef3e1bae1cf1d45ec',27,''),(361,39,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',356,'Introducing ownCloud.pdf',5,3,238300,1716936440,1716936440,0,0,'3aa8c61cd10e45c737ed1348fa2614c4',27,''),(362,39,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',356,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936441,1716936441,0,0,'e89e64b1be984ec5f25b43e78eb02f09',27,''),(363,39,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',356,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936441,1716936441,0,0,'1187fb2aa1b096e6a0273542285845e8',27,''),(364,39,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',356,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936441,1716936441,0,0,'f47eee1a59fcc6a60e45a4e3db2c8d44',27,''),(365,39,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',357,'Lake-Constance.jpg',7,6,538942,1716936441,1716936441,0,0,'42064c2c6ad462972c47d1394507de2c',27,''),(366,39,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',357,'Teotihuacan.jpg',7,6,228789,1716936441,1716936441,0,0,'ebf5381cf0c9fb756175ba6b05429ad0',27,''),(367,39,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',357,'Portugal.jpg',7,6,243733,1716936441,1716936441,0,0,'d6eaa2436b4673d5768f5fcdf2778128',27,''),(368,41,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717405816,1716936454,0,0,'665d887834a2d',23,''),(369,41,'cache','0fea6a13c52b4d4725368f24b045ca84',368,'cache',2,1,0,1716936454,1716936454,0,0,'665d887807392',31,''),(370,41,'files','45b963397aa40d4a0063e0d85e4fe7a1',368,'files',2,1,4688555,1717405816,1716936455,0,0,'665d887834a2d',31,''),(371,41,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',370,'Documents',2,1,36227,1717405816,1716936454,0,0,'665d887834a2d',31,''),(372,41,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',370,'Learn more about ownCloud',2,1,3640864,1717405816,1716936455,0,0,'665d887834a2d',31,''),(373,41,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',370,'Photos',2,1,1011464,1717405816,1716936456,0,0,'665d887834a2d',31,''),(374,41,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',371,'Example.odt',4,3,36227,1716936454,1716936454,0,0,'0bbc26f77cf5d589a6385e99752dc507',27,''),(375,41,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',372,'ownCloud Subscription Overview.pdf',5,3,1611431,1716936455,1716936455,0,0,'1f6e5b43f0f241c0e801d9b910f83521',27,''),(376,41,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',372,'Share files efficiently in your company.pdf',5,3,303237,1716936455,1716936455,0,0,'b40ac5ec371e0b4e008bf5d97c9f98e2',27,''),(377,41,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',372,'Introducing ownCloud.pdf',5,3,238300,1716936455,1716936455,0,0,'0738603c2797c82270d3dc0489b2f8f2',27,''),(378,41,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',372,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1716936455,1716936455,0,0,'92a98fcf45b35ccf388d64f8bee906d4',27,''),(379,41,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',372,'Safely leverage Microsoft Office.pdf',5,3,314348,1716936455,1716936455,0,0,'22e94cb957a583b2a73284cd16bb2506',27,''),(380,41,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',372,'Keep your files safe with ownCloud.pdf',5,3,755022,1716936455,1716936455,0,0,'78cd12cc9129f3555ebfe879ffe232da',27,''),(381,41,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',373,'Lake-Constance.jpg',7,6,538942,1716936455,1716936455,0,0,'6f3fc83a3140b3d0b11041501af4cdc8',27,''),(382,41,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',373,'Teotihuacan.jpg',7,6,228789,1716936456,1716936456,0,0,'651a9da6cc39fbf2fdfc1f586f1f28bf',27,''),(383,41,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',373,'Portugal.jpg',7,6,243733,1716936456,1716936456,0,0,'f86286efee63b1410d5fc3d0451520e7',27,''),(384,43,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,9377110,1717449680,1717449679,0,0,'665e33d07e58b',23,''),(385,43,'cache','0fea6a13c52b4d4725368f24b045ca84',384,'cache',2,1,0,1716934835,1716934835,0,0,'665d887848eb4',31,''),(386,43,'files','45b963397aa40d4a0063e0d85e4fe7a1',384,'files',2,1,4688555,1717449680,1716934836,0,0,'665e33d06f46b',31,''),(387,43,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',386,'Documents',2,1,36227,1717449679,1716934835,0,0,'665e33cf6eef4',31,''),(388,43,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',386,'Learn more about ownCloud',2,1,3640864,1717449680,1716934836,0,0,'665e33d01f2fe',31,''),(389,43,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',386,'Photos',2,1,1011464,1717449680,1716934837,0,0,'665e33d06f46b',31,''),(390,43,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',387,'Example.odt',4,3,36227,1717449679,1717449679,0,0,'b6720ad3bf6e8f4724845cf71fc4184c',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(391,43,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',388,'ownCloud Subscription Overview.pdf',5,3,1611431,1717449679,1717449679,0,0,'ff41cbb12601dcf4b4f49bef6a0e9940',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(392,43,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',388,'Share files efficiently in your company.pdf',5,3,303237,1717449679,1717449679,0,0,'0c66023d4da701cff22bc2fe5f4d711e',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(393,43,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',388,'Introducing ownCloud.pdf',5,3,238300,1717449679,1717449679,0,0,'194f666177bb55c32e269af7057a1544',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(394,43,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',388,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717449680,1717449680,0,0,'e0847658896a05f8ca574fdec3212684',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(395,43,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',388,'Safely leverage Microsoft Office.pdf',5,3,314348,1717449680,1717449680,0,0,'79c1966aed725f9f65b30f41dbaba2e1',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(396,43,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',388,'Keep your files safe with ownCloud.pdf',5,3,755022,1717449680,1717449680,0,0,'d1e3be9eddf905be7929ccd8ed6d0231',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(397,43,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',389,'Lake-Constance.jpg',7,6,538942,1717449680,1717449680,0,0,'84f73ca92344649a5992af5d3297d473',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(398,43,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',389,'Teotihuacan.jpg',7,6,228789,1717449680,1717449680,0,0,'e4f9e7c2a3afe089b4564b6bb73baf61',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(399,43,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',389,'Portugal.jpg',7,6,243733,1717449680,1717449680,0,0,'e55bbe0543bc464eda46c03711c30115',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(400,11,'files_versions','9692aae50022f45f1098646939b287b1',115,'files_versions',2,1,4688555,1717445718,1717445717,0,0,'665e245629792',31,''),(401,11,'files_versions/Documents','31726c44088c2bcb7763e1f483a37c67',400,'Documents',2,1,36227,1717445717,1717445717,0,0,'665e24553abfa',31,''),(402,11,'files_versions/Documents/Example.odt.v1717445717','4add3ed2c17c7bc3c631a314e0fa86e0',401,'Example.odt.v1717445717',9,3,36227,1717445717,1717445717,0,0,'9ad873edb3f2bae682c00ba45968836a',27,''),(403,11,'files_versions/Learn more about ownCloud','4c9d74da5a52565213216abfe1b11e4f',400,'Learn more about ownCloud',2,1,3640864,1717445717,1717445717,0,0,'665e2455d30d5',31,''),(404,11,'files_versions/Learn more about ownCloud/ownCloud Subscription Overview.pdf.v1717445717','a59d0343df079db79d7168ef008b1a73',403,'ownCloud Subscription Overview.pdf.v1717445717',9,3,1611431,1717445717,1717445717,0,0,'16bc3bf549b7b24a96cf97092633d4d4',27,''),(405,11,'files_versions/Learn more about ownCloud/Share files efficiently in your company.pdf.v1717445717','a61f4374b6418a69bcfa49d745c9b7fb',403,'Share files efficiently in your company.pdf.v1717445717',9,3,303237,1717445717,1717445717,0,0,'39b4181b6229f8bd7ca737f9d2fb3e09',27,''),(406,11,'files_versions/Learn more about ownCloud/Introducing ownCloud.pdf.v1717445717','20e735c7f84232711ab9b96c93d38b28',403,'Introducing ownCloud.pdf.v1717445717',9,3,238300,1717445717,1717445717,0,0,'f05ecc22218e1bdf5631666facbbe3ac',27,''),(407,11,'files_versions/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf.v1717445717','c032a95a13e1bb294fe07de6d14a7758',403,'Data Protection and Data Secrecy in ownCloud.pdf.v1717445717',9,3,418526,1717445717,1717445717,0,0,'0e75a0f87883afc654b3d74eb678567b',27,''),(408,11,'files_versions/Learn more about ownCloud/Safely leverage Microsoft Office.pdf.v1717445717','c50ff6934a5a37ee44240718012047f3',403,'Safely leverage Microsoft Office.pdf.v1717445717',9,3,314348,1717445717,1717445717,0,0,'9ef18489da6d23e697fc070b82cd472b',27,''),(409,11,'files_versions/Learn more about ownCloud/Keep your files safe with ownCloud.pdf.v1717445717','6ac2a6c7781c43d41c3c627f8af307f3',403,'Keep your files safe with ownCloud.pdf.v1717445717',9,3,755022,1717445717,1717445717,0,0,'189815b77fe55861d0a9649af0f6ee80',27,''),(410,11,'files_versions/Photos','745595fc1c6eb42d923e37526197a3db',400,'Photos',2,1,1011464,1717445718,1717445718,0,0,'665e245629792',31,''),(411,11,'files_versions/Photos/Lake-Constance.jpg.v1717445717','f898de3420bd43c7cb760c38973f5307',410,'Lake-Constance.jpg.v1717445717',9,3,538942,1717445717,1717445717,0,0,'5bca47a5b3171ed1af1330811ddeb97e',27,''),(412,11,'files_versions/Photos/Teotihuacan.jpg.v1717445718','f0f7f30c338378547452b0b5cc59b8cf',410,'Teotihuacan.jpg.v1717445718',9,3,228789,1717445718,1717445718,0,0,'73399b9681c33ecbf2117d9e0ebd50af',27,''),(413,11,'files_versions/Photos/Portugal.jpg.v1717445718','9e0954286c45e4d402a111ff43be0b13',410,'Portugal.jpg.v1717445718',9,3,243733,1717445718,1717445718,0,0,'c4db971fc29e6784bb076274b689650e',27,''),(414,11,'thumbnails/129','aa17b4dea3df92ed7c02064139bf9b65',118,'129',2,1,0,1717445719,1717445719,0,0,'665e24577f317',31,''),(415,11,'thumbnails/129/2048-2048-max.png','6b17f2748e8b809c1455da1cd976b17e',414,'2048-2048-max.png',8,6,18264,1717445719,1717445719,0,0,'0c5e3e83988c45d717abcd56bbc6dd40',27,'SHA1:c0eb24d5a48f8bb9906419c4fc7b47993264e481 MD5:e2ed05f12b6610d4037d47d548018da2 ADLER32:b84e0270'),(416,11,'thumbnails/129/32-32.png','6b3ef81f8140cf095cbb13c7b8002c4f',414,'32-32.png',8,6,512,1717445719,1717445719,0,0,'b41a91f8a183bc2221f319927e960807',27,'SHA1:71d1d55fc290e87915b02f767200d3eae5d13a13 MD5:3cc69eec678d119d68dfafdedca50051 ADLER32:77badb46'),(417,43,'files_versions','9692aae50022f45f1098646939b287b1',384,'files_versions',2,1,4688555,1717449680,1717449680,0,0,'665e33d07e58b',31,''),(418,43,'files_versions/Documents','31726c44088c2bcb7763e1f483a37c67',417,'Documents',2,1,36227,1717449679,1717449679,0,0,'665e33cf8c740',31,''),(419,43,'files_versions/Documents/Example.odt.v1717449679','6e5a78751b3365b1a0b8257bef8c0bd8',418,'Example.odt.v1717449679',9,3,36227,1717449679,1717449679,0,0,'127f0becbbc8b580d2164d1c14b95138',27,''),(420,43,'files_versions/Learn more about ownCloud','4c9d74da5a52565213216abfe1b11e4f',417,'Learn more about ownCloud',2,1,3640864,1717449680,1717449680,0,0,'665e33d02ad07',31,''),(421,43,'files_versions/Learn more about ownCloud/ownCloud Subscription Overview.pdf.v1717449679','c7d01426062e69fd715ac7423bb280d8',420,'ownCloud Subscription Overview.pdf.v1717449679',9,3,1611431,1717449679,1717449679,0,0,'ee48219f6f7d6f07e660f8d07f4dd224',27,''),(422,43,'files_versions/Learn more about ownCloud/Share files efficiently in your company.pdf.v1717449679','130edaf43ac5714cd9007377ea2fba0f',420,'Share files efficiently in your company.pdf.v1717449679',9,3,303237,1717449679,1717449679,0,0,'5ba490f98f1ff197ed311bea6549e9ad',27,''),(423,43,'files_versions/Learn more about ownCloud/Introducing ownCloud.pdf.v1717449679','376633a190b3dd73c24904a15b81930e',420,'Introducing ownCloud.pdf.v1717449679',9,3,238300,1717449679,1717449679,0,0,'efcb42362410e8312649ede039d99aa0',27,''),(424,43,'files_versions/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf.v1717449679','3661a04fea9c47b806c449afeefcb869',420,'Data Protection and Data Secrecy in ownCloud.pdf.v1717449679',9,3,418526,1717449679,1717449679,0,0,'03e556ad42d564a355d2adb17c294364',27,''),(425,43,'files_versions/Learn more about ownCloud/Safely leverage Microsoft Office.pdf.v1717449680','90902d2dbf1503925d0c7c5de6869217',420,'Safely leverage Microsoft Office.pdf.v1717449680',9,3,314348,1717449680,1717449680,0,0,'9f76236bf0cb6963489f9f0e02b96397',27,''),(426,43,'files_versions/Learn more about ownCloud/Keep your files safe with ownCloud.pdf.v1717449680','a1b01922bdb972e3263fc8992f6a9910',420,'Keep your files safe with ownCloud.pdf.v1717449680',9,3,755022,1717449680,1717449680,0,0,'473850b442f066029cbc36edac3cd7b0',27,''),(427,43,'files_versions/Photos','745595fc1c6eb42d923e37526197a3db',417,'Photos',2,1,1011464,1717449680,1717449680,0,0,'665e33d07e58b',31,''),(428,43,'files_versions/Photos/Lake-Constance.jpg.v1717449680','4b550b11b2392548ce863f2c0bea6fdc',427,'Lake-Constance.jpg.v1717449680',9,3,538942,1717449680,1717449680,0,0,'f11efd5ff769f6b7ee4aa2e31fcec8c1',27,''),(429,43,'files_versions/Photos/Teotihuacan.jpg.v1717449680','39695a1068456965ac6fccfa745926c7',427,'Teotihuacan.jpg.v1717449680',9,3,228789,1717449680,1717449680,0,0,'62edcfe7c3f024ff77ee6b5dcf47a709',27,''),(430,43,'files_versions/Photos/Portugal.jpg.v1717449680','80810691df688f174b67bba7c774fb3d',427,'Portugal.jpg.v1717449680',9,3,243733,1717449680,1717449680,0,0,'86510688edf7df1f1b85047e465dc399',27,''),(431,5,'files_versions','9692aae50022f45f1098646939b287b1',33,'files_versions',2,1,4688555,1717449829,1717449829,0,0,'665e346596412',31,''),(432,5,'files_versions/Documents','31726c44088c2bcb7763e1f483a37c67',431,'Documents',2,1,36227,1717449828,1717449828,0,0,'665e3464a00ad',31,''),(433,5,'files_versions/Documents/Example.odt.v1717449828','095c7b125f5f6c1bbf6d7aefda7d7e40',432,'Example.odt.v1717449828',9,3,36227,1717449828,1717449828,0,0,'a3a9b3dca388e25fe127cfdcc87a504f',27,''),(434,5,'files_versions/Learn more about ownCloud','4c9d74da5a52565213216abfe1b11e4f',431,'Learn more about ownCloud',2,1,3640864,1717449829,1717449829,0,0,'665e346546e9a',31,''),(435,5,'files_versions/Learn more about ownCloud/ownCloud Subscription Overview.pdf.v1717449828','7f5ca85319575086e5d12b089e403ca5',434,'ownCloud Subscription Overview.pdf.v1717449828',9,3,1611431,1717449828,1717449828,0,0,'3cdfe55caabd244c7ddc05e918e9b813',27,''),(436,5,'files_versions/Learn more about ownCloud/Share files efficiently in your company.pdf.v1717449828','25c5d1d9f9f518b23be67a0f5bb5824e',434,'Share files efficiently in your company.pdf.v1717449828',9,3,303237,1717449828,1717449828,0,0,'40381d69ea033a7a0d24789143e8e045',27,''),(437,5,'files_versions/Learn more about ownCloud/Introducing ownCloud.pdf.v1717449828','b3e0b92c2e63abc0955a50dc1d13cf92',434,'Introducing ownCloud.pdf.v1717449828',9,3,238300,1717449828,1717449828,0,0,'4c6626a5c76e55a32de0b3d45f1ebb57',27,''),(438,5,'files_versions/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf.v1717449829','a64f819323a84a3170a22dd13c326b73',434,'Data Protection and Data Secrecy in ownCloud.pdf.v1717449829',9,3,418526,1717449829,1717449829,0,0,'484d6e3d2cf1284304547fc0855b7992',27,''),(439,5,'files_versions/Learn more about ownCloud/Safely leverage Microsoft Office.pdf.v1717449829','7944949743e03c0606bcb2bdf436dec5',434,'Safely leverage Microsoft Office.pdf.v1717449829',9,3,314348,1717449829,1717449829,0,0,'280fa671062d4d3f098288472dd5cdd4',27,''),(440,5,'files_versions/Learn more about ownCloud/Keep your files safe with ownCloud.pdf.v1717449829','5d8a99dced967a6befafe1f9db94d852',434,'Keep your files safe with ownCloud.pdf.v1717449829',9,3,755022,1717449829,1717449829,0,0,'bd1eb5e1de9330b4b67545753eaa7f08',27,''),(441,5,'files_versions/Photos','745595fc1c6eb42d923e37526197a3db',431,'Photos',2,1,1011464,1717449829,1717449829,0,0,'665e346596412',31,''),(442,5,'files_versions/Photos/Lake-Constance.jpg.v1717449829','60d49d3d178b2f4585e0a53ea5bf6abc',441,'Lake-Constance.jpg.v1717449829',9,3,538942,1717449829,1717449829,0,0,'7eb0272f3dfe8a8df8ade0dbc5f924d5',27,''),(443,5,'files_versions/Photos/Teotihuacan.jpg.v1717449829','0b78bff2e2aaf3c3da533f8e01cd4418',441,'Teotihuacan.jpg.v1717449829',9,3,228789,1717449829,1717449829,0,0,'ce6130ca2085aec3cda5c49ef1483eba',27,''),(444,5,'files_versions/Photos/Portugal.jpg.v1717449829','d80f4f0f872c1a118c602eaf4355e4f1',441,'Portugal.jpg.v1717449829',9,3,243733,1717449829,1717449829,0,0,'d57aec01f94093668a5fabec44845319',27,''),(445,3,'ocuser04','d3ae55bb87d9084adfb49f89c32311b1',17,'ocuser04',2,1,-1,1717445717,1717445717,0,0,'665e34671d90c',31,''),(446,3,'ocuser04/files_versions','ee9355b2b379317d2790d7b958c3c786',445,'files_versions',2,1,-2,1717445717,1717445717,0,0,'665e34671b1b4',31,''),(447,3,'ocuser04/files_versions/Documents','a0bf50d53f91bc62e357514f70a76ef7',446,'Documents',2,1,-1,1717445717,1717445717,0,0,'665e346724d57',31,''),(448,3,'ocuser04/files_versions/Learn more about ownCloud','0b112154884841d7cffc752bec045f99',446,'Learn more about ownCloud',2,1,-1,1717445717,1717445717,0,0,'665e346726a54',31,''),(449,3,'ocuser04/files_versions/Photos','a9333f32d3ab64da1e1548bb4c67409d',446,'Photos',2,1,-1,1717445718,1717445718,0,0,'665e34672839c',31,''),(450,5,'thumbnails/84','2c4432b18ef2f5c671b071755778cc5f',36,'84',2,1,0,1717450235,1717450235,0,0,'665e3470bc638',31,''),(451,5,'thumbnails/82','c74d0227048bbaf555ac73ced144a02f',36,'82',2,1,0,1717450234,1717450234,0,0,'665e3470c273f',31,''),(452,5,'thumbnails/81','d2479680e6000db0111f1ee41a406520',36,'81',2,1,0,1717450259,1717450259,0,0,'665e3470c81d6',31,''),(453,5,'thumbnails/80','59d38c85e1fa4c5a7fa66c553fb0f97b',36,'80',2,1,0,1717450242,1717450242,0,0,'665e3470dd680',31,''),(454,5,'thumbnails/83','347dcd9e1e23f78b4663e269d05031bf',36,'83',2,1,0,1717450242,1717450242,0,0,'665e3470e1e15',31,''),(455,5,'thumbnails/80/450-532-max.png','7e2407c07ab54b2f481e6f012a88a0c4',453,'450-532-max.png',8,6,28812,1717449840,1717449840,0,0,'6f6dd09a953c268da09ba04b4c8fff95',27,'SHA1:3539f1077d2809183ed8a089cba2254954b697c2 MD5:e94272ab008e94ede19bddd3f380685d ADLER32:a51bcf0d'),(456,5,'thumbnails/83/383-458-max.png','288c4d3df366815f70a217b8f8bdd4da',454,'383-458-max.png',8,6,18744,1717449840,1717449840,0,0,'35be2c842a9e18c11ef9b8318d926ddf',27,'SHA1:3f554857da3e9ca63f858d2fc63adb26d9196ad7 MD5:86d333b2a7721add6784aafce540c305 ADLER32:0f1f8e2d'),(457,5,'thumbnails/85','5b2f1f7e5df9f8ff89dac4afffd8b921',36,'85',2,1,0,1717450234,1717450234,0,0,'665e3470eb293',31,''),(458,5,'thumbnails/80/32-32.png','4246b64bb126c4c26eb87b81566bc198',453,'32-32.png',8,6,1466,1717449840,1717449840,0,0,'44cc9882f60e10e1fd4e10d5d3f9ebeb',27,'SHA1:fd96c63d2021a060a78cc7a550c40cc0f7528011 MD5:dbe4ab9e8b5ac149f6874305b41f5ec5 ADLER32:5490d4de'),(459,5,'thumbnails/83/32-32.png','6213f7581833974e35f8ca1f54b43ec3',454,'32-32.png',8,6,1686,1717449840,1717449840,0,0,'1f2a3153c886bdfe9d32980fe0162265',27,'SHA1:0baa2ce2a3a09a97711adc1a6bd83d6ac329e735 MD5:329f618939946e7688ac482adeb925c5 ADLER32:f6bc3fa7'),(460,5,'thumbnails/82/546-464-max.png','22c04dd589a13af51a90eaed5d0143c6',451,'546-464-max.png',8,6,262960,1717449840,1717449840,0,0,'dd8da7188f399fb95875e7d91d618e7a',27,'SHA1:ef90ce81e7ee96d8ffcd47d6f5aebd94b8cfc7f2 MD5:1c1638eb4d78d3a6e8b5bf04f5a157a6 ADLER32:726f31e3'),(461,5,'thumbnails/82/32-32.png','7030578e7b21599d267ebd09b6168c90',451,'32-32.png',8,6,2467,1717449841,1717449841,0,0,'6f063939dbe85019093d047613d2d016',27,'SHA1:2c1b5f5ea2de7faf64c05fdaafce026c844db6d7 MD5:ad9f1406e2fced7b43a46d2684d627e8 ADLER32:5efd94a5'),(462,5,'thumbnails/81/377-452-max.png','3309e0d8343a834ec377387a041e3927',452,'377-452-max.png',8,6,211541,1717449841,1717449841,0,0,'9895ba10999c1b0c48b6da1e09dd8257',27,'SHA1:ea8b23ba51b7734a5e7005b2ce664bfaaa48e7aa MD5:4ed569cb86b43c7dc4d240a5a8b4265a ADLER32:33f665aa'),(463,5,'thumbnails/81/32-32.png','51fe3a69c2faef204963b9e58ecbf11c',452,'32-32.png',8,6,2661,1717449841,1717449841,0,0,'f49cb89e1580929ea2031ee1d3c3093e',27,'SHA1:b55df4439ffc7c1b5ca8cd7021ebf49eb1396f7c MD5:de5e3a86f6125d3d75b6f723e247664f ADLER32:deb519a0'),(464,5,'thumbnails/84/969-723-max.png','d0850084dd81fd93235fdcbbca2a3101',450,'969-723-max.png',8,6,418028,1717449841,1717449841,0,0,'95111666b1769f09c7b0c915d70c008a',27,'SHA1:6eb9527109014fbe41d93bd8818afedf73e95da8 MD5:cf67ced8528ebf96f862fb8d8e6d164d ADLER32:6012713c'),(465,5,'thumbnails/84/32-32.png','b96fe49a170885c71ebe221822a3d8bc',450,'32-32.png',8,6,1999,1717449841,1717449841,0,0,'d9590b4d790639a464e6b10b5f7e9bb8',27,'SHA1:9d7326decd14276bea8258ab68be4eae106fdde3 MD5:3918b3391e0163d3fd1c04e448380878 ADLER32:4c91dda2'),(466,5,'thumbnails/89','3e204e7cd599983c05c51fbbcc38e3d5',36,'89',2,1,0,1717450242,1717450242,0,0,'665e34713542f',31,''),(467,5,'thumbnails/88','6fa2f8571fdf0a9a75756ed0c9fdfeaf',36,'88',2,1,0,1717450244,1717450244,0,0,'665e34713a261',31,''),(468,5,'thumbnails/89/429-530-max.png','5260594e1e5415e532595813acf1ff69',466,'429-530-max.png',8,6,39232,1717449841,1717449841,0,0,'c9050e16970f2f39cfb63c6990a44af3',27,'SHA1:240e177c4c7a9eaa6ef755a3c1b6326968c48bca MD5:b9700e89338b441adcc68ce8494f3cce ADLER32:e1cde4c1'),(469,5,'thumbnails/89/32-32.png','9f33ce27b9119ce577a04000a7c3f534',466,'32-32.png',8,6,1823,1717449841,1717449841,0,0,'5d5568552f3121c303d50ecb675617db',27,'SHA1:37f99f1e9d9f2ffd5a95a3599dcdae42696f561e MD5:af9ed2928faa8c550e4b8d6a1a52b5b2 ADLER32:4eb175b1'),(470,5,'thumbnails/79','e318b8da4b9acd15d00a0ba3aeb6717d',36,'79',2,1,0,1717450238,1717450238,0,0,'665e347143bea',31,''),(471,5,'thumbnails/87','c1ec72c371da9f91acce67375a5415b1',36,'87',2,1,0,1717450238,1717450238,0,0,'665e34714f392',31,''),(472,5,'thumbnails/86','a6615a2e877f705b349399596ad83bc2',36,'86',2,1,0,1717450237,1717450237,0,0,'665e347160c00',31,''),(473,5,'thumbnails/86/389-363-max.png','65a3de0e06883827542e9c9ba2d2384d',472,'389-363-max.png',8,6,51149,1717449841,1717449841,0,0,'6e40a98fba4d2f6735419799ca3acf83',27,'SHA1:1e7dd360864b0cd5244a852124d93531c612ea22 MD5:a210cf9a03084bc515ebd5bca66c5d3f ADLER32:d25332c7'),(474,5,'thumbnails/86/32-32.png','11b7e4182c635f8e637e369b6cd27098',472,'32-32.png',8,6,1605,1717449841,1717449841,0,0,'9d126fdebf1da28dfb6cf48c5bf97ca3',27,'SHA1:9e930601af4196a9106e68b8e6c7e46d6286607e MD5:0b8a6e57b75f30bd274c6343dbff45c4 ADLER32:ff54f830'),(475,5,'thumbnails/88/722-445-max.png','3f809456868db05f7b86a0a7fe4aceef',467,'722-445-max.png',8,6,460192,1717449841,1717449841,0,0,'75263d578b66ebfb9f6d41ab9aa3e75b',27,'SHA1:bfa209908520f779a88ce7b156d30e0cf97caf7e MD5:a8e15400a55dd7f7e3ffe0d15947a3df ADLER32:85ccc4a6'),(476,5,'thumbnails/85/791-528-max.png','027da81215e2983517db687fef936225',457,'791-528-max.png',8,6,845830,1717449841,1717449841,0,0,'905a1a6c098a52efb34836093be5b407',27,'SHA1:d63279d553c500d084c852de6a1e1b54f20f15bf MD5:1a807f3f2927bf62ffbdeee0a6027fef ADLER32:0e0f5313'),(477,5,'thumbnails/88/32-32.png','f6c6df56a16e1a54c4c0ab504df2b455',467,'32-32.png',8,6,2937,1717449841,1717449841,0,0,'316bb0dc01fcee81dfc307cc0e4d4f18',27,'SHA1:eb3a5b2cf0fa279dfdb6908f1ab98755e6f3a676 MD5:6eaa716ebc68300341d34a2295ec216a ADLER32:f3629551'),(478,5,'thumbnails/85/32-32.png','5596dc0a88108e8bb0ac92cc2731706e',457,'32-32.png',8,6,2164,1717449841,1717449841,0,0,'9c9fb8430aa13b5ceccad2326b072f07',27,'SHA1:c6345562d879a917a35da54a54957531689d3271 MD5:fb0b1b130e974bfba010671be9a492e6 ADLER32:c78e10f7'),(479,5,'thumbnails/87/524-625-max.png','bf46822877427ad1b43666c11fe84eea',471,'524-625-max.png',8,6,304201,1717449841,1717449841,0,0,'5239938c98bd5a928a9f02d17898c243',27,'SHA1:e5d9c838e2d9074712f9a6b94d0a46059117d09d MD5:0488e28093d1d4d507ea64ab68c63f9a ADLER32:4780b74b'),(480,5,'thumbnails/79/760-468-max.png','62fa076e7f490de1124b08dce08d08e7',470,'760-468-max.png',8,6,496723,1717449841,1717449841,0,0,'216123a873f3344aed770b792424c8de',27,'SHA1:fbf7de85765e757b66e024107432559e09c7f08f MD5:cd3b36ace3aa0666384315fce3069da2 ADLER32:9987264f'),(481,5,'thumbnails/87/32-32.png','b99d8eb2c551da271b38885705299f08',471,'32-32.png',8,6,2601,1717449841,1717449841,0,0,'83b9afef5a2c4b2b9c3e78191143c90d',27,'SHA1:2cfcb4587af735943ffd43a0bca7ae51efcfc304 MD5:eab177a5fa9c85f7dd870b23c44b9c32 ADLER32:46020262'),(482,5,'thumbnails/79/32-32.png','08f8ae49dd44397bdea7a147571b85b7',470,'32-32.png',8,6,2814,1717449841,1717449841,0,0,'f5cef188b4cf135d67e71ddd8df2fede',27,'SHA1:68de53dd20df0454391e9b976b1dcf16c2813fbc MD5:193cb7df838d4fadab30d6a6680b57ec ADLER32:4bbe6009'),(483,5,'thumbnails/98','e8a9e548e7adc8a0dd3f47cb8fef8cc1',36,'98',2,1,0,1717449976,1717449976,0,0,'665e34f8df0a3',31,''),(484,5,'thumbnails/98/1024-768-max.png','82ffeefbf6ffab272cbeb51eae9ef750',483,'1024-768-max.png',8,6,126124,1717449976,1717449976,0,0,'bf5ad3d299a482fe4bd8b436a5797e7f',27,'SHA1:086cebd754e5c9904bbaa2dc059a6121a14de04c MD5:5c2870efdf5d7801fa3130dadb51fd19 ADLER32:3ba5ac68'),(485,5,'thumbnails/97','9a021b868b21df1543ceba05ce817901',36,'97',2,1,0,1717449977,1717449977,0,0,'665e34f8f3561',31,''),(486,5,'thumbnails/98/32-32.png','ea92b2083a488966e5b9782651911f4c',483,'32-32.png',8,6,987,1717449976,1717449976,0,0,'65ce90d832ba7acccc64562ab6164048',27,'SHA1:529ad3611d74b84ad207d5c1f014bd69928e2036 MD5:25fe0fca139f84378565e19617d1f068 ADLER32:7b277963'),(487,5,'thumbnails/97/1024-768-max.png','73e6af4df04a908b36886b81b801078f',485,'1024-768-max.png',8,6,89157,1717449977,1717449977,0,0,'abef845212e6f563235bfac3e5523955',27,'SHA1:d6153622a1cd5f1a4461714093fd79fa1a4b9eff MD5:4ae275ee9657ef18a8d00f2d6531e635 ADLER32:f116b037'),(488,5,'thumbnails/97/32-32.png','27d1032c2179f22bee83a4435dc76865',485,'32-32.png',8,6,982,1717449977,1717449977,0,0,'db492875a14d07d83e6f8ad4a59de2c6',27,'SHA1:0e9d22e3e841e7edabf4f840c82c0455454c8350 MD5:ac569379f1999910ebc831961daf8573 ADLER32:57a36e2a'),(489,5,'thumbnails/96','0910bd9f135d54118fe71571c05578a2',36,'96',2,1,0,1717449977,1717449977,0,0,'665e34f927bb8',31,''),(490,5,'thumbnails/96/2048-541-max.png','9cc8a36c1a1fa3cab5aea60fc1242139',489,'2048-541-max.png',8,6,211011,1717449977,1717449977,0,0,'47102a220791943b4cac3633b3b7efc7',27,'SHA1:bb9c2c65c2ce847e1a4074915d3df05526508da8 MD5:accd646949af5def623363377d018dcb ADLER32:01f8618d'),(491,5,'thumbnails/96/32-32.png','b1059d3fcc0f18ead11519b6878ee66a',489,'32-32.png',8,6,1005,1717449977,1717449977,0,0,'ca56db4220eaf3f577f47bfd98629362',27,'SHA1:18f94a96eb39d87194485545237a47990021268e MD5:eb59b9ea79166d417911e3c426e25c46 ADLER32:02918619'),(492,5,'thumbnails/84/537-401-with-aspect-cover.png','01b9c9d17081eb17b82245ffd07a8660',450,'537-401-with-aspect-cover.png',8,6,169120,1717450023,1717450023,0,0,'eea7d26d94b4c18bea1cd5cc18c093a8',27,'SHA1:6b62eec10ec712d8f4827fcb45474451362de2ae MD5:48306e25cdb308c8e937aeaf2e962690 ADLER32:b3883d5b'),(493,5,'thumbnails/81/754-904-with-aspect.png','f51b29896f6b75d08e508b6fe4356667',452,'754-904-with-aspect.png',8,6,259533,1717450234,1717450234,0,0,'e1e69adf2333faf531ad6de6174fe0ac',27,'SHA1:f17bf6c241faabd201958d1a77cbea79efaf9da4 MD5:8222ce8d50f57f5bb3d501b3c60441c0 ADLER32:c30c2a7d'),(494,5,'thumbnails/82/1092-928-with-aspect.png','fdbbdec9d57ed3f330958bf4322685e8',451,'1092-928-with-aspect.png',8,6,332897,1717450234,1717450234,0,0,'f98fdb29a2f82c14aa7eac5ae849f286',27,'SHA1:2627f0ceda7f0460c1512336f9e33a249a68192a MD5:72a3a5576e5a1830f4221d30a441fca6 ADLER32:8ebac638'),(495,5,'thumbnails/85/1582-1056-with-aspect.png','6ef6872d93b12b10ffa13cdefbee4192',457,'1582-1056-with-aspect.png',8,6,997909,1717450234,1717450234,0,0,'ccd73716970b17f4319a772ec563bfe7',27,'SHA1:581262a889a8647f2b3ec9319462288a628c98b5 MD5:cc1f3d1d4715c25da28288e8921abe13 ADLER32:2d628964'),(496,5,'thumbnails/84/1920-1433-with-aspect.png','0ea817aae57c1291c6c98d6c7a0f43b3',450,'1920-1433-with-aspect.png',8,6,958224,1717450235,1717450235,0,0,'436e0eb7cb578602d04ade1c57329a22',27,'SHA1:7917ef6669f4b8aced79ca9a6117c86ae6f3a438 MD5:58dbedbc1768e9ffd711602300b1b4e8 ADLER32:304583bd'),(497,5,'thumbnails/86/778-726-with-aspect.png','b3a16f467978fa8f2c12665225d85e7f',472,'778-726-with-aspect.png',8,6,67210,1717450237,1717450237,0,0,'b75dc42384c62b567a4be25d026d3607',27,'SHA1:e427e5edb5071e2082a379fc3e61c8f9eff2ce62 MD5:b67ac92fa1308c8811cfd103bea6d53d ADLER32:af47552f'),(498,5,'thumbnails/79/1520-936-with-aspect.png','e9ee2d4fb26a8b48b996723b5a783f5c',470,'1520-936-with-aspect.png',8,6,589604,1717450238,1717450238,0,0,'8abc3f7cdb9d2665c15dba0ee739d3ec',27,'SHA1:ae95344c2366a2b9ade4848b822b7b494f58a8ea MD5:3cfd12c78c8d04e6f9a8f687b57ef490 ADLER32:804e84cf'),(499,5,'thumbnails/87/1048-1250-with-aspect.png','b01e5ad1380bce39a1a1e57a0abceef8',471,'1048-1250-with-aspect.png',8,6,395681,1717450238,1717450238,0,0,'7615d65e82615ad8cb25b756273e07cc',27,'SHA1:a1939d2001738e44de2aba0538f66dfc48861c56 MD5:ae8cbbc4273fbe1b464ac5f810d8adf6 ADLER32:09dcc438'),(500,5,'thumbnails/83/766-916-with-aspect.png','da4e427026eee890d6aab0347b88331e',454,'766-916-with-aspect.png',8,6,65015,1717450242,1717450242,0,0,'be11876dc9358522a41b9bac046c5448',27,'SHA1:fec310ffeb8eac4d3ca1a2ffe5466ae25e5a70f8 MD5:8b1132eaaa881010b56fdfe63c029d90 ADLER32:e99d22a9'),(501,5,'thumbnails/89/858-1060-with-aspect.png','84606d9a3a9705b04457b59870ebf6d1',466,'858-1060-with-aspect.png',8,6,114338,1717450242,1717450242,0,0,'280019339a6baf5ca44de7c4f361ce1a',27,'SHA1:b8777869fb8fa38fc62a6acb79c9b4fd38efc3f1 MD5:4da2df41471194603c3491045ae90ec3 ADLER32:4d3cb90b'),(502,5,'thumbnails/80/900-1064-with-aspect.png','31481fee904040066c3f0e1ac49b5069',453,'900-1064-with-aspect.png',8,6,89792,1717450242,1717450242,0,0,'d32aa2cdb5484283d28b5ed271053e23',27,'SHA1:f9daa5bd90a8ad21183914459020e807e474a5b2 MD5:94b5bca0025378fceb487354abe80bf7 ADLER32:9bd7bcea'),(503,5,'thumbnails/88/1444-890-with-aspect.png','861744395eb50c53b93426f753be8ff1',467,'1444-890-with-aspect.png',8,6,528976,1717450244,1717450244,0,0,'ac5b15b5a1c2455a9525d45786541520',27,'SHA1:57d0b7190b75b3744d0bff790de029224a9c9739 MD5:552326ac3ab72dbbeb70e5ba9347a78d ADLER32:13cd469e'),(504,5,'thumbnails/81/538-645-with-aspect-cover.png','ccd0064f370f802a902a637f69753b25',452,'538-645-with-aspect-cover.png',8,6,346255,1717450259,1717450259,0,0,'ec7414fff93aca518aa1cd96b3c45a08',27,'SHA1:38ccb2f8aae7e82568df173e08cc5a6a3378ebf3 MD5:50fd6f0e286cb9cae692d3d72c4fa7ab ADLER32:b22092f2'),(505,3,'ocuser20','b62d30bd9ba9839a8dd6c3dcde58d72b',17,'ocuser20',2,1,-1,1717449679,1717449679,0,0,'665e5c0726fa8',31,''),(506,3,'ocuser20/files_versions','6c798924c5b4cfb9291660ba33058db3',505,'files_versions',2,1,-2,1717449680,1717449680,0,0,'665e5c072531a',31,''),(507,3,'ocuser20/files_versions/Documents','d4290926f4459a6f0f65ec1b96e81a65',506,'Documents',2,1,-1,1717449679,1717449679,0,0,'665e5c072dea8',31,''),(508,3,'ocuser20/files_versions/Learn more about ownCloud','fa9818e0c82133223c2051c852a73c30',506,'Learn more about ownCloud',2,1,-1,1717449680,1717449680,0,0,'665e5c072f890',31,''),(509,3,'ocuser20/files_versions/Photos','998ce517d49ec154154990a5da5e318d',506,'Photos',2,1,-1,1717449680,1717449680,0,0,'665e5c0730ba0',31,''),(510,3,'ocuser01','08439087ce7d489e0f484be1d3033635',17,'ocuser01',2,1,-1,1717449828,1717449828,0,0,'665f85a0e3cad',31,''),(511,3,'ocuser01/files_versions','5e90993bac51c4271be93f5d60faef03',510,'files_versions',2,1,-2,1717449829,1717449829,0,0,'665f85a0e023b',31,''),(512,3,'ocuser01/files_versions/Documents','410d7240e370e0fbb380d7bf9f43f296',511,'Documents',2,1,-1,1717449828,1717449828,0,0,'665f85a0e92c0',31,''),(513,3,'ocuser01/files_versions/Learn more about ownCloud','f531ba946168e4d1697252f5960cbc72',511,'Learn more about ownCloud',2,1,-1,1717449829,1717449829,0,0,'665f85a0eb726',31,''),(514,3,'ocuser01/files_versions/Photos','3ed7aaa50a68beb839cc56071b4ea62e',511,'Photos',2,1,-1,1717449829,1717449829,0,0,'665f85a0ecc49',31,''),(515,7,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1717536426,1717536424,0,0,'665f86aa03aef',23,''),(516,7,'cache','0fea6a13c52b4d4725368f24b045ca84',515,'cache',2,1,0,1717536424,1717536424,0,0,'665f86a890b0b',31,''),(517,7,'files','45b963397aa40d4a0063e0d85e4fe7a1',515,'files',2,1,4688555,1717536426,1717536425,0,0,'665f86aa03aef',31,''),(518,7,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',517,'Documents',2,1,36227,1717536424,1717536424,0,0,'665f86a8cee90',31,''),(519,7,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',518,'Example.odt',4,3,36227,1717536424,1717536424,0,0,'c1374d713ce15d86f4e6a4fc46333237',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(520,7,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',517,'Learn more about ownCloud',2,1,3640864,1717536425,1717536425,0,0,'665f86a992cbd',31,''),(521,7,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',520,'ownCloud Subscription Overview.pdf',5,3,1611431,1717536425,1717536425,0,0,'3d33fb532149c0e92f590173ab5f0db2',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(522,7,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',520,'Share files efficiently in your company.pdf',5,3,303237,1717536425,1717536425,0,0,'6779ea00c66a300f54b7e939c661971e',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(523,7,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',520,'Introducing ownCloud.pdf',5,3,238300,1717536425,1717536425,0,0,'685dc6103dcdaa305aad24dc94ada961',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(524,7,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',520,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717536425,1717536425,0,0,'0daaba48f40931c8d2231bb2e50491d2',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(525,7,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',520,'Safely leverage Microsoft Office.pdf',5,3,314348,1717536425,1717536425,0,0,'6d5c93043179dba2a3011b65aaeb17a6',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(526,7,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',520,'Keep your files safe with ownCloud.pdf',5,3,755022,1717536425,1717536425,0,0,'d354610489407c61f5fed67675e2887b',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(527,7,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',517,'Photos',2,1,1011464,1717536426,1717536425,0,0,'665f86aa03aef',31,''),(528,7,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',527,'Lake-Constance.jpg',7,6,538942,1717536425,1717536425,0,0,'c8a34f4602099fe38f8441e237be5ec3',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(529,7,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',527,'Teotihuacan.jpg',7,6,228789,1717536425,1717536425,0,0,'a5146ac54b8d46be8a7f5978ee522b79',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(530,7,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',527,'Portugal.jpg',7,6,243733,1717536426,1717536426,0,0,'c8afa2ce1da6aaaba34e0b6ce33a8807',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(531,3,'ocuser17','ade5c33acc7504b0b0f494b63a55e41f',17,'ocuser17',2,1,-1,1716936426,1716936426,0,0,'665fc06d320ef',31,''),(532,3,'ocuser11','67810e9fe883e36f71b043526a615eb9',17,'ocuser11',2,1,-1,1716936321,1716936321,0,0,'665fc06d334a6',31,''),(533,3,'ocuser14','2b18a08a23afe18012a6db228eadd4c9',17,'ocuser14',2,1,-1,1716936379,1716936379,0,0,'665fc06d343a4',31,''),(534,3,'ocuser13','1ff538c8741186683ad6a86fe5aa3ea9',17,'ocuser13',2,1,-1,1716936365,1716936365,0,0,'665fc06d351c6',31,''),(535,3,'admin','21232f297a57a5a743894a0e4a801fc3',17,'admin',2,1,-1,1717021238,1717021238,0,0,'665fc06d36249',31,''),(536,3,'ocuser05','2395e1b4814676d9b048564fb014d7e3',17,'ocuser05',2,1,-1,1716936232,1716936232,0,0,'665fc06d36eba',31,''),(537,3,'ocuser15','d32a3599bda063b7d39c14c8b3e0ec72',17,'ocuser15',2,1,-1,1716936393,1716936393,0,0,'665fc06d37db2',31,''),(538,3,'ocuser09','cfd45ab7968b9ce184b4cdbf350a7a29',17,'ocuser09',2,1,-1,1716936280,1716936280,0,0,'665fc06d38d4d',31,''),(539,3,'ocuser10','395e7231609c16730aa51b46f1e9f7b1',17,'ocuser10',2,1,-1,1716936306,1716936306,0,0,'665fc06d3bc14',31,''),(540,3,'owncloud.log','9703bd00121351aafcb85ff51784acc5',17,'owncloud.log',9,3,620449,1717536416,1717536416,0,0,'6b361c5bc1748897892f9be3d2fdf807',27,''),(541,3,'crash-2024-06-03.log','ab9e9dfa309a8c35a136ba4d0adf6b47',17,'crash-2024-06-03.log',9,3,1559928,1717386369,1717386369,0,0,'bba82f29747d61c99814296e85ff753d',27,''),(542,3,'files_encryption','171a8829416be21834bef1b79079dde8',17,'files_encryption',2,1,-1,1716940195,1716940195,0,0,'665fc06d3fadc',31,''),(543,3,'ocuser18','fee6aa0e4d11e4a43cbf7a03fcf997bb',17,'ocuser18',2,1,-1,1716936440,1716936440,0,0,'665fc06d408b6',31,''),(544,3,'htaccesstest.txt','7bccc20f7af3caba6981199fe6d83002',17,'htaccesstest.txt',11,10,145,1716942420,1716942420,0,0,'e3c07b4348486eaf959b9dddf720b304',27,''),(545,3,'ocuser08','3b4709f21946b403ef381473f41b560f',17,'ocuser08',2,1,-1,1716935963,1716935963,0,0,'665fc06d4426c',31,''),(546,3,'ocuser19','eedb06dd4d41aef568f2c8b03fe08238',17,'ocuser19',2,1,-1,1716936454,1716936454,0,0,'665fc06d4551a',31,''),(547,3,'ocuser07','2db4adaba32a25334f91510ddae9a403',17,'ocuser07',2,1,-1,1717360396,1717360396,0,0,'665fc06d474c1',31,''),(548,3,'.ocdata','a840ac417b1f143f29a22c7261756dad',17,'.ocdata',9,3,0,1715036516,1715036516,0,0,'87810b381475c52f6e535d8886fb04ba',27,''),(549,3,'ocuser16','1c11767a3b5eda6b603a8f53be265905',17,'ocuser16',2,1,-1,1716936410,1716936410,0,0,'665fc06d49c13',31,''),(550,3,'index.html','eacf331f0ffc35d4b482f1d15a887d3b',17,'index.html',12,10,0,1715036516,1715036516,0,0,'d23c2da46a9c954737c929422e06317a',27,''),(551,3,'ocuser03','a6846dc2df00091a0ca030c987df873c',17,'ocuser03',2,1,-1,1716936189,1716936189,0,0,'665fc06d4c230',31,''),(552,3,'ocuser12','5b73a4a6ad6835406bfe724548c2234e',17,'ocuser12',2,1,-1,1716936348,1716936348,0,0,'665fc06d4d08f',31,''),(553,3,'crash-2024-05-18.log','62637e4035e8cc4da687f700914e2d7e',17,'crash-2024-05-18.log',9,3,64588,1716003827,1716003827,0,0,'1fe95e0282c52731298b000100d1be36',27,''),(554,3,'ocuser02','cdafed160e18e00c2717b2f9ea3df047',17,'ocuser02',2,1,-1,1717536424,1717536424,0,0,'665fc06d4edcb',31,''),(555,3,'ocuser06','c95296032831fe38dc38e543844d8571',17,'ocuser06',2,1,-1,1716936247,1716936247,0,0,'665fc06d4fca9',31,''),(556,52,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,2759670443,1717553204,1717552919,0,0,'665fc8f4f1a10',23,''),(557,52,'cache','0fea6a13c52b4d4725368f24b045ca84',556,'cache',2,1,0,1717552918,1717552918,0,0,'665fc716cb269',31,''),(558,52,'files','45b963397aa40d4a0063e0d85e4fe7a1',556,'files',2,1,2759670443,1717553396,1717553396,0,0,'665fc8f4f1a10',31,''),(559,52,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',558,'Documents',2,1,36227,1717552919,1717552919,0,0,'665fc71732380',31,''),(560,52,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',559,'Example.odt',4,3,36227,1717552919,1717552919,0,0,'44ead84de3a10c9180707a47adf9cb97',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(561,52,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',558,'Learn more about ownCloud',2,1,3640864,1717552919,1717552919,0,0,'665fc717e389f',31,''),(562,52,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',561,'ownCloud Subscription Overview.pdf',5,3,1611431,1717552919,1717552919,0,0,'05ec81153b2341a1825f02fcba110e42',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(563,52,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',561,'Share files efficiently in your company.pdf',5,3,303237,1717552919,1717552919,0,0,'6bf6bf912c883ee993a20771afa08db9',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(564,52,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',561,'Introducing ownCloud.pdf',5,3,238300,1717552919,1717552919,0,0,'8c8e97afcac9e10f6734077c256e8beb',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(565,52,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',561,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717552919,1717552919,0,0,'795866eab4a771cf55263a243d8bf4d2',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(566,52,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',561,'Safely leverage Microsoft Office.pdf',5,3,314348,1717552919,1717552919,0,0,'81494a17f80a78115d39cf3c081f732c',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(567,52,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',561,'Keep your files safe with ownCloud.pdf',5,3,755022,1717552919,1717552919,0,0,'e4fc113ffc2f1d46c342e234674cccac',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(568,52,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',558,'Photos',2,1,1011464,1717552920,1717552920,0,0,'665fc718482b1',31,''),(569,52,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',568,'Lake-Constance.jpg',7,6,538942,1717552920,1717552920,0,0,'dfaf4224e95756e098bfc3b7e2ffecc9',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(570,52,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',568,'Teotihuacan.jpg',7,6,228789,1717552920,1717552920,0,0,'76e17604e17da4c7a59e97b300f423c0',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(571,52,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',568,'Portugal.jpg',7,6,243733,1717552920,1717552920,0,0,'de65b09fd692a01a2a744f84a9732aca',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(572,49,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,2759670443,1717553599,1717553025,0,0,'665fcb0c8d7f6',23,''),(573,49,'cache','0fea6a13c52b4d4725368f24b045ca84',572,'cache',2,1,0,1717553025,1717553025,0,0,'665fc78191dc0',31,''),(574,49,'files','45b963397aa40d4a0063e0d85e4fe7a1',572,'files',2,1,2759670443,1717553599,1717553026,0,0,'665fcb0c8d7f6',31,''),(575,49,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',574,'Documents',2,1,2755018115,1717553932,1717553932,0,0,'665fcb0c8d7f6',31,''),(576,49,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',575,'Example.odt',4,3,36227,1717553025,1717553025,0,0,'3d7fbb7fb516e34ce62c40315e0d67ec',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(577,49,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',574,'Learn more about ownCloud',2,1,3640864,1717553026,1717553026,0,0,'665fc7829ca76',31,''),(578,49,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',577,'ownCloud Subscription Overview.pdf',5,3,1611431,1717553026,1717553026,0,0,'6e59535c22181e1fa8432070ee7dcf37',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(579,49,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',577,'Share files efficiently in your company.pdf',5,3,303237,1717553026,1717553026,0,0,'b1f42e3e5cce016f9f561185c42fc249',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(580,49,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',577,'Introducing ownCloud.pdf',5,3,238300,1717553026,1717553026,0,0,'b688a65a7b6e2ef106ee16e588e56a8f',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(581,49,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',577,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717553026,1717553026,0,0,'4b48149e23638bc15694ecc22d5c88f5',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(582,49,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',577,'Safely leverage Microsoft Office.pdf',5,3,314348,1717553026,1717553026,0,0,'53070241bfd729383b703d7fabf28cff',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(583,49,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',577,'Keep your files safe with ownCloud.pdf',5,3,755022,1717553026,1717553026,0,0,'453c9be1b54f706d8abef3d4b637e72b',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(584,49,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',574,'Photos',2,1,1011464,1717553027,1717553027,0,0,'665fc7831b67e',31,''),(585,49,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',584,'Lake-Constance.jpg',7,6,538942,1717553026,1717553026,0,0,'3c50624b6a8ab9439c521b415deb938a',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(586,49,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',584,'Teotihuacan.jpg',7,6,228789,1717553027,1717553027,0,0,'f1ec8ce42fda1052c6b704b68f5d5cc1',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(587,49,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',584,'Portugal.jpg',7,6,243733,1717553027,1717553027,0,0,'4a5c21f48a219589506f82bfd7c8478f',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(588,46,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,0,1717553397,1717553397,0,0,'665fc8f5457ec',23,NULL),(853,52,'files/ubuntu-24.04-live-server-amd64.iso','f81a1c961f8b6490c86633a636430cab',558,'ubuntu-24.04-live-server-amd64.iso',9,3,2754981888,1717553204,1717553204,0,0,'b68c2ef13d4efe5842744776d47a21b7',27,'SHA1:15fd5417156fc406234108b3bf528d64e3a8cc7d MD5:b33b57dea8c827febc89f38b31d532e6 ADLER32:a61a5242'),(854,48,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,0,1717553932,1717553932,0,0,'665fcb0cd6401',23,NULL),(1119,49,'files/Documents/ubuntu-24.04-live-server-amd64.iso','cae1dcd020df315650147197a5e704cc',575,'ubuntu-24.04-live-server-amd64.iso',9,3,2754981888,1717553599,1717553599,0,0,'9e74ea507caa0270b9733641e418b686',27,'SHA1:15fd5417156fc406234108b3bf528d64e3a8cc7d MD5:b33b57dea8c827febc89f38b31d532e6 ADLER32:a61a5242'),(1120,51,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,2759670443,1717554046,1717554045,0,0,'665fccdceeb33',23,''),(1121,51,'cache','0fea6a13c52b4d4725368f24b045ca84',1120,'cache',2,1,0,1717554044,1717554044,0,0,'665fcb7cf2cbb',31,''),(1122,51,'files','45b963397aa40d4a0063e0d85e4fe7a1',1120,'files',2,1,2759670443,1717554046,1717554046,0,0,'665fccdceeb33',31,''),(1123,51,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',1122,'Documents',2,1,2755018115,1717554396,1717554396,0,0,'665fccdceeb33',31,''),(1124,51,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',1123,'Example.odt',4,3,36227,1717554045,1717554045,0,0,'aedd1bf28713bb19bfe6545a1b11d296',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(1125,51,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',1122,'Learn more about ownCloud',2,1,3640864,1717554045,1717554045,0,0,'665fcb7decea6',31,''),(1126,51,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',1125,'ownCloud Subscription Overview.pdf',5,3,1611431,1717554045,1717554045,0,0,'33fa5790501cd8f865ff38e6e2400a82',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(1127,51,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',1125,'Share files efficiently in your company.pdf',5,3,303237,1717554045,1717554045,0,0,'39ff1a7f479622b0293576904c393ed3',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(1128,51,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',1125,'Introducing ownCloud.pdf',5,3,238300,1717554045,1717554045,0,0,'3a6a46f3682f3b4fb7301b74c53eb22d',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(1129,51,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',1125,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1717554045,1717554045,0,0,'9954c9c76ae4b54152ef011cee63adc2',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(1130,51,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',1125,'Safely leverage Microsoft Office.pdf',5,3,314348,1717554045,1717554045,0,0,'7c689f81c9086361beeaec28444cbbcd',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(1131,51,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',1125,'Keep your files safe with ownCloud.pdf',5,3,755022,1717554046,1717554046,0,0,'41666ec382dd92e8ca2d944a089de815',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(1132,51,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',1122,'Photos',2,1,1011464,1717554046,1717554046,0,0,'665fcb7e56edf',31,''),(1133,51,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',1132,'Lake-Constance.jpg',7,6,538942,1717554046,1717554046,0,0,'3b2ad1d5f0bd6dd3efcc312a4f29b2e4',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(1134,51,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',1132,'Teotihuacan.jpg',7,6,228789,1717554046,1717554046,0,0,'355f3762c93d2c4dd8df0ee6b99262f7',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(1135,51,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',1132,'Portugal.jpg',7,6,243733,1717554046,1717554046,0,0,'c9b85c77596a91919fff00ff46a8a31e',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(1136,50,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,0,1717554397,1717554397,0,0,'665fccdd41050',23,NULL),(1401,51,'files/Documents/ubuntu-24.04-live-server-amd64.iso','cae1dcd020df315650147197a5e704cc',1123,'ubuntu-24.04-live-server-amd64.iso',9,3,2754981888,1717553599,1717553599,0,0,'7d321bebd8f539e3dd7c247ffefe970c',27,'SHA1:15fd5417156fc406234108b3bf528d64e3a8cc7d MD5:b33b57dea8c827febc89f38b31d532e6 ADLER32:a61a5242'),(1402,2,'thumbnails/14/1920-507-with-aspect.png','e44704b9173b69df96bbf35b905da371',26,'1920-507-with-aspect.png',8,6,170321,1717654202,1717654202,0,0,'9842cb18b8260c1f523e17abdc03fcee',27,'SHA1:5e290b1f26a6eea29cdab9ea13eec03a2c008e64 MD5:a658e266dc59129c8ae81eee082b6de7 ADLER32:07520496'),(1403,2,'thumbnails/16/1920-1440-with-aspect.png','3fe224624a9b1983c491cd2f182a0db8',20,'1920-1440-with-aspect.png',8,6,322063,1717654202,1717654202,0,0,'6332b26aadc313311afb3a75dc015af1',27,'SHA1:9705a9121bedbe9f23cf38c37b4dcce4f624367b MD5:495d7fa48a494c52bc31a3b1a8534f8e ADLER32:eaf12242');
/*!40000 ALTER TABLE `oc_filecache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_trash`
--

DROP TABLE IF EXISTS `oc_files_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_files_trash` (
  `auto_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` varchar(250) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timestamp` varchar(12) COLLATE utf8_bin NOT NULL DEFAULT '',
  `location` varchar(512) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  KEY `id_index` (`id`),
  KEY `timestamp_index` (`timestamp`),
  KEY `user_index` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_trash`
--

LOCK TABLES `oc_files_trash` WRITE;
/*!40000 ALTER TABLE `oc_files_trash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_trash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_admin`
--

DROP TABLE IF EXISTS `oc_group_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_group_admin` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `group_admin_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_admin`
--

LOCK TABLES `oc_group_admin` WRITE;
/*!40000 ALTER TABLE `oc_group_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_group_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_user`
--

DROP TABLE IF EXISTS `oc_group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_group_user` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `gu_uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_user`
--

LOCK TABLES `oc_group_user` WRITE;
/*!40000 ALTER TABLE `oc_group_user` DISABLE KEYS */;
INSERT INTO `oc_group_user` VALUES ('admin','admin'),('admin','admin01'),('admin','admin02'),('admin','admin03');
/*!40000 ALTER TABLE `oc_group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_groups`
--

DROP TABLE IF EXISTS `oc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_groups` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_groups`
--

LOCK TABLES `oc_groups` WRITE;
/*!40000 ALTER TABLE `oc_groups` DISABLE KEYS */;
INSERT INTO `oc_groups` VALUES ('admin');
/*!40000 ALTER TABLE `oc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_jobs`
--

DROP TABLE IF EXISTS `oc_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `argument` varchar(4000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `last_run` int(11) DEFAULT '0',
  `last_checked` int(11) DEFAULT '0',
  `reserved_at` int(11) DEFAULT '0',
  `execution_duration` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `job_class_index` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_jobs`
--

LOCK TABLES `oc_jobs` WRITE;
/*!40000 ALTER TABLE `oc_jobs` DISABLE KEYS */;
INSERT INTO `oc_jobs` VALUES (1,'OCA\\Files\\BackgroundJob\\ScanFiles','null',1717929085,1717929085,0,1),(2,'OCA\\Files\\BackgroundJob\\DeleteOrphanedItems','null',1717929089,1717929089,0,0),(3,'OCA\\Files\\BackgroundJob\\CleanupFileLocks','null',1717987526,1717987526,0,0),(4,'OCA\\Files\\BackgroundJob\\CleanupPersistentFileLocks','null',1718062376,1718062376,0,0),(5,'OCA\\Files\\BackgroundJob\\PreviewCleanupJob','null',1718062395,1718062395,0,0),(6,'OCA\\DAV\\CardDAV\\SyncJob','null',1718097510,1718097510,0,1),(7,'OCA\\DAV\\BackgroundJob\\CleanProperties','null',1717654188,1717654188,0,0),(8,'OCA\\Activity\\BackgroundJob\\EmailNotification','null',1717654195,1717654195,0,0),(9,'OCA\\Activity\\BackgroundJob\\ExpireActivities','null',1717713359,1717713359,0,0),(10,'OCA\\Federation\\SyncJob','null',1717713379,1717713379,0,0),(11,'OCA\\Files_Sharing\\DeleteOrphanedSharesJob','null',1717713409,1717713409,0,0),(12,'OCA\\Files_Sharing\\ExpireSharesJob','null',1717713462,1717713462,0,0),(13,'OCA\\Files_Sharing\\External\\ScanExternalSharesJob','null',1717716056,1717716056,0,0),(14,'OCA\\Files_Trashbin\\BackgroundJob\\ExpireTrash','null',1717717734,1717717734,0,0),(15,'OCA\\Files_Versions\\BackgroundJob\\ExpireVersions','null',1717732639,1717732639,0,0),(16,'OCA\\Market\\CheckUpdateBackgroundJob','null',1717732655,1717732655,0,3),(17,'OCA\\UpdateNotification\\Notification\\BackgroundJob','null',1717732659,1717732659,0,1),(18,'\\OC\\Authentication\\Token\\DefaultTokenCleanupJob','null',1717929079,1717929079,0,0);
/*!40000 ALTER TABLE `oc_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_migrations`
--

DROP TABLE IF EXISTS `oc_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_migrations` (
  `app` varchar(177) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`app`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_migrations`
--

LOCK TABLES `oc_migrations` WRITE;
/*!40000 ALTER TABLE `oc_migrations` DISABLE KEYS */;
INSERT INTO `oc_migrations` VALUES ('activity','20161122085340'),('activity','20161122092159'),('activity','20170131134507'),('activity','20170724182159'),('activity','20181019151118'),('activity','20181022150134'),('core','20170101010100'),('core','20170101215145'),('core','20170111103310'),('core','20170213215145'),('core','20170214112458'),('core','20170221114437'),('core','20170221121536'),('core','20170315173825'),('core','20170320173955'),('core','20170418154659'),('core','20170516100103'),('core','20170526104128'),('core','20170605143658'),('core','20170711191432'),('core','20170804201253'),('core','20170928120000'),('core','20171026130750'),('core','20180123131835'),('core','20180302155233'),('core','20180319102121'),('core','20180607072706'),('core','20181017105216'),('core','20181017120818'),('core','20181113071753'),('core','20181220085457'),('core','20190125162909'),('core','20200610110817'),('core','20210928123126'),('core','20230105001100'),('core','20230120101715'),('core','20230210073645'),('core','20230210103154'),('core','20240112140951'),('core','20240131080456'),('dav','20170116150538'),('dav','20170116170538'),('dav','20170202213905'),('dav','20170202220512'),('dav','20170427182800'),('dav','20170519091921'),('dav','20170526100342'),('dav','20170711193427'),('dav','20170927201245'),('dav','20180622095921'),('dav','20181115210344'),('dav','20190823065724'),('dav','20200114181454'),('dav','20200427142541'),('dav','20210714123001'),('federatedfilesharing','20170804201125'),('federatedfilesharing','20170804201253'),('federatedfilesharing','20190410160725'),('files_external','20170814051424'),('files_external','20210511082903'),('files_external','20220329110116'),('files_sharing','20170804201125'),('files_sharing','20170804201253'),('files_sharing','20170830112305'),('files_sharing','20171115154900'),('files_sharing','20171215103657'),('files_sharing','20190426123324'),('files_sharing','20200504211654'),('files_sharing','20200823121322'),('files_trashbin','20170804201125'),('files_trashbin','20170804201253'),('notifications','20170801085340'),('notifications','20170801152524'),('notifications','20180119080933'),('notifications','20180604132522');
/*!40000 ALTER TABLE `oc_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mimetypes`
--

DROP TABLE IF EXISTS `oc_mimetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_mimetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mimetype` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mimetype_id_index` (`mimetype`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mimetypes`
--

LOCK TABLES `oc_mimetypes` WRITE;
/*!40000 ALTER TABLE `oc_mimetypes` DISABLE KEYS */;
INSERT INTO `oc_mimetypes` VALUES (3,'application'),(9,'application/octet-stream'),(5,'application/pdf'),(4,'application/vnd.oasis.opendocument.text'),(1,'httpd'),(2,'httpd/unix-directory'),(6,'image'),(7,'image/jpeg'),(8,'image/png'),(10,'text'),(12,'text/html'),(11,'text/plain');
/*!40000 ALTER TABLE `oc_mimetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mounts`
--

DROP TABLE IF EXISTS `oc_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_mounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage_id` int(11) NOT NULL,
  `root_id` bigint(20) NOT NULL,
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `mount_point` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mounts_user_root_index` (`user_id`,`root_id`),
  KEY `mounts_user_index` (`user_id`),
  KEY `mounts_storage_index` (`storage_id`),
  KEY `mounts_root_index` (`root_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mounts`
--

LOCK TABLES `oc_mounts` WRITE;
/*!40000 ALTER TABLE `oc_mounts` DISABLE KEYS */;
INSERT INTO `oc_mounts` VALUES (1,2,1,'admin','/admin/'),(2,5,33,'ocuser01','/ocuser01/'),(3,9,99,'ocuser03','/ocuser03/'),(4,11,115,'ocuser04','/ocuser04/'),(5,13,140,'ocuser05','/ocuser05/'),(6,15,156,'ocuser06','/ocuser06/'),(7,17,172,'ocuser07','/ocuser07/'),(8,19,192,'ocuser08','/ocuser08/'),(9,21,208,'ocuser09','/ocuser09/'),(10,23,224,'ocuser10','/ocuser10/'),(11,25,240,'ocuser11','/ocuser11/'),(12,27,256,'ocuser12','/ocuser12/'),(13,29,272,'ocuser13','/ocuser13/'),(14,31,288,'ocuser14','/ocuser14/'),(15,33,304,'ocuser15','/ocuser15/'),(16,35,320,'ocuser16','/ocuser16/'),(17,37,336,'ocuser17','/ocuser17/'),(18,39,352,'ocuser18','/ocuser18/'),(19,41,368,'ocuser19','/ocuser19/'),(20,43,384,'ocuser20','/ocuser20/'),(21,7,515,'ocuser02','/ocuser02/'),(22,52,556,'admin03','/admin03/'),(23,49,572,'admin01','/admin01/'),(24,46,588,'admin03','/admin03/uploads/'),(25,48,854,'admin01','/admin01/uploads/'),(26,51,1120,'admin02','/admin02/'),(27,50,1136,'admin02','/admin02/uploads/');
/*!40000 ALTER TABLE `oc_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications`
--

DROP TABLE IF EXISTS `oc_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(32) COLLATE utf8_bin NOT NULL,
  `user` varchar(64) COLLATE utf8_bin NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `subject` varchar(64) COLLATE utf8_bin NOT NULL,
  `subject_parameters` longtext COLLATE utf8_bin,
  `message` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `message_parameters` longtext COLLATE utf8_bin,
  `link` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `actions` longtext COLLATE utf8_bin,
  `icon` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `IDX_16B80748C96E70CF` (`app`),
  KEY `IDX_16B807488D93D649` (`user`),
  KEY `IDX_16B80748A5D6E63E` (`timestamp`),
  KEY `IDX_16B8074811CB6B3A232D562B` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications`
--

LOCK TABLES `oc_notifications` WRITE;
/*!40000 ALTER TABLE `oc_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_persistent_locks`
--

DROP TABLE IF EXISTS `oc_persistent_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_persistent_locks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL COMMENT 'FK to fileid in table oc_file_cache',
  `owner_account_id` bigint(20) unsigned DEFAULT NULL COMMENT 'owner of the lock - FK to account table',
  `owner` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT 'owner of the lock - just a human readable string',
  `timeout` int(10) unsigned NOT NULL COMMENT 'timestamp when the lock expires',
  `created_at` int(10) unsigned NOT NULL COMMENT 'timestamp when the lock was created',
  `token` varchar(1024) COLLATE utf8_bin NOT NULL COMMENT 'uuid for webdav locks - 1024 random chars for WOPI locks',
  `token_hash` varchar(32) COLLATE utf8_bin NOT NULL COMMENT 'md5(token)',
  `scope` smallint(6) NOT NULL COMMENT '1 - exclusive, 2 - shared',
  `depth` smallint(6) NOT NULL COMMENT '0, 1 or infinite',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F0C3D55BB3BC57DA` (`token_hash`),
  KEY `IDX_F0C3D55B93CB796C` (`file_id`),
  KEY `IDX_F0C3D55BC901C6FF` (`owner_account_id`),
  CONSTRAINT `FK_F0C3D55B93CB796C` FOREIGN KEY (`file_id`) REFERENCES `oc_filecache` (`fileid`) ON DELETE CASCADE,
  CONSTRAINT `FK_F0C3D55BC901C6FF` FOREIGN KEY (`owner_account_id`) REFERENCES `oc_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_persistent_locks`
--

LOCK TABLES `oc_persistent_locks` WRITE;
/*!40000 ALTER TABLE `oc_persistent_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_persistent_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_preferences`
--

DROP TABLE IF EXISTS `oc_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_preferences` (
  `userid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `appid` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8_bin,
  PRIMARY KEY (`userid`,`appid`,`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_preferences`
--

LOCK TABLES `oc_preferences` WRITE;
/*!40000 ALTER TABLE `oc_preferences` DISABLE KEYS */;
INSERT INTO `oc_preferences` VALUES ('admin','core','lang','en'),('admin','core','timezone','Pacific/Auckland'),('admin','files','file_sorting','mtime'),('admin','files','file_sorting_direction','desc'),('admin','firstrunwizard','show','0'),('admin01','core','lang','en_GB'),('admin01','core','timezone','Pacific/Auckland'),('admin01','firstrunwizard','show','0'),('admin02','core','lang','en_GB'),('admin02','core','timezone','Pacific/Auckland'),('admin02','firstrunwizard','show','0'),('admin03','core','lang','en'),('admin03','core','timezone','Pacific/Auckland'),('admin03','firstrunwizard','show','0'),('ocuser01','core','lang','en'),('ocuser01','core','timezone','Pacific/Auckland'),('ocuser01','firstrunwizard','show','0'),('ocuser02','core','lang','en'),('ocuser02','core','timezone','Pacific/Auckland'),('ocuser02','firstrunwizard','show','0'),('ocuser04','core','lang','en'),('ocuser04','core','timezone','Pacific/Auckland'),('ocuser04','firstrunwizard','show','0'),('ocuser20','core','lang','en'),('ocuser20','core','timezone','Pacific/Auckland'),('ocuser20','firstrunwizard','show','0');
/*!40000 ALTER TABLE `oc_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_privatedata`
--

DROP TABLE IF EXISTS `oc_privatedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_privatedata` (
  `keyid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `app` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `key` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`keyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_privatedata`
--

LOCK TABLES `oc_privatedata` WRITE;
/*!40000 ALTER TABLE `oc_privatedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_privatedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_properties`
--

DROP TABLE IF EXISTS `oc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_properties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fileid` bigint(20) unsigned NOT NULL,
  `propertyname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyvalue` varchar(255) COLLATE utf8_bin NOT NULL,
  `propertytype` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fileid_index` (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_properties`
--

LOCK TABLES `oc_properties` WRITE;
/*!40000 ALTER TABLE `oc_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_schedulingobjects`
--

DROP TABLE IF EXISTS `oc_schedulingobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_schedulingobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_schedulingobjects`
--

LOCK TABLES `oc_schedulingobjects` WRITE;
/*!40000 ALTER TABLE `oc_schedulingobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_schedulingobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share`
--

DROP TABLE IF EXISTS `oc_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `share_type` smallint(6) NOT NULL DEFAULT '0',
  `share_with` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uid_owner` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid_initiator` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_source` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `item_target` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `file_source` bigint(20) DEFAULT NULL,
  `file_target` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `permissions` smallint(6) NOT NULL DEFAULT '0',
  `stime` bigint(20) NOT NULL DEFAULT '0',
  `accepted` smallint(6) NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `mail_send` smallint(6) NOT NULL DEFAULT '0',
  `share_name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `attributes` longtext COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `item_share_type_index` (`item_type`,`share_type`),
  KEY `file_source_index` (`file_source`),
  KEY `token_index` (`token`),
  KEY `share_with_index` (`share_with`),
  KEY `item_source_index` (`item_source`),
  KEY `item_source_type_index` (`item_source`,`share_type`,`item_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share`
--

LOCK TABLES `oc_share` WRITE;
/*!40000 ALTER TABLE `oc_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share_external`
--

DROP TABLE IF EXISTS `oc_share_external`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_share_external` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `remote` varchar(512) COLLATE utf8_bin NOT NULL COMMENT 'Url of the remote owncloud instance',
  `remote_id` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '-1',
  `share_token` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'Public share token',
  `password` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT 'Optional password for the public share',
  `name` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'Original name on the remote server',
  `owner` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'User that owns the public share on the remote server',
  `user` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'Local user which added the external share',
  `mountpoint` varchar(4000) COLLATE utf8_bin NOT NULL COMMENT 'Full path where the share is mounted',
  `mountpoint_hash` varchar(32) COLLATE utf8_bin NOT NULL COMMENT 'md5 hash of the mountpoint',
  `accepted` int(11) NOT NULL DEFAULT '0',
  `lastscan` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sh_external_mp` (`user`,`mountpoint_hash`),
  KEY `sh_external_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share_external`
--

LOCK TABLES `oc_share_external` WRITE;
/*!40000 ALTER TABLE `oc_share_external` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share_external` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages`
--

DROP TABLE IF EXISTS `oc_storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_storages` (
  `id` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `numeric_id` int(11) NOT NULL AUTO_INCREMENT,
  `available` int(11) NOT NULL DEFAULT '1',
  `last_checked` int(11) DEFAULT NULL,
  PRIMARY KEY (`numeric_id`),
  UNIQUE KEY `storages_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages`
--

LOCK TABLES `oc_storages` WRITE;
/*!40000 ALTER TABLE `oc_storages` DISABLE KEYS */;
INSERT INTO `oc_storages` VALUES ('local::/var/www/owncloud/data/admin/uploads/',1,1,NULL),('home::admin',2,1,NULL),('local::/var/www/owncloud/data/',3,1,NULL),('local::/var/www/owncloud/data/ocuser01/uploads/',4,1,NULL),('home::ocuser01',5,1,NULL),('local::/var/www/owncloud/data/ocuser02/uploads/',6,1,NULL),('home::ocuser02',7,1,NULL),('local::/var/www/owncloud/data/ocuser03/uploads/',8,1,NULL),('home::ocuser03',9,1,NULL),('local::/var/www/owncloud/data/ocuser04/uploads/',10,1,NULL),('home::ocuser04',11,1,NULL),('local::/var/www/owncloud/data/ocuser05/uploads/',12,1,NULL),('home::ocuser05',13,1,NULL),('local::/var/www/owncloud/data/ocuser06/uploads/',14,1,NULL),('home::ocuser06',15,1,NULL),('local::/var/www/owncloud/data/ocuser07/uploads/',16,1,NULL),('home::ocuser07',17,1,NULL),('local::/var/www/owncloud/data/ocuser08/uploads/',18,1,NULL),('home::ocuser08',19,1,NULL),('local::/var/www/owncloud/data/ocuser09/uploads/',20,1,NULL),('home::ocuser09',21,1,NULL),('local::/var/www/owncloud/data/ocuser10/uploads/',22,1,NULL),('home::ocuser10',23,1,NULL),('local::/var/www/owncloud/data/ocuser11/uploads/',24,1,NULL),('home::ocuser11',25,1,NULL),('local::/var/www/owncloud/data/ocuser12/uploads/',26,1,NULL),('home::ocuser12',27,1,NULL),('local::/var/www/owncloud/data/ocuser13/uploads/',28,1,NULL),('home::ocuser13',29,1,NULL),('local::/var/www/owncloud/data/ocuser14/uploads/',30,1,NULL),('home::ocuser14',31,1,NULL),('local::/var/www/owncloud/data/ocuser15/uploads/',32,1,NULL),('home::ocuser15',33,1,NULL),('local::/var/www/owncloud/data/ocuser16/uploads/',34,1,NULL),('home::ocuser16',35,1,NULL),('local::/var/www/owncloud/data/ocuser17/uploads/',36,1,NULL),('home::ocuser17',37,1,NULL),('local::/var/www/owncloud/data/ocuser18/uploads/',38,1,NULL),('home::ocuser18',39,1,NULL),('local::/var/www/owncloud/data/ocuser19/uploads/',40,1,NULL),('home::ocuser19',41,1,NULL),('local::/var/www/owncloud/data/ocuser20/uploads/',42,1,NULL),('home::ocuser20',43,1,NULL),('local::/var/www/owncloud/data/testuser/uploads/',44,1,NULL),('local::/var/www/owncloud/data/admin03/uploads/',46,1,NULL),('local::/var/www/owncloud/data/admin01/uploads/',48,1,NULL),('home::admin01',49,1,NULL),('local::/var/www/owncloud/data/admin02/uploads/',50,1,NULL),('home::admin02',51,1,NULL),('home::admin03',52,1,NULL);
/*!40000 ALTER TABLE `oc_storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag`
--

DROP TABLE IF EXISTS `oc_systemtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `visibility` smallint(6) NOT NULL DEFAULT '1',
  `editable` smallint(6) NOT NULL DEFAULT '1',
  `assignable` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_ident` (`name`,`visibility`,`editable`,`assignable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag`
--

LOCK TABLES `oc_systemtag` WRITE;
/*!40000 ALTER TABLE `oc_systemtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_group`
--

DROP TABLE IF EXISTS `oc_systemtag_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag_group` (
  `systemtagid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`gid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_group`
--

LOCK TABLES `oc_systemtag_group` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_object_mapping`
--

DROP TABLE IF EXISTS `oc_systemtag_object_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag_object_mapping` (
  `objectid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `objecttype` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `systemtagid` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `mapping` (`objecttype`,`objectid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_object_mapping`
--

LOCK TABLES `oc_systemtag_object_mapping` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_trusted_servers`
--

DROP TABLE IF EXISTS `oc_trusted_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_trusted_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(512) COLLATE utf8_bin NOT NULL COMMENT 'Url of trusted server',
  `url_hash` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'sha1 hash of the url without the protocol',
  `token` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT 'token used to exchange the shared secret',
  `shared_secret` varchar(256) COLLATE utf8_bin DEFAULT NULL COMMENT 'shared secret used to authenticate',
  `status` int(11) NOT NULL DEFAULT '2' COMMENT 'current status of the connection',
  `sync_token` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT 'cardDav sync token',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_hash` (`url_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_trusted_servers`
--

LOCK TABLES `oc_trusted_servers` WRITE;
/*!40000 ALTER TABLE `oc_trusted_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_trusted_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_users`
--

DROP TABLE IF EXISTS `oc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_users` (
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `displayname` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_users`
--

LOCK TABLES `oc_users` WRITE;
/*!40000 ALTER TABLE `oc_users` DISABLE KEYS */;
INSERT INTO `oc_users` VALUES ('admin',NULL,'1|$2y$10$biQHfOhhzaiEuFLMI2n3mOsvjwuPtuv8mC7TSdluhTIco9E.nk4NK'),('admin01',NULL,'1|$2y$10$BWfFmrTpEvCWslIGAEdnFOZ3CbxfLLMJU0dirHQ4wS2CIsjChz5Sa'),('admin02',NULL,'1|$2y$10$IEoDpguLsEPISFVGhqVLMeu/vRYYqD7Ph3imY1cENwqdv6DES3Ype'),('admin03',NULL,'1|$2y$10$3/KB0zq5wMtxiW/NunTYROr7CPvwidYK671haapMWe2LRtdhW6OH6'),('ocuser01',NULL,'1|$2y$10$U2uHvxh/5Swdynw4lEnCMOq1Zh3MANM2A/aHw07XTs3Zo/L/kMomS'),('ocuser02',NULL,'1|$2y$10$e9J8jMBtwGRVt/PUpToRoe1drCK/qoBlg8AFSSZ0HYkkWgRYMO86G'),('ocuser03',NULL,'1|$2y$10$kA/k9G1HBvmr1F6wm8CPM.hJKhSt4rv4ut9jyrraWs6qxC4Nq.y.W'),('ocuser04',NULL,'1|$2y$10$ePboSAG2BNdbC1PrQrg2KOnwh3QFJd3McfJauUUBy3nqXc99XjWW6'),('ocuser05',NULL,'1|$2y$10$rqU/rOvH3TuX6Id5oiLWVesFrAbpnJcd4gSeAuYp9.zBUKWW4q1xa'),('ocuser06',NULL,'1|$2y$10$MJ1e9/QoNnZZDxuS4XibW.5lPU5fL0hwiDa5UjWBd0ehjcPuPF4qS'),('ocuser07',NULL,'1|$2y$10$tad6d9l6LH1DhRl3eKAk0O7.jQvr3AL27a3hhAdgHYZQP8S5Kbjry'),('ocuser08',NULL,'1|$2y$10$wyAH16TwBSvgBPuIgNRC2.SRajvoKMVDm26.I4VTfI6H6AiOIWvxy'),('ocuser09',NULL,'1|$2y$10$/cCZ.oHVEAudTKpZ2lxjFe7KR6HnYZo3AMOG967oEF58C6rWhZ1rC'),('ocuser10',NULL,'1|$2y$10$h9l0s1AKTvZNZoD32tOAQ.ZXiomNDfzc5HdoUZgFnQVqSzKvV2wRy'),('ocuser11',NULL,'1|$2y$10$M5y5/4R6IdPQzqN9lFDRU.f.ywj/vngOqqEJVG/ZxTKeOe6iOJU2O'),('ocuser12',NULL,'1|$2y$10$LtOr2Rc/aExiJo0sbnR97OPjtRXOQxKZnFTiifbx0ZON9ztvgplgO'),('ocuser13',NULL,'1|$2y$10$be7dJ99cmEu8Du5bMjhyTOhq3aNp72xSXV8ZdkirR5uh5AT.9rJMu'),('ocuser14',NULL,'1|$2y$10$sLGBbbA8O/.7KlQwJCZVlOy0bYxGqLMvhZaDe5hSOG1xiP5Nuiflq'),('ocuser15',NULL,'1|$2y$10$2UTBh9apO2Zp90kcNNcTLOHd0ymMzPgltTipmKJIEhNGhEZMwyVeC'),('ocuser16',NULL,'1|$2y$10$fsUSt0eHRcy1lTzx0.tmgusw40.VP9bxr7CF.cO7jAShaK2AzpoVC'),('ocuser17',NULL,'1|$2y$10$ncXAUpVlmfz6I1R9q/hp5eReVhzDGnd.65jRn3ksw7seZAbb4X26m'),('ocuser18',NULL,'1|$2y$10$qcL9qEBE9876VCGpazfa2.QaqMKtQXa0gr4vmcwHHZxIlnuk2BidW'),('ocuser19',NULL,'1|$2y$10$rQj.reWXoHYpRcSffY/zdOcvBKcN3evVScJ5DXSg.nq6k1H3XyAF2'),('ocuser20',NULL,'1|$2y$10$eRRJUIU34JNg2rH.yvxquudEOe1BMybXaj9.ni6NqfzLq2XoIt1SC');
/*!40000 ALTER TABLE `oc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory`
--

DROP TABLE IF EXISTS `oc_vcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_vcategory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `category` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uid_index` (`uid`),
  KEY `type_index` (`type`),
  KEY `category_index` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory`
--

LOCK TABLES `oc_vcategory` WRITE;
/*!40000 ALTER TABLE `oc_vcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory_to_object`
--

DROP TABLE IF EXISTS `oc_vcategory_to_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_vcategory_to_object` (
  `objid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `categoryid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryid`,`objid`,`type`),
  KEY `vcategory_objectd_index` (`objid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory_to_object`
--

LOCK TABLES `oc_vcategory_to_object` WRITE;
/*!40000 ALTER TABLE `oc_vcategory_to_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory_to_object` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-12  8:00:01
