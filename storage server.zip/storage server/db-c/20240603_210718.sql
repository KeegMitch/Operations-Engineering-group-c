-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: owncloud
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oc_account_terms`
--

DROP TABLE IF EXISTS `oc_account_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_account_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint(20) unsigned NOT NULL,
  `term` varchar(191) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id_index` (`account_id`),
  KEY `term_index` (`term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_account_terms`
--

LOCK TABLES `oc_account_terms` WRITE;
/*!40000 ALTER TABLE `oc_account_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_account_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_accounts`
--

DROP TABLE IF EXISTS `oc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `lower_user_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `display_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `quota` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `last_login` int(11) NOT NULL DEFAULT '0',
  `backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `home` varchar(1024) COLLATE utf8_bin NOT NULL,
  `state` smallint(6) NOT NULL DEFAULT '0' COMMENT '0: initial, 1: enabled, 2: disabled, 3: deleted',
  `creation_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_907AA303A76ED395` (`user_id`),
  UNIQUE KEY `lower_user_id_index` (`lower_user_id`),
  KEY `display_name_index` (`display_name`),
  KEY `email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts`
--

LOCK TABLES `oc_accounts` WRITE;
/*!40000 ALTER TABLE `oc_accounts` DISABLE KEYS */;
INSERT INTO `oc_accounts` VALUES (1,NULL,'admin','admin','admin',NULL,1717405486,'OC\\User\\Database','/var/www/owncloud/data/admin',1,1715036500),(2,NULL,'ocuser01','ocuser01','ocuser01',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser01',1,1717405364),(3,NULL,'ocuser02','ocuser02','ocuser02',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser02',1,1717405365),(4,NULL,'ocuser03','ocuser03','ocuser03',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser03',1,1717405365),(5,NULL,'ocuser04','ocuser04','ocuser04',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser04',1,1717405366),(6,NULL,'ocuser05','ocuser05','ocuser05',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser05',1,1717405366),(7,NULL,'ocuser06','ocuser06','ocuser06',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser06',1,1717405366),(8,NULL,'ocuser07','ocuser07','ocuser07',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser07',1,1717405367),(9,NULL,'ocuser08','ocuser08','ocuser08',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser08',1,1717405367),(10,NULL,'ocuser09','ocuser09','ocuser09',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser09',1,1717405368),(11,NULL,'ocuser10','ocuser10','ocuser10',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser10',1,1717405368),(12,NULL,'ocuser11','ocuser11','ocuser11',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser11',1,1717405368),(13,NULL,'ocuser12','ocuser12','ocuser12',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser12',1,1717405369),(14,NULL,'ocuser13','ocuser13','ocuser13',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser13',1,1717405369),(15,NULL,'ocuser14','ocuser14','ocuser14',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser14',1,1717405369),(16,NULL,'ocuser15','ocuser15','ocuser15',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser15',1,1717405370),(17,NULL,'ocuser16','ocuser16','ocuser16',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser16',1,1717405370),(18,NULL,'ocuser17','ocuser17','ocuser17',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser17',1,1717405371),(19,NULL,'ocuser18','ocuser18','ocuser18',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser18',1,1717405371),(20,NULL,'ocuser19','ocuser19','ocuser19',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser19',1,1717405371),(21,NULL,'ocuser20','ocuser20','ocuser20',NULL,0,'OC\\User\\Database','/var/www/owncloud/data/ocuser20',1,1717405372);
/*!40000 ALTER TABLE `oc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity`
--

DROP TABLE IF EXISTS `oc_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_activity` (
  `activity_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `user` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `affecteduser` varchar(64) COLLATE utf8_bin NOT NULL,
  `app` varchar(255) COLLATE utf8_bin NOT NULL,
  `subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `subjectparams` longtext COLLATE utf8_bin NOT NULL,
  `message` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `messageparams` longtext COLLATE utf8_bin,
  `file` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `link` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `object_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `object_id` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`activity_id`),
  KEY `activity_time` (`timestamp`),
  KEY `activity_user_time` (`affecteduser`,`timestamp`),
  KEY `activity_filter_by` (`affecteduser`,`user`,`timestamp`),
  KEY `activity_filter_app` (`affecteduser`,`app`,`timestamp`),
  KEY `activity_object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity`
--

LOCK TABLES `oc_activity` WRITE;
/*!40000 ALTER TABLE `oc_activity` DISABLE KEYS */;
INSERT INTO `oc_activity` VALUES (1,1715036538,30,'file_created','admin','admin','files','created_self','[{\"3\":\"\"}]','','[]','','http://13.75.139.57/index.php/apps/files/?dir=','files',3),(2,1715036538,30,'file_created','admin','admin','files','created_self','[{\"4\":\"\\/Documents\"}]','','[]','/Documents','http://13.75.139.57/index.php/apps/files/?dir=/','files',4),(3,1715036539,30,'file_created','admin','admin','files','created_self','[{\"5\":\"\\/Documents\\/Example.odt\"}]','','[]','/Documents/Example.odt','http://13.75.139.57/index.php/apps/files/?dir=/Documents','files',5),(4,1715036539,30,'file_created','admin','admin','files','created_self','[{\"6\":\"\\/Learn more about ownCloud\"}]','','[]','/Learn more about ownCloud','http://13.75.139.57/index.php/apps/files/?dir=/','files',6),(5,1715036539,30,'file_created','admin','admin','files','created_self','[{\"7\":\"\\/Learn more about ownCloud\\/ownCloud Subscription Overview.pdf\"}]','','[]','/Learn more about ownCloud/ownCloud Subscription Overview.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',7),(6,1715036539,30,'file_created','admin','admin','files','created_self','[{\"8\":\"\\/Learn more about ownCloud\\/Share files efficiently in your company.pdf\"}]','','[]','/Learn more about ownCloud/Share files efficiently in your company.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',8),(7,1715036539,30,'file_created','admin','admin','files','created_self','[{\"9\":\"\\/Learn more about ownCloud\\/Introducing ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Introducing ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',9),(8,1715036539,30,'file_created','admin','admin','files','created_self','[{\"10\":\"\\/Learn more about ownCloud\\/Data Protection and Data Secrecy in ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',10),(9,1715036539,30,'file_created','admin','admin','files','created_self','[{\"11\":\"\\/Learn more about ownCloud\\/Safely leverage Microsoft Office.pdf\"}]','','[]','/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',11),(10,1715036539,30,'file_created','admin','admin','files','created_self','[{\"12\":\"\\/Learn more about ownCloud\\/Keep your files safe with ownCloud.pdf\"}]','','[]','/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','http://13.75.139.57/index.php/apps/files/?dir=/Learn%20more%20about%20ownCloud','files',12),(11,1715036539,30,'file_created','admin','admin','files','created_self','[{\"13\":\"\\/Photos\"}]','','[]','/Photos','http://13.75.139.57/index.php/apps/files/?dir=/','files',13),(12,1715036539,30,'file_created','admin','admin','files','created_self','[{\"14\":\"\\/Photos\\/Lake-Constance.jpg\"}]','','[]','/Photos/Lake-Constance.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',14),(13,1715036539,30,'file_created','admin','admin','files','created_self','[{\"15\":\"\\/Photos\\/Teotihuacan.jpg\"}]','','[]','/Photos/Teotihuacan.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',15),(14,1715036540,30,'file_created','admin','admin','files','created_self','[{\"16\":\"\\/Photos\\/Portugal.jpg\"}]','','[]','/Photos/Portugal.jpg','http://13.75.139.57/index.php/apps/files/?dir=/Photos','files',16);
/*!40000 ALTER TABLE `oc_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity_mq`
--

DROP TABLE IF EXISTS `oc_activity_mq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_activity_mq` (
  `mail_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amq_timestamp` int(11) NOT NULL DEFAULT '0',
  `amq_latest_send` int(11) NOT NULL DEFAULT '0',
  `amq_type` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_affecteduser` varchar(64) COLLATE utf8_bin NOT NULL,
  `amq_appid` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_subject` varchar(255) COLLATE utf8_bin NOT NULL,
  `amq_subjectparams` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`mail_id`),
  KEY `amp_user` (`amq_affecteduser`),
  KEY `amp_latest_send_time` (`amq_latest_send`),
  KEY `amp_timestamp_time` (`amq_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity_mq`
--

LOCK TABLES `oc_activity_mq` WRITE;
/*!40000 ALTER TABLE `oc_activity_mq` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_activity_mq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbookchanges`
--

DROP TABLE IF EXISTS `oc_addressbookchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_addressbookchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `addressbookid` int(11) NOT NULL,
  `operation` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addressbookid_synctoken` (`addressbookid`,`synctoken`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbookchanges`
--

LOCK TABLES `oc_addressbookchanges` WRITE;
/*!40000 ALTER TABLE `oc_addressbookchanges` DISABLE KEYS */;
INSERT INTO `oc_addressbookchanges` VALUES (1,'Database:admin.vcf',1,2,1),(2,'Database:ocuser01.vcf',2,2,1),(3,'Database:ocuser02.vcf',3,2,1),(4,'Database:ocuser03.vcf',4,2,1),(5,'Database:ocuser04.vcf',5,2,1),(6,'Database:ocuser05.vcf',6,2,1),(7,'Database:ocuser06.vcf',7,2,1),(8,'Database:ocuser07.vcf',8,2,1),(9,'Database:ocuser08.vcf',9,2,1),(10,'Database:ocuser09.vcf',10,2,1),(11,'Database:ocuser10.vcf',11,2,1),(12,'Database:ocuser11.vcf',12,2,1),(13,'Database:ocuser12.vcf',13,2,1),(14,'Database:ocuser13.vcf',14,2,1),(15,'Database:ocuser14.vcf',15,2,1),(16,'Database:ocuser15.vcf',16,2,1),(17,'Database:ocuser16.vcf',17,2,1),(18,'Database:ocuser17.vcf',18,2,1),(19,'Database:ocuser18.vcf',19,2,1),(20,'Database:ocuser19.vcf',20,2,1),(21,'Database:ocuser20.vcf',21,2,1);
/*!40000 ALTER TABLE `oc_addressbookchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbooks`
--

DROP TABLE IF EXISTS `oc_addressbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_addressbooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `addressbook_index` (`principaluri`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbooks`
--

LOCK TABLES `oc_addressbooks` WRITE;
/*!40000 ALTER TABLE `oc_addressbooks` DISABLE KEYS */;
INSERT INTO `oc_addressbooks` VALUES (1,'principals/users/admin','Contacts','contacts',NULL,1),(2,'principals/system/system','system','system','System addressbook which holds all users of this instance',22);
/*!40000 ALTER TABLE `oc_addressbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_appconfig`
--

DROP TABLE IF EXISTS `oc_appconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_appconfig` (
  `appid` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8_bin,
  PRIMARY KEY (`appid`,`configkey`),
  KEY `appconfig_config_key_index` (`configkey`),
  KEY `appconfig_appid_key` (`appid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_appconfig`
--

LOCK TABLES `oc_appconfig` WRITE;
/*!40000 ALTER TABLE `oc_appconfig` DISABLE KEYS */;
INSERT INTO `oc_appconfig` VALUES ('activity','enabled','yes'),('activity','installed_version','2.7.2'),('activity','types','filesystem'),('backgroundjob','lastjob','15'),('comments','enabled','yes'),('comments','installed_version','0.3.0'),('comments','types','logging,dav'),('configreport','enabled','yes'),('configreport','installed_version','0.2.2'),('configreport','types','filesystem'),('core','first_install_version','10.14.0.3'),('core','installedat','1715036500.9282'),('core','lastcron','1717405493'),('core','lastupdateResult','[]'),('core','lastupdatedat','1715056958'),('core','oc.integritycheck.checker','[]'),('core','public_files','files_sharing/public.php'),('core','public_webdav','dav/appinfo/v1/publicwebdav.php'),('dav','enabled','yes'),('dav','installed_version','0.7.0'),('dav','types','filesystem'),('diagnostics','enabled','yes'),('diagnostics','installed_version','0.2.0'),('diagnostics','types','authentication'),('federatedfilesharing','enabled','yes'),('federatedfilesharing','installed_version','0.5.0'),('federatedfilesharing','types','filesystem'),('federation','enabled','yes'),('federation','installed_version','0.1.0'),('federation','types','authentication'),('files','cronjob_scan_files','500'),('files','enabled','yes'),('files','installed_version','1.6.0'),('files','types','filesystem'),('files_external','enabled','yes'),('files_external','installed_version','0.9.0'),('files_external','types','filesystem'),('files_mediaviewer','enabled','yes'),('files_mediaviewer','installed_version','1.0.5'),('files_mediaviewer','types',''),('files_pdfviewer','enabled','yes'),('files_pdfviewer','installed_version','1.0.2'),('files_pdfviewer','types',''),('files_sharing','enabled','yes'),('files_sharing','installed_version','0.14.0'),('files_sharing','types','filesystem'),('files_texteditor','enabled','yes'),('files_texteditor','installed_version','2.6.1'),('files_texteditor','types',''),('files_trashbin','enabled','yes'),('files_trashbin','installed_version','0.9.1'),('files_trashbin','types','filesystem'),('files_versions','enabled','yes'),('files_versions','installed_version','1.3.0'),('files_versions','types','filesystem'),('firstrunwizard','enabled','yes'),('firstrunwizard','installed_version','1.3.0'),('firstrunwizard','types',''),('market','enabled','yes'),('market','installed_version','0.8.0'),('market','types',''),('notifications','enabled','yes'),('notifications','installed_version','0.6.0'),('notifications','types','logging'),('provisioning_api','enabled','yes'),('provisioning_api','installed_version','0.5.0'),('provisioning_api','types','prevent_group_restriction'),('systemtags','enabled','yes'),('systemtags','installed_version','0.3.0'),('systemtags','types','logging'),('updatenotification','enabled','yes'),('updatenotification','installed_version','0.2.1'),('updatenotification','types','');
/*!40000 ALTER TABLE `oc_appconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authtoken`
--

DROP TABLE IF EXISTS `oc_authtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_authtoken` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `login_name` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `password` longtext COLLATE utf8_bin,
  `name` longtext COLLATE utf8_bin NOT NULL,
  `token` varchar(200) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` smallint(5) unsigned NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `last_check` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `authtoken_token_index` (`token`),
  KEY `authtoken_last_activity_index` (`last_activity`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authtoken`
--

LOCK TABLES `oc_authtoken` WRITE;
/*!40000 ALTER TABLE `oc_authtoken` DISABLE KEYS */;
INSERT INTO `oc_authtoken` VALUES (5,'admin','admin','v2|d93ee8b32efd73f8ffe1dd7cbe44cdaf|c445b0fe645cc60fc8661822227a23a8|1d3244100ed6a857b9575d5e518cef782aa25c55ab9a11da75605c5e044a1b02cc85223d7fc168c056a6c2c9f9b031c9679cc828166b69a8d6be3c59952b902f','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36','958450310549b40e4f926d4b53e1d70a7474908b449c3f87938971231a374b7b94c1d0a870738e3703c4e9f279cdecff092fa4d98f80bae3cee44f5df5215aed',0,1715551018,1715551018),(6,'admin','admin','v2|42ac36d052343045f7a0b2c8c8849e99|d4a6b1b72f419bb45a3aa45cee5272c5|80384018c8c09c5040d648c671d703815bf77ca96beae8ef68d23644985f282a2399965fe81e46ee0c2abd7ecc489134fde50eb15dca800761f6072180f4f601','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36','0468fef03eded7d5ffc46888c357c9a175189bef3234c2af97191a3988bc5ea3626b5ce84fbd457eb7f7c3d5434da6d395e8bfe54ad34ace5222d8a72360785b',0,1717405613,1717405486);
/*!40000 ALTER TABLE `oc_authtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarchanges`
--

DROP TABLE IF EXISTS `oc_calendarchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `calendarid` int(11) NOT NULL,
  `operation` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendarid_synctoken` (`calendarid`,`synctoken`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarchanges`
--

LOCK TABLES `oc_calendarchanges` WRITE;
/*!40000 ALTER TABLE `oc_calendarchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects`
--

DROP TABLE IF EXISTS `oc_calendarobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendarid` int(10) unsigned NOT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `componenttype` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `firstoccurence` bigint(20) unsigned DEFAULT NULL,
  `lastoccurence` bigint(20) unsigned DEFAULT NULL,
  `uid` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `classification` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `calobjects_index` (`calendarid`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects`
--

LOCK TABLES `oc_calendarobjects` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendars`
--

DROP TABLE IF EXISTS `oc_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT '1',
  `description` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `timezone` longtext COLLATE utf8_bin,
  `components` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `transparent` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `calendars_index` (`principaluri`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendars`
--

LOCK TABLES `oc_calendars` WRITE;
/*!40000 ALTER TABLE `oc_calendars` DISABLE KEYS */;
INSERT INTO `oc_calendars` VALUES (1,'principals/users/admin','Personal','personal',1,NULL,0,'#041e42',NULL,'VEVENT,VTODO',0),(2,'principals/system/system','Contact birthdays','contact_birthdays',1,NULL,0,'#FFFFCA',NULL,'VEVENT,VTODO',0);
/*!40000 ALTER TABLE `oc_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarsubscriptions`
--

DROP TABLE IF EXISTS `oc_calendarsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_calendarsubscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `source` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `displayname` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `refreshrate` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT '0',
  `calendarcolor` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `striptodos` smallint(6) DEFAULT NULL,
  `stripalarms` smallint(6) DEFAULT NULL,
  `stripattachments` smallint(6) DEFAULT NULL,
  `lastmodified` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calsub_index` (`principaluri`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarsubscriptions`
--

LOCK TABLES `oc_calendarsubscriptions` WRITE;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards`
--

DROP TABLE IF EXISTS `oc_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` int(11) NOT NULL DEFAULT '0',
  `carddata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `lastmodified` bigint(20) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `addressbookid_uri_index` (`addressbookid`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards`
--

LOCK TABLES `oc_cards` WRITE;
/*!40000 ALTER TABLE `oc_cards` DISABLE KEYS */;
INSERT INTO `oc_cards` VALUES (1,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:admin\r\nFN:admin\r\nN:admin;;;;\r\nCLOUD:admin@13.75.139.57\r\nEND:VCARD\r\n','Database:admin.vcf',1715037010,'f1d5727ee1334176a3958a4da10de53f',139),(2,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser01\r\nFN:ocuser01\r\nN:ocuser01;;;;\r\nCLOUD:ocuser01@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser01.vcf',1717405365,'58cda386f8461f01ea62874bb6bd10e3',151),(3,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser02\r\nFN:ocuser02\r\nN:ocuser02;;;;\r\nCLOUD:ocuser02@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser02.vcf',1717405365,'c9f8c2ff4755a5654f7e28f38fc1483d',151),(4,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser03\r\nFN:ocuser03\r\nN:ocuser03;;;;\r\nCLOUD:ocuser03@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser03.vcf',1717405365,'8e3b982844dc91339a01f30991d9868a',151),(5,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser04\r\nFN:ocuser04\r\nN:ocuser04;;;;\r\nCLOUD:ocuser04@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser04.vcf',1717405366,'891dad2baa4b70f70b0bf5a7c24db7d2',151),(6,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser05\r\nFN:ocuser05\r\nN:ocuser05;;;;\r\nCLOUD:ocuser05@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser05.vcf',1717405366,'17ea8e97322087e97dc28847e2d822f0',151),(7,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser06\r\nFN:ocuser06\r\nN:ocuser06;;;;\r\nCLOUD:ocuser06@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser06.vcf',1717405366,'f7aa5dad0bad3150bcf7d411d2d03b60',151),(8,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser07\r\nFN:ocuser07\r\nN:ocuser07;;;;\r\nCLOUD:ocuser07@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser07.vcf',1717405367,'91f31e128d71922000dda4521a2fd637',151),(9,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser08\r\nFN:ocuser08\r\nN:ocuser08;;;;\r\nCLOUD:ocuser08@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser08.vcf',1717405367,'ca1f7e06de4f960d311c0bdafc3931a6',151),(10,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser09\r\nFN:ocuser09\r\nN:ocuser09;;;;\r\nCLOUD:ocuser09@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser09.vcf',1717405368,'82700c28f0ebcc4ef78ee0b9f29729be',151),(11,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser10\r\nFN:ocuser10\r\nN:ocuser10;;;;\r\nCLOUD:ocuser10@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser10.vcf',1717405368,'749504b391ad37af21d813adc34d9854',151),(12,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser11\r\nFN:ocuser11\r\nN:ocuser11;;;;\r\nCLOUD:ocuser11@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser11.vcf',1717405368,'990207695d5c063dbc5b4bb595567c2c',151),(13,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser12\r\nFN:ocuser12\r\nN:ocuser12;;;;\r\nCLOUD:ocuser12@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser12.vcf',1717405369,'58f7e09827bd0094762e96274a570a7f',151),(14,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser13\r\nFN:ocuser13\r\nN:ocuser13;;;;\r\nCLOUD:ocuser13@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser13.vcf',1717405369,'be31e1d6aa38a4875081a166cef0c5d6',151),(15,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser14\r\nFN:ocuser14\r\nN:ocuser14;;;;\r\nCLOUD:ocuser14@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser14.vcf',1717405369,'fbc29a297947b2fc00fa031686473ab0',151),(16,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser15\r\nFN:ocuser15\r\nN:ocuser15;;;;\r\nCLOUD:ocuser15@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser15.vcf',1717405370,'5e51fe91c8beb6d98866aa9d6012ab96',151),(17,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser16\r\nFN:ocuser16\r\nN:ocuser16;;;;\r\nCLOUD:ocuser16@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser16.vcf',1717405370,'f863e31b8a891c8308587165bb2d25b9',151),(18,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser17\r\nFN:ocuser17\r\nN:ocuser17;;;;\r\nCLOUD:ocuser17@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser17.vcf',1717405371,'ca4d2ac478673e65413e76d2e09bb3c7',151),(19,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser18\r\nFN:ocuser18\r\nN:ocuser18;;;;\r\nCLOUD:ocuser18@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser18.vcf',1717405371,'588b0b6cd6eb7d8f70ba66b910682fa3',151),(20,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser19\r\nFN:ocuser19\r\nN:ocuser19;;;;\r\nCLOUD:ocuser19@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser19.vcf',1717405371,'18c7e19569a5f915c44bb90d10ca3e30',151),(21,2,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.4//EN\r\nUID:ocuser20\r\nFN:ocuser20\r\nN:ocuser20;;;;\r\nCLOUD:ocuser20@13.75.139.57\r\nEND:VCARD\r\n','Database:ocuser20.vcf',1717405372,'86da30b7358de500247bacc9fdc8b33e',151);
/*!40000 ALTER TABLE `oc_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards_properties`
--

DROP TABLE IF EXISTS `oc_cards_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_cards_properties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint(20) NOT NULL DEFAULT '0',
  `cardid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `preferred` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `card_value_index` (`value`),
  KEY `card_name_index` (`name`),
  KEY `card_contactid_index` (`cardid`),
  KEY `card_bookid_name_index` (`addressbookid`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards_properties`
--

LOCK TABLES `oc_cards_properties` WRITE;
/*!40000 ALTER TABLE `oc_cards_properties` DISABLE KEYS */;
INSERT INTO `oc_cards_properties` VALUES (1,2,1,'UID','admin',0),(2,2,1,'FN','admin',0),(3,2,1,'N','admin;;;;',0),(4,2,1,'CLOUD','admin@13.75.139.57',0),(5,2,2,'UID','ocuser01',0),(6,2,2,'FN','ocuser01',0),(7,2,2,'N','ocuser01;;;;',0),(8,2,2,'CLOUD','ocuser01@13.75.139.57',0),(9,2,3,'UID','ocuser02',0),(10,2,3,'FN','ocuser02',0),(11,2,3,'N','ocuser02;;;;',0),(12,2,3,'CLOUD','ocuser02@13.75.139.57',0),(13,2,4,'UID','ocuser03',0),(14,2,4,'FN','ocuser03',0),(15,2,4,'N','ocuser03;;;;',0),(16,2,4,'CLOUD','ocuser03@13.75.139.57',0),(17,2,5,'UID','ocuser04',0),(18,2,5,'FN','ocuser04',0),(19,2,5,'N','ocuser04;;;;',0),(20,2,5,'CLOUD','ocuser04@13.75.139.57',0),(21,2,6,'UID','ocuser05',0),(22,2,6,'FN','ocuser05',0),(23,2,6,'N','ocuser05;;;;',0),(24,2,6,'CLOUD','ocuser05@13.75.139.57',0),(25,2,7,'UID','ocuser06',0),(26,2,7,'FN','ocuser06',0),(27,2,7,'N','ocuser06;;;;',0),(28,2,7,'CLOUD','ocuser06@13.75.139.57',0),(29,2,8,'UID','ocuser07',0),(30,2,8,'FN','ocuser07',0),(31,2,8,'N','ocuser07;;;;',0),(32,2,8,'CLOUD','ocuser07@13.75.139.57',0),(33,2,9,'UID','ocuser08',0),(34,2,9,'FN','ocuser08',0),(35,2,9,'N','ocuser08;;;;',0),(36,2,9,'CLOUD','ocuser08@13.75.139.57',0),(37,2,10,'UID','ocuser09',0),(38,2,10,'FN','ocuser09',0),(39,2,10,'N','ocuser09;;;;',0),(40,2,10,'CLOUD','ocuser09@13.75.139.57',0),(41,2,11,'UID','ocuser10',0),(42,2,11,'FN','ocuser10',0),(43,2,11,'N','ocuser10;;;;',0),(44,2,11,'CLOUD','ocuser10@13.75.139.57',0),(45,2,12,'UID','ocuser11',0),(46,2,12,'FN','ocuser11',0),(47,2,12,'N','ocuser11;;;;',0),(48,2,12,'CLOUD','ocuser11@13.75.139.57',0),(49,2,13,'UID','ocuser12',0),(50,2,13,'FN','ocuser12',0),(51,2,13,'N','ocuser12;;;;',0),(52,2,13,'CLOUD','ocuser12@13.75.139.57',0),(53,2,14,'UID','ocuser13',0),(54,2,14,'FN','ocuser13',0),(55,2,14,'N','ocuser13;;;;',0),(56,2,14,'CLOUD','ocuser13@13.75.139.57',0),(57,2,15,'UID','ocuser14',0),(58,2,15,'FN','ocuser14',0),(59,2,15,'N','ocuser14;;;;',0),(60,2,15,'CLOUD','ocuser14@13.75.139.57',0),(61,2,16,'UID','ocuser15',0),(62,2,16,'FN','ocuser15',0),(63,2,16,'N','ocuser15;;;;',0),(64,2,16,'CLOUD','ocuser15@13.75.139.57',0),(65,2,17,'UID','ocuser16',0),(66,2,17,'FN','ocuser16',0),(67,2,17,'N','ocuser16;;;;',0),(68,2,17,'CLOUD','ocuser16@13.75.139.57',0),(69,2,18,'UID','ocuser17',0),(70,2,18,'FN','ocuser17',0),(71,2,18,'N','ocuser17;;;;',0),(72,2,18,'CLOUD','ocuser17@13.75.139.57',0),(73,2,19,'UID','ocuser18',0),(74,2,19,'FN','ocuser18',0),(75,2,19,'N','ocuser18;;;;',0),(76,2,19,'CLOUD','ocuser18@13.75.139.57',0),(77,2,20,'UID','ocuser19',0),(78,2,20,'FN','ocuser19',0),(79,2,20,'N','ocuser19;;;;',0),(80,2,20,'CLOUD','ocuser19@13.75.139.57',0),(81,2,21,'UID','ocuser20',0),(82,2,21,'FN','ocuser20',0),(83,2,21,'N','ocuser20;;;;',0),(84,2,21,'CLOUD','ocuser20@13.75.139.57',0);
/*!40000 ALTER TABLE `oc_cards_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments`
--

DROP TABLE IF EXISTS `oc_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `topmost_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `children_count` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `actor_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `message` longtext COLLATE utf8_bin,
  `verb` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `creation_timestamp` datetime DEFAULT NULL,
  `latest_child_timestamp` datetime DEFAULT NULL,
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `comments_parent_id_index` (`parent_id`),
  KEY `comments_topmost_parent_id_idx` (`topmost_parent_id`),
  KEY `comments_object_index` (`object_type`,`object_id`,`creation_timestamp`),
  KEY `comments_actor_index` (`actor_type`,`actor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments`
--

LOCK TABLES `oc_comments` WRITE;
/*!40000 ALTER TABLE `oc_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments_read_markers`
--

DROP TABLE IF EXISTS `oc_comments_read_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_comments_read_markers` (
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `marker_datetime` datetime DEFAULT NULL,
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  UNIQUE KEY `comments_marker_index` (`user_id`,`object_type`,`object_id`),
  KEY `comments_marker_object_index` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments_read_markers`
--

LOCK TABLES `oc_comments_read_markers` WRITE;
/*!40000 ALTER TABLE `oc_comments_read_markers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments_read_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_credentials`
--

DROP TABLE IF EXISTS `oc_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_credentials` (
  `user` varchar(64) COLLATE utf8_bin NOT NULL,
  `identifier` varchar(64) COLLATE utf8_bin NOT NULL,
  `credentials` longtext COLLATE utf8_bin,
  PRIMARY KEY (`user`,`identifier`),
  KEY `credentials_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_credentials`
--

LOCK TABLES `oc_credentials` WRITE;
/*!40000 ALTER TABLE `oc_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_job_status`
--

DROP TABLE IF EXISTS `oc_dav_job_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_job_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8_bin NOT NULL COMMENT '(DC2Type:guid)',
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `status_info` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_18BBA548D17F50A6` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_job_status`
--

LOCK TABLES `oc_dav_job_status` WRITE;
/*!40000 ALTER TABLE `oc_dav_job_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_job_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_properties`
--

DROP TABLE IF EXISTS `oc_dav_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_properties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `propertypath` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyvalue` varchar(255) COLLATE utf8_bin NOT NULL,
  `propertytype` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `propertypath_index` (`propertypath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_properties`
--

LOCK TABLES `oc_dav_properties` WRITE;
/*!40000 ALTER TABLE `oc_dav_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_shares`
--

DROP TABLE IF EXISTS `oc_dav_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_dav_shares` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `access` smallint(6) DEFAULT NULL,
  `resourceid` int(10) unsigned NOT NULL,
  `publicuri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_shares_index` (`principaluri`,`resourceid`,`type`,`publicuri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_shares`
--

LOCK TABLES `oc_dav_shares` WRITE;
/*!40000 ALTER TABLE `oc_dav_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_applicable`
--

DROP TABLE IF EXISTS `oc_external_applicable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_applicable` (
  `applicable_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  `value` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`applicable_id`),
  UNIQUE KEY `applicable_type_value_mount` (`type`,`value`,`mount_id`),
  KEY `applicable_mount` (`mount_id`),
  KEY `applicable_type_value` (`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_applicable`
--

LOCK TABLES `oc_external_applicable` WRITE;
/*!40000 ALTER TABLE `oc_external_applicable` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_applicable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_config`
--

DROP TABLE IF EXISTS `oc_external_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_config` (
  `config_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `value` varchar(4096) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`config_id`),
  UNIQUE KEY `config_mount_key` (`mount_id`,`key`),
  KEY `config_mount` (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_config`
--

LOCK TABLES `oc_external_config` WRITE;
/*!40000 ALTER TABLE `oc_external_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_mounts`
--

DROP TABLE IF EXISTS `oc_external_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_mounts` (
  `mount_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_point` varchar(128) COLLATE utf8_bin NOT NULL,
  `storage_backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `auth_backend` varchar(64) COLLATE utf8_bin NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '100',
  `type` int(11) NOT NULL,
  PRIMARY KEY (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_mounts`
--

LOCK TABLES `oc_external_mounts` WRITE;
/*!40000 ALTER TABLE `oc_external_mounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_external_options`
--

DROP TABLE IF EXISTS `oc_external_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_external_options` (
  `option_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mount_id` bigint(20) NOT NULL,
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `value` varchar(256) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_mount_key` (`mount_id`,`key`),
  KEY `option_mount` (`mount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_external_options`
--

LOCK TABLES `oc_external_options` WRITE;
/*!40000 ALTER TABLE `oc_external_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_external_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_federated_reshares`
--

DROP TABLE IF EXISTS `oc_federated_reshares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_federated_reshares` (
  `share_id` bigint(20) NOT NULL,
  `remote_id` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'share ID at the remote server',
  UNIQUE KEY `share_id_index` (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_federated_reshares`
--

LOCK TABLES `oc_federated_reshares` WRITE;
/*!40000 ALTER TABLE `oc_federated_reshares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_federated_reshares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_file_locks`
--

DROP TABLE IF EXISTS `oc_file_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_file_locks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lock` int(11) NOT NULL DEFAULT '0',
  `key` varchar(64) COLLATE utf8_bin NOT NULL,
  `ttl` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lock_key_index` (`key`),
  KEY `lock_ttl_index` (`ttl`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_file_locks`
--

LOCK TABLES `oc_file_locks` WRITE;
/*!40000 ALTER TABLE `oc_file_locks` DISABLE KEYS */;
INSERT INTO `oc_file_locks` VALUES (1,0,'files/93d5339bd03eda04328d8daec67b0aec',1715060568),(2,0,'files/9ee07df1536f63a6e8047fc80573b3b7',1715060568),(4,0,'files/c31e581b3c2ec56f9b7b1dca2421b72e',1715058356),(22,0,'files/cb6b4c11e5e5642185bd52f5896a8bf8',1715058357);
/*!40000 ALTER TABLE `oc_file_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache`
--

DROP TABLE IF EXISTS `oc_filecache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_filecache` (
  `fileid` bigint(20) NOT NULL AUTO_INCREMENT,
  `storage` int(11) NOT NULL DEFAULT '0',
  `path` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `path_hash` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `parent` bigint(20) NOT NULL DEFAULT '0',
  `name` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `mimetype` int(11) NOT NULL DEFAULT '0',
  `mimepart` int(11) NOT NULL DEFAULT '0',
  `size` bigint(20) NOT NULL DEFAULT '0',
  `mtime` bigint(20) NOT NULL DEFAULT '0',
  `storage_mtime` bigint(20) NOT NULL DEFAULT '0',
  `encrypted` int(11) NOT NULL DEFAULT '0',
  `unencrypted_size` bigint(20) NOT NULL DEFAULT '0',
  `etag` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `permissions` int(11) DEFAULT '0',
  `checksum` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`fileid`),
  UNIQUE KEY `fs_storage_path_hash` (`storage`,`path_hash`),
  KEY `fs_parent_name_hash` (`parent`,`name`),
  KEY `fs_storage_mimetype` (`storage`,`mimetype`),
  KEY `fs_storage_mimepart` (`storage`,`mimepart`),
  KEY `fs_storage_size` (`storage`,`size`,`fileid`),
  KEY `fs_parent_storage_size` (`parent`,`storage`,`size`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache`
--

LOCK TABLES `oc_filecache` WRITE;
/*!40000 ALTER TABLE `oc_filecache` DISABLE KEYS */;
INSERT INTO `oc_filecache` VALUES (1,2,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,4688555,1715037031,1715037031,0,0,'6639617c09382',23,''),(2,2,'cache','0fea6a13c52b4d4725368f24b045ca84',1,'cache',2,1,0,1715036538,1715036538,0,0,'6639617a99996',31,''),(3,2,'files','45b963397aa40d4a0063e0d85e4fe7a1',1,'files',2,1,4688555,1715036540,1715036539,0,0,'6639617c09382',31,''),(4,2,'files/Documents','0ad78ba05b6961d92f7970b2b3922eca',3,'Documents',2,1,36227,1715036538,1715036538,0,0,'6639617af1061',31,''),(5,2,'files/Documents/Example.odt','c89c560541b952a435783a7d51a27d50',4,'Example.odt',4,3,36227,1715036539,1715036539,0,0,'0f879ed35c9022b35301d572c957143a',27,'SHA1:a2c861e88db506c0deadb9f7d78a1e27212ce9fc MD5:12348c01fb20e0230c1afdacfe514308 ADLER32:85ffdff5'),(6,2,'files/Learn more about ownCloud','d2973fb874c5912ffd5bb0641c5ea684',3,'Learn more about ownCloud',2,1,3640864,1715036539,1715036539,0,0,'6639617ba34bc',31,''),(7,2,'files/Learn more about ownCloud/ownCloud Subscription Overview.pdf','82c512590823b9f60241661147b6ee3e',6,'ownCloud Subscription Overview.pdf',5,3,1611431,1715036539,1715036539,0,0,'f0c40eacdb57d0186cdcac1c7c21bf4b',27,'SHA1:60d39db691f0e1e336a24de2da18b326958b6296 MD5:d6022e62ba4ca6339023a7ca8a59c624 ADLER32:857c8495'),(8,2,'files/Learn more about ownCloud/Share files efficiently in your company.pdf','bdf0d315b6e669549e4b0315df88efc0',6,'Share files efficiently in your company.pdf',5,3,303237,1715036539,1715036539,0,0,'9755645aeda18f5e5040255b1c3e51b4',27,'SHA1:de4d1a3e1b73cd73efb5a1f529c0b5dc51d3bfd2 MD5:ae2666d86aeb555ee15c31b5f5f477ac ADLER32:84b00a47'),(9,2,'files/Learn more about ownCloud/Introducing ownCloud.pdf','b9ec9d71f18517b94c9c4f89383c1c0d',6,'Introducing ownCloud.pdf',5,3,238300,1715036539,1715036539,0,0,'744c73ec9bc558e50faeaf769f26b35e',27,'SHA1:5f347dcebb39e84114bcd9a46fb3a4c2f49ad146 MD5:c511ba341ba6aad2e28f47770b184b88 ADLER32:89780720'),(10,2,'files/Learn more about ownCloud/Data Protection and Data Secrecy in ownCloud.pdf','3fefc5573101667f6ec8765e03f603fd',6,'Data Protection and Data Secrecy in ownCloud.pdf',5,3,418526,1715036539,1715036539,0,0,'c4d32c9acf5ca1cff5ef12a6bb11cc42',27,'SHA1:7cc7d05042acea27a4e5106f67850280036665d8 MD5:3dc8c7aa774018e273ed0966231f6900 ADLER32:d4dda484'),(11,2,'files/Learn more about ownCloud/Safely leverage Microsoft Office.pdf','5a0b23e984d4aba3d4ec45dd7993a9e2',6,'Safely leverage Microsoft Office.pdf',5,3,314348,1715036539,1715036539,0,0,'2c931cbb5973e0ae97d66d3e2fd36efb',27,'SHA1:7d9fc0830b748676d849fa49368196a8cd41870b MD5:46bf17bceab32b1fa275d45a6812b1bd ADLER32:c296ebf8'),(12,2,'files/Learn more about ownCloud/Keep your files safe with ownCloud.pdf','2745d631ba3df00ecc0639ba1e65f004',6,'Keep your files safe with ownCloud.pdf',5,3,755022,1715036539,1715036539,0,0,'c891849d6da02ef24c2bae307bb3402a',27,'SHA1:fd1272edf3192ee53eae108b8698a79fe4b6ca1e MD5:397599bed99ed48e1a420fe0a8ce68fd ADLER32:ae4a19bf'),(13,2,'files/Photos','d01bb67e7b71dd49fd06bad922f521c9',3,'Photos',2,1,1011464,1715036540,1715036540,0,0,'6639617c09382',31,''),(14,2,'files/Photos/Lake-Constance.jpg','7055b85346dc19417e7f3d7b3e7a154a',13,'Lake-Constance.jpg',7,6,538942,1715036539,1715036539,0,0,'34d400d02e041619f7eb976e5894e6e7',27,'SHA1:b26d5544e642330e2858a4d8528cb108ddbca9e3 MD5:147156bc95dba89fab2227507462ebea ADLER32:f21d8700'),(15,2,'files/Photos/Teotihuacan.jpg','704b0aeb1b065272539e87218dee5f7a',13,'Teotihuacan.jpg',7,6,228789,1715036539,1715036539,0,0,'9d25c1c3feea9cc658f4c36263741f3b',27,'SHA1:8ae951c9412a00be206912b95fe8e5c7c3c05667 MD5:2617bb41ab25b8acd0c18cefefbf6360 ADLER32:91867251'),(16,2,'files/Photos/Portugal.jpg','99079102f2763830ef072aa7459c0b13',13,'Portugal.jpg',7,6,243733,1715036540,1715036540,0,0,'d042f6aa16c55dee5f499938e5d3c984',27,'SHA1:872adcabcb4e06bea6265200c0d71b12defe2df1 MD5:01b38c622feac31652d738a94e15e86b ADLER32:6959358d'),(17,3,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,-1,1715054756,1715054756,0,0,'6639a8a506440',23,''),(18,3,'avatars','aec9f4efc5a055bbd053f220538c61e0',17,'avatars',2,1,0,1715036540,1715036540,0,0,'6639617c639da',31,''),(19,2,'thumbnails','3b8779ba05b8f0aed49650f3ff8beb4b',1,'thumbnails',2,1,-2,1715037032,1715037032,0,0,'66396367d3216',31,''),(20,2,'thumbnails/16','205061c872c90eb2ccc9f589b194004d',19,'16',2,1,0,1715056962,1715056962,0,0,'66396367d9aaa',31,''),(21,2,'thumbnails/15','fc5030e51a18e2657b54b65613863ec6',19,'15',2,1,0,1715056962,1715056962,0,0,'66396367dec4e',31,''),(22,2,'thumbnails/16/1024-768-max.png','e4c73c70e8f88896b55d1e4487b6ce4b',20,'1024-768-max.png',8,6,126124,1715037031,1715037031,0,0,'3bfdc34e11030a58086641819e32af8d',27,'SHA1:086cebd754e5c9904bbaa2dc059a6121a14de04c MD5:5c2870efdf5d7801fa3130dadb51fd19 ADLER32:3ba5ac68'),(23,2,'thumbnails/15/1024-768-max.png','1060fc64ed9b200cc422ea90ca5a51d0',21,'1024-768-max.png',8,6,89157,1715037031,1715037031,0,0,'c9024f41246d0b2965d365587fa9dff9',27,'SHA1:d6153622a1cd5f1a4461714093fd79fa1a4b9eff MD5:4ae275ee9657ef18a8d00f2d6531e635 ADLER32:f116b037'),(24,2,'thumbnails/16/32-32.png','7895dc310ca563126ced231d2d052080',20,'32-32.png',8,6,987,1715037031,1715037031,0,0,'76a34f5b9803a4483a7e63213c3a0d77',27,'SHA1:529ad3611d74b84ad207d5c1f014bd69928e2036 MD5:25fe0fca139f84378565e19617d1f068 ADLER32:7b277963'),(25,2,'thumbnails/15/32-32.png','81ec9aa63f517d7c3ac6ebd9e6b30941',21,'32-32.png',8,6,982,1715037031,1715037031,0,0,'845924faf6f3cead722bf87095e13ab6',27,'SHA1:0e9d22e3e841e7edabf4f840c82c0455454c8350 MD5:ac569379f1999910ebc831961daf8573 ADLER32:57a36e2a'),(26,2,'thumbnails/14','ea47b030176b781fc37e3b0ab4c9e953',19,'14',2,1,0,1715056962,1715056962,0,0,'663963680a341',31,''),(27,2,'thumbnails/14/2048-541-max.png','4afa26ad6cd79ced63b6bad7f0b61db4',26,'2048-541-max.png',8,6,211011,1715037032,1715037032,0,0,'97f63bf5ca6bc6257e94d3ea47078d91',27,'SHA1:bb9c2c65c2ce847e1a4074915d3df05526508da8 MD5:accd646949af5def623363377d018dcb ADLER32:01f8618d'),(28,2,'thumbnails/14/32-32.png','4b1f8e25d575269e8ab4ef5f8553eafa',26,'32-32.png',8,6,1005,1715037032,1715037032,0,0,'08711b393ab0a66326dab1b16043253b',27,'SHA1:18f94a96eb39d87194485545237a47990021268e MD5:eb59b9ea79166d417911e3c426e25c46 ADLER32:02918619'),(29,3,'files_external','c270928b685e7946199afdfb898d27ea',17,'files_external',2,1,0,1715054756,1715054756,0,0,'6639a8a4f24a1',31,''),(30,2,'thumbnails/16/150-150.png','36cbfda9c7c194e418ae8bda4f85be09',20,'150-150.png',8,6,5837,1715056962,1715056962,0,0,'7a3a95ac6941a0418069781d12dcc073',27,'SHA1:cb248fe0e28099fc74fce2a40a27072d88566f8c MD5:13cf02f337acb5cb93a54aa7bf40b2b2 ADLER32:0597f1fc'),(31,2,'thumbnails/14/150-150.png','5cf835d37f7d6b52e1f72f1e033d0330',26,'150-150.png',8,6,6223,1715056962,1715056962,0,0,'3f54644e9985b6f038c84c185e9d6388',27,'SHA1:05d4416116fbf86389ea9c415a6978af9cc37e25 MD5:3439409969cec508ec15a240fc363bf7 ADLER32:e16e969d'),(32,2,'thumbnails/15/150-150.png','93c2c8eef748971acf823ba17ba04edc',21,'150-150.png',8,6,5186,1715056962,1715056962,0,0,'52bb1b1a08f91ece9218776a36c37722',27,'SHA1:7ef5da1f6828f01c69c38cb907478003e8cf1cf9 MD5:4aed90575f59fa908fb00857142b6661 ADLER32:369e74b5');
/*!40000 ALTER TABLE `oc_filecache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_trash`
--

DROP TABLE IF EXISTS `oc_files_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_files_trash` (
  `auto_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` varchar(250) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timestamp` varchar(12) COLLATE utf8_bin NOT NULL DEFAULT '',
  `location` varchar(512) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` varchar(4) COLLATE utf8_bin DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  KEY `id_index` (`id`),
  KEY `timestamp_index` (`timestamp`),
  KEY `user_index` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_trash`
--

LOCK TABLES `oc_files_trash` WRITE;
/*!40000 ALTER TABLE `oc_files_trash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_trash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_admin`
--

DROP TABLE IF EXISTS `oc_group_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_group_admin` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `group_admin_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_admin`
--

LOCK TABLES `oc_group_admin` WRITE;
/*!40000 ALTER TABLE `oc_group_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_group_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_user`
--

DROP TABLE IF EXISTS `oc_group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_group_user` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `gu_uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_user`
--

LOCK TABLES `oc_group_user` WRITE;
/*!40000 ALTER TABLE `oc_group_user` DISABLE KEYS */;
INSERT INTO `oc_group_user` VALUES ('admin','admin');
/*!40000 ALTER TABLE `oc_group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_groups`
--

DROP TABLE IF EXISTS `oc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_groups` (
  `gid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_groups`
--

LOCK TABLES `oc_groups` WRITE;
/*!40000 ALTER TABLE `oc_groups` DISABLE KEYS */;
INSERT INTO `oc_groups` VALUES ('admin');
/*!40000 ALTER TABLE `oc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_jobs`
--

DROP TABLE IF EXISTS `oc_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_jobs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `argument` varchar(4000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `last_run` int(11) DEFAULT '0',
  `last_checked` int(11) DEFAULT '0',
  `reserved_at` int(11) DEFAULT '0',
  `execution_duration` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `job_class_index` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_jobs`
--

LOCK TABLES `oc_jobs` WRITE;
/*!40000 ALTER TABLE `oc_jobs` DISABLE KEYS */;
INSERT INTO `oc_jobs` VALUES (1,'OCA\\Files\\BackgroundJob\\ScanFiles','null',1715056968,1715056968,0,0),(2,'OCA\\Files\\BackgroundJob\\DeleteOrphanedItems','null',1715056973,1715056973,0,0),(3,'OCA\\Files\\BackgroundJob\\CleanupFileLocks','null',1715057376,1715057376,0,0),(4,'OCA\\Files\\BackgroundJob\\CleanupPersistentFileLocks','null',1715057380,1715057380,0,0),(5,'OCA\\Files\\BackgroundJob\\PreviewCleanupJob','null',1715057389,1715057389,0,0),(6,'OCA\\DAV\\CardDAV\\SyncJob','null',1715037010,1715057394,0,0),(7,'OCA\\DAV\\BackgroundJob\\CleanProperties','null',1715037017,1715057871,0,0),(8,'OCA\\Activity\\BackgroundJob\\EmailNotification','null',1715057891,1715057891,0,0),(9,'OCA\\Activity\\BackgroundJob\\ExpireActivities','null',1715037025,1715057920,0,0),(10,'OCA\\Federation\\SyncJob','null',1715046958,1715057969,0,0),(11,'OCA\\Files_Sharing\\DeleteOrphanedSharesJob','null',1715543868,1715543868,0,0),(12,'OCA\\Files_Sharing\\ExpireSharesJob','null',1715543883,1715543883,0,0),(13,'OCA\\Files_Sharing\\External\\ScanExternalSharesJob','null',1717405481,1717405481,0,0),(14,'OCA\\Files_Trashbin\\BackgroundJob\\ExpireTrash','null',1717405489,1717405488,0,0),(15,'OCA\\Files_Versions\\BackgroundJob\\ExpireVersions','null',1717405492,1717405492,0,0),(16,'OCA\\Market\\CheckUpdateBackgroundJob','null',1715054756,1715054756,0,3),(17,'OCA\\UpdateNotification\\Notification\\BackgroundJob','null',1715056958,1715056958,0,1),(18,'\\OC\\Authentication\\Token\\DefaultTokenCleanupJob','null',1715056962,1715056962,0,0);
/*!40000 ALTER TABLE `oc_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_migrations`
--

DROP TABLE IF EXISTS `oc_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_migrations` (
  `app` varchar(177) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(14) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`app`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_migrations`
--

LOCK TABLES `oc_migrations` WRITE;
/*!40000 ALTER TABLE `oc_migrations` DISABLE KEYS */;
INSERT INTO `oc_migrations` VALUES ('activity','20161122085340'),('activity','20161122092159'),('activity','20170131134507'),('activity','20170724182159'),('activity','20181019151118'),('activity','20181022150134'),('core','20170101010100'),('core','20170101215145'),('core','20170111103310'),('core','20170213215145'),('core','20170214112458'),('core','20170221114437'),('core','20170221121536'),('core','20170315173825'),('core','20170320173955'),('core','20170418154659'),('core','20170516100103'),('core','20170526104128'),('core','20170605143658'),('core','20170711191432'),('core','20170804201253'),('core','20170928120000'),('core','20171026130750'),('core','20180123131835'),('core','20180302155233'),('core','20180319102121'),('core','20180607072706'),('core','20181017105216'),('core','20181017120818'),('core','20181113071753'),('core','20181220085457'),('core','20190125162909'),('core','20200610110817'),('core','20210928123126'),('core','20230105001100'),('core','20230120101715'),('core','20230210073645'),('core','20230210103154'),('core','20240112140951'),('core','20240131080456'),('dav','20170116150538'),('dav','20170116170538'),('dav','20170202213905'),('dav','20170202220512'),('dav','20170427182800'),('dav','20170519091921'),('dav','20170526100342'),('dav','20170711193427'),('dav','20170927201245'),('dav','20180622095921'),('dav','20181115210344'),('dav','20190823065724'),('dav','20200114181454'),('dav','20200427142541'),('dav','20210714123001'),('federatedfilesharing','20170804201125'),('federatedfilesharing','20170804201253'),('federatedfilesharing','20190410160725'),('files_external','20170814051424'),('files_external','20210511082903'),('files_external','20220329110116'),('files_sharing','20170804201125'),('files_sharing','20170804201253'),('files_sharing','20170830112305'),('files_sharing','20171115154900'),('files_sharing','20171215103657'),('files_sharing','20190426123324'),('files_sharing','20200504211654'),('files_sharing','20200823121322'),('files_trashbin','20170804201125'),('files_trashbin','20170804201253'),('notifications','20170801085340'),('notifications','20170801152524'),('notifications','20180119080933'),('notifications','20180604132522');
/*!40000 ALTER TABLE `oc_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mimetypes`
--

DROP TABLE IF EXISTS `oc_mimetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_mimetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mimetype` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mimetype_id_index` (`mimetype`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mimetypes`
--

LOCK TABLES `oc_mimetypes` WRITE;
/*!40000 ALTER TABLE `oc_mimetypes` DISABLE KEYS */;
INSERT INTO `oc_mimetypes` VALUES (3,'application'),(5,'application/pdf'),(4,'application/vnd.oasis.opendocument.text'),(1,'httpd'),(2,'httpd/unix-directory'),(6,'image'),(7,'image/jpeg'),(8,'image/png');
/*!40000 ALTER TABLE `oc_mimetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mounts`
--

DROP TABLE IF EXISTS `oc_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_mounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `storage_id` int(11) NOT NULL,
  `root_id` bigint(20) NOT NULL,
  `user_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `mount_point` varchar(4000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mounts_user_root_index` (`user_id`,`root_id`),
  KEY `mounts_user_index` (`user_id`),
  KEY `mounts_storage_index` (`storage_id`),
  KEY `mounts_root_index` (`root_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mounts`
--

LOCK TABLES `oc_mounts` WRITE;
/*!40000 ALTER TABLE `oc_mounts` DISABLE KEYS */;
INSERT INTO `oc_mounts` VALUES (1,2,1,'admin','/admin/');
/*!40000 ALTER TABLE `oc_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications`
--

DROP TABLE IF EXISTS `oc_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(32) COLLATE utf8_bin NOT NULL,
  `user` varchar(64) COLLATE utf8_bin NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT '0',
  `object_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `object_id` varchar(64) COLLATE utf8_bin NOT NULL,
  `subject` varchar(64) COLLATE utf8_bin NOT NULL,
  `subject_parameters` longtext COLLATE utf8_bin,
  `message` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `message_parameters` longtext COLLATE utf8_bin,
  `link` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  `actions` longtext COLLATE utf8_bin,
  `icon` varchar(4000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `IDX_16B80748C96E70CF` (`app`),
  KEY `IDX_16B807488D93D649` (`user`),
  KEY `IDX_16B80748A5D6E63E` (`timestamp`),
  KEY `IDX_16B8074811CB6B3A232D562B` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications`
--

LOCK TABLES `oc_notifications` WRITE;
/*!40000 ALTER TABLE `oc_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_persistent_locks`
--

DROP TABLE IF EXISTS `oc_persistent_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_persistent_locks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL COMMENT 'FK to fileid in table oc_file_cache',
  `owner_account_id` bigint(20) unsigned DEFAULT NULL COMMENT 'owner of the lock - FK to account table',
  `owner` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT 'owner of the lock - just a human readable string',
  `timeout` int(10) unsigned NOT NULL COMMENT 'timestamp when the lock expires',
  `created_at` int(10) unsigned NOT NULL COMMENT 'timestamp when the lock was created',
  `token` varchar(1024) COLLATE utf8_bin NOT NULL COMMENT 'uuid for webdav locks - 1024 random chars for WOPI locks',
  `token_hash` varchar(32) COLLATE utf8_bin NOT NULL COMMENT 'md5(token)',
  `scope` smallint(6) NOT NULL COMMENT '1 - exclusive, 2 - shared',
  `depth` smallint(6) NOT NULL COMMENT '0, 1 or infinite',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F0C3D55BB3BC57DA` (`token_hash`),
  KEY `IDX_F0C3D55B93CB796C` (`file_id`),
  KEY `IDX_F0C3D55BC901C6FF` (`owner_account_id`),
  CONSTRAINT `FK_F0C3D55B93CB796C` FOREIGN KEY (`file_id`) REFERENCES `oc_filecache` (`fileid`) ON DELETE CASCADE,
  CONSTRAINT `FK_F0C3D55BC901C6FF` FOREIGN KEY (`owner_account_id`) REFERENCES `oc_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_persistent_locks`
--

LOCK TABLES `oc_persistent_locks` WRITE;
/*!40000 ALTER TABLE `oc_persistent_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_persistent_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_preferences`
--

DROP TABLE IF EXISTS `oc_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_preferences` (
  `userid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `appid` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configkey` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `configvalue` longtext COLLATE utf8_bin,
  PRIMARY KEY (`userid`,`appid`,`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_preferences`
--

LOCK TABLES `oc_preferences` WRITE;
/*!40000 ALTER TABLE `oc_preferences` DISABLE KEYS */;
INSERT INTO `oc_preferences` VALUES ('admin','core','lang','en'),('admin','core','timezone','Pacific/Auckland'),('admin','firstrunwizard','show','0');
/*!40000 ALTER TABLE `oc_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_privatedata`
--

DROP TABLE IF EXISTS `oc_privatedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_privatedata` (
  `keyid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `app` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `key` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`keyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_privatedata`
--

LOCK TABLES `oc_privatedata` WRITE;
/*!40000 ALTER TABLE `oc_privatedata` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_privatedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_properties`
--

DROP TABLE IF EXISTS `oc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_properties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fileid` bigint(20) unsigned NOT NULL,
  `propertyname` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `propertyvalue` varchar(255) COLLATE utf8_bin NOT NULL,
  `propertytype` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fileid_index` (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_properties`
--

LOCK TABLES `oc_properties` WRITE;
/*!40000 ALTER TABLE `oc_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_schedulingobjects`
--

DROP TABLE IF EXISTS `oc_schedulingobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_schedulingobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `calendardata` longblob,
  `uri` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_schedulingobjects`
--

LOCK TABLES `oc_schedulingobjects` WRITE;
/*!40000 ALTER TABLE `oc_schedulingobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_schedulingobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share`
--

DROP TABLE IF EXISTS `oc_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `share_type` smallint(6) NOT NULL DEFAULT '0',
  `share_with` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `uid_owner` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `uid_initiator` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `item_source` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `item_target` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `file_source` bigint(20) DEFAULT NULL,
  `file_target` varchar(512) COLLATE utf8_bin DEFAULT NULL,
  `permissions` smallint(6) NOT NULL DEFAULT '0',
  `stime` bigint(20) NOT NULL DEFAULT '0',
  `accepted` smallint(6) NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `mail_send` smallint(6) NOT NULL DEFAULT '0',
  `share_name` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `attributes` longtext COLLATE utf8_bin,
  PRIMARY KEY (`id`),
  KEY `item_share_type_index` (`item_type`,`share_type`),
  KEY `file_source_index` (`file_source`),
  KEY `token_index` (`token`),
  KEY `share_with_index` (`share_with`),
  KEY `item_source_index` (`item_source`),
  KEY `item_source_type_index` (`item_source`,`share_type`,`item_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share`
--

LOCK TABLES `oc_share` WRITE;
/*!40000 ALTER TABLE `oc_share` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share_external`
--

DROP TABLE IF EXISTS `oc_share_external`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_share_external` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `remote` varchar(512) COLLATE utf8_bin NOT NULL COMMENT 'Url of the remote owncloud instance',
  `remote_id` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '-1',
  `share_token` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'Public share token',
  `password` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT 'Optional password for the public share',
  `name` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'Original name on the remote server',
  `owner` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'User that owns the public share on the remote server',
  `user` varchar(64) COLLATE utf8_bin NOT NULL COMMENT 'Local user which added the external share',
  `mountpoint` varchar(4000) COLLATE utf8_bin NOT NULL COMMENT 'Full path where the share is mounted',
  `mountpoint_hash` varchar(32) COLLATE utf8_bin NOT NULL COMMENT 'md5 hash of the mountpoint',
  `accepted` int(11) NOT NULL DEFAULT '0',
  `lastscan` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sh_external_mp` (`user`,`mountpoint_hash`),
  KEY `sh_external_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share_external`
--

LOCK TABLES `oc_share_external` WRITE;
/*!40000 ALTER TABLE `oc_share_external` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share_external` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages`
--

DROP TABLE IF EXISTS `oc_storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_storages` (
  `id` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `numeric_id` int(11) NOT NULL AUTO_INCREMENT,
  `available` int(11) NOT NULL DEFAULT '1',
  `last_checked` int(11) DEFAULT NULL,
  PRIMARY KEY (`numeric_id`),
  UNIQUE KEY `storages_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages`
--

LOCK TABLES `oc_storages` WRITE;
/*!40000 ALTER TABLE `oc_storages` DISABLE KEYS */;
INSERT INTO `oc_storages` VALUES ('local::/var/www/owncloud/data/admin/uploads/',1,1,NULL),('home::admin',2,1,NULL),('local::/var/www/owncloud/data/',3,1,NULL);
/*!40000 ALTER TABLE `oc_storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag`
--

DROP TABLE IF EXISTS `oc_systemtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `visibility` smallint(6) NOT NULL DEFAULT '1',
  `editable` smallint(6) NOT NULL DEFAULT '1',
  `assignable` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_ident` (`name`,`visibility`,`editable`,`assignable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag`
--

LOCK TABLES `oc_systemtag` WRITE;
/*!40000 ALTER TABLE `oc_systemtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_group`
--

DROP TABLE IF EXISTS `oc_systemtag_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag_group` (
  `systemtagid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` varchar(255) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`gid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_group`
--

LOCK TABLES `oc_systemtag_group` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_object_mapping`
--

DROP TABLE IF EXISTS `oc_systemtag_object_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_systemtag_object_mapping` (
  `objectid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `objecttype` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `systemtagid` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `mapping` (`objecttype`,`objectid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_object_mapping`
--

LOCK TABLES `oc_systemtag_object_mapping` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_trusted_servers`
--

DROP TABLE IF EXISTS `oc_trusted_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_trusted_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(512) COLLATE utf8_bin NOT NULL COMMENT 'Url of trusted server',
  `url_hash` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'sha1 hash of the url without the protocol',
  `token` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT 'token used to exchange the shared secret',
  `shared_secret` varchar(256) COLLATE utf8_bin DEFAULT NULL COMMENT 'shared secret used to authenticate',
  `status` int(11) NOT NULL DEFAULT '2' COMMENT 'current status of the connection',
  `sync_token` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT 'cardDav sync token',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_hash` (`url_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_trusted_servers`
--

LOCK TABLES `oc_trusted_servers` WRITE;
/*!40000 ALTER TABLE `oc_trusted_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_trusted_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_users`
--

DROP TABLE IF EXISTS `oc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_users` (
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `displayname` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_users`
--

LOCK TABLES `oc_users` WRITE;
/*!40000 ALTER TABLE `oc_users` DISABLE KEYS */;
INSERT INTO `oc_users` VALUES ('admin',NULL,'1|$2y$10$tuNZfkIBzw3/EqbEh8AQNesug.IwKQjFKOvbn/6MBm.OuD5MP9fL.'),('ocuser01',NULL,'1|$2y$10$U2uHvxh/5Swdynw4lEnCMOq1Zh3MANM2A/aHw07XTs3Zo/L/kMomS'),('ocuser02',NULL,'1|$2y$10$e9J8jMBtwGRVt/PUpToRoe1drCK/qoBlg8AFSSZ0HYkkWgRYMO86G'),('ocuser03',NULL,'1|$2y$10$kA/k9G1HBvmr1F6wm8CPM.hJKhSt4rv4ut9jyrraWs6qxC4Nq.y.W'),('ocuser04',NULL,'1|$2y$10$f1tmnO0RCl76YbgAZZrsQuTlPuYlXaroJ7Yd.ozK0yvEoaaysl/PW'),('ocuser05',NULL,'1|$2y$10$rqU/rOvH3TuX6Id5oiLWVesFrAbpnJcd4gSeAuYp9.zBUKWW4q1xa'),('ocuser06',NULL,'1|$2y$10$MJ1e9/QoNnZZDxuS4XibW.5lPU5fL0hwiDa5UjWBd0ehjcPuPF4qS'),('ocuser07',NULL,'1|$2y$10$tad6d9l6LH1DhRl3eKAk0O7.jQvr3AL27a3hhAdgHYZQP8S5Kbjry'),('ocuser08',NULL,'1|$2y$10$wyAH16TwBSvgBPuIgNRC2.SRajvoKMVDm26.I4VTfI6H6AiOIWvxy'),('ocuser09',NULL,'1|$2y$10$/cCZ.oHVEAudTKpZ2lxjFe7KR6HnYZo3AMOG967oEF58C6rWhZ1rC'),('ocuser10',NULL,'1|$2y$10$h9l0s1AKTvZNZoD32tOAQ.ZXiomNDfzc5HdoUZgFnQVqSzKvV2wRy'),('ocuser11',NULL,'1|$2y$10$M5y5/4R6IdPQzqN9lFDRU.f.ywj/vngOqqEJVG/ZxTKeOe6iOJU2O'),('ocuser12',NULL,'1|$2y$10$LtOr2Rc/aExiJo0sbnR97OPjtRXOQxKZnFTiifbx0ZON9ztvgplgO'),('ocuser13',NULL,'1|$2y$10$be7dJ99cmEu8Du5bMjhyTOhq3aNp72xSXV8ZdkirR5uh5AT.9rJMu'),('ocuser14',NULL,'1|$2y$10$sLGBbbA8O/.7KlQwJCZVlOy0bYxGqLMvhZaDe5hSOG1xiP5Nuiflq'),('ocuser15',NULL,'1|$2y$10$2UTBh9apO2Zp90kcNNcTLOHd0ymMzPgltTipmKJIEhNGhEZMwyVeC'),('ocuser16',NULL,'1|$2y$10$fsUSt0eHRcy1lTzx0.tmgusw40.VP9bxr7CF.cO7jAShaK2AzpoVC'),('ocuser17',NULL,'1|$2y$10$ncXAUpVlmfz6I1R9q/hp5eReVhzDGnd.65jRn3ksw7seZAbb4X26m'),('ocuser18',NULL,'1|$2y$10$qcL9qEBE9876VCGpazfa2.QaqMKtQXa0gr4vmcwHHZxIlnuk2BidW'),('ocuser19',NULL,'1|$2y$10$rQj.reWXoHYpRcSffY/zdOcvBKcN3evVScJ5DXSg.nq6k1H3XyAF2'),('ocuser20',NULL,'1|$2y$10$eRRJUIU34JNg2rH.yvxquudEOe1BMybXaj9.ni6NqfzLq2XoIt1SC');
/*!40000 ALTER TABLE `oc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory`
--

DROP TABLE IF EXISTS `oc_vcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_vcategory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `category` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `uid_index` (`uid`),
  KEY `type_index` (`type`),
  KEY `category_index` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory`
--

LOCK TABLES `oc_vcategory` WRITE;
/*!40000 ALTER TABLE `oc_vcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory_to_object`
--

DROP TABLE IF EXISTS `oc_vcategory_to_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_vcategory_to_object` (
  `objid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `categoryid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryid`,`objid`,`type`),
  KEY `vcategory_objectd_index` (`objid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory_to_object`
--

LOCK TABLES `oc_vcategory_to_object` WRITE;
/*!40000 ALTER TABLE `oc_vcategory_to_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory_to_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 21:07:18
