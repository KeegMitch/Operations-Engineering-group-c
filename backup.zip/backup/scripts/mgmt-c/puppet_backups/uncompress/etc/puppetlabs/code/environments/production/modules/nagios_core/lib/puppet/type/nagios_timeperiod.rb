require File.dirname(__FILE__) + '/../util/nagios_maker'

Puppet::Util::NagiosMaker.create_nagios_type :timeperiod
