
# This python file was created by the Azure VM Agent. Please do not edit.

import os 


if __name__ == '__main__':
    if os.path.exists("/var/lib/waagent/WALinuxAgent-2.11.1.4/bin/WALinuxAgent-2.11.1.4-py3.9.egg"):
        os.system("/usr/bin/python3 /var/lib/waagent/WALinuxAgent-2.11.1.4/bin/WALinuxAgent-2.11.1.4-py3.9.egg --setup-firewall --dst_ip=168.63.129.16 --uid=0 -w")
    else:
        print("/var/lib/waagent/WALinuxAgent-2.11.1.4/bin/WALinuxAgent-2.11.1.4-py3.9.egg file not found, skipping execution of firewall execution setup for this boot")
